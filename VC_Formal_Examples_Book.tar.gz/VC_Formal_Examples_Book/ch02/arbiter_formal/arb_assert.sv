module arb_assert(
   input                                  clk,
   input                                  rst_n,
   input [15:0] data0,data1,data2,data3,
   input [3:0] req,grant,
   input [15:0] data_out
                );

     assert_grant_0: assert property ( @(posedge clk)
           (req[0]) |-> ##1 grant[0]&(data_out==$past(data0)));
     assert_grant_1: assert property ( @(posedge clk)
           ~(|req[0:0])&(req[1]) |-> ##1 grant[1]&(data_out==$past(data1)));      
     assert_grant_2: assert property ( @(posedge clk)
           ~(|req[1:0])&(req[2]) |-> ##1 grant[2]&(data_out==$past(data2)));     
     assert_grant_3: assert property ( @(posedge clk)
           ~(|req[2:0])&(req[3]) |-> ##1 grant[3]&(data_out==$past(data3)));
endmodule

bind arbiter arb_assert u_arb_assert(.*); 
