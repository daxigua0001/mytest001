
module arbiter(rst_n,clk,req,data0,data1,data2,data3,grant,data_out);
   input rst_n;
   input clk;
   input [3:0] req;
   input [15:0] data0,data1,data2,data3;
   output reg [3:0] grant;
   output reg [15:0] data_out;
   
   always_ff @(posedge clk or negedge rst_n)
   if(~rst_n) begin
     grant<='h0;
     data_out<='h0;
   end else
   begin
     if(req[0]) begin
       grant[0]<=1'b1;
       data_out<=data0;
     end else if(req[1]) begin
       grant[1]<=1'b1;
       data_out<=data1;
     end else if(req[2]) begin
       grant[2]<=1'b1;
       data_out<=data2;
     end else if(req[3]&(data3 != 'h2)) begin
       grant[3]<=1'b1;
       data_out<=data3;
     end else begin
       grant<=4'h0;
     end  
   end
   
   
   
   endmodule
