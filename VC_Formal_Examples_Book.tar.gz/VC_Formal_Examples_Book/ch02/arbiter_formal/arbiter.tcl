clear -all
set design arbiter 
analyze -sv12 arbiter.sv
elaborate -top arbiter
clock  clk
reset  ~rst_n
prove  -all
