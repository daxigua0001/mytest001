set_fml_appmode FPV

set design arbiter 

read_file -top $design -format sverilog -sva -vcs { arbiter.sv arb_assert.sv}

# Clock Definitions 
create_clock clk -period 100

# Reset Definitions 
create_reset rst_n -sense low

# Initialisation Commands 
sim_run -stable
sim_save_reset

## Proof
check_fv 
 
