 vcs simulation command : (+fsdb+sva_success control fsdb dump SVA success case, -assert success control display success case)
vcs -sverilog += -debug_acc+pp+fsdb -R -ucli -do run_vcs.tcl local_var.v +fsdb+sva_success
