class arbiter_test extends uvm_test;
  env my_env;
  sequence_in seq;

  `uvm_component_utils(arbiter_test)

  function new(string name, uvm_component parent = null);
    super.new(name, parent);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    my_env = env::type_id::create("my_env", this);
    seq = sequence_in::type_id::create("seq", this);
  endfunction
 
  task run_phase(uvm_phase phase);
      phase.raise_objection(this);
    seq.start(my_env.master.sqr);
      phase.drop_objection(this);
  endtask: run_phase

endclass
