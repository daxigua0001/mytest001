
`include "agent.sv"
`include "scoreboard.sv"

class arb_model_env extends uvm_env;
  
  //---------------------------------------
  // agent and scoreboard instance
  //---------------------------------------
  arb_agent      arb_agnt;
  arb_scoreboard arb_scb;
  
  `uvm_component_utils(arb_model_env)
  
  //--------------------------------------- 
  // constructor
  //---------------------------------------
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction : new

  //---------------------------------------
  // build_phase - crate the components
  //---------------------------------------
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);

    arb_agnt = arb_agent::type_id::create("arb_agnt", this);
    arb_scb  = arb_scoreboard::type_id::create("arb_scb", this);
  endfunction : build_phase
  
  //---------------------------------------
  // connect_phase - connecting monitor and scoreboard port
  //---------------------------------------
  function void connect_phase(uvm_phase phase);
    arb_agnt.monitor.item_collected_port.connect(arb_scb.item_collected_export);
  endfunction : connect_phase

endclass : arb_model_env
