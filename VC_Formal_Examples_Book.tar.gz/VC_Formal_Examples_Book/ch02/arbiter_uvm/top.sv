//including interfcae and testcase files
import uvm_pkg::*;
`include "uvm_macros.svh"

`include "req_if.sv"
//`include "test.sv"
`include "env.sv"
`include "arbiter_random_test.sv"
//---------------------------------------------------------------

module tbench_top;

  //---------------------------------------
  //clock and rst_n signal declaration
  //---------------------------------------
  bit clk;
  bit rst_n;
  
  //---------------------------------------
  //clock generation
  //---------------------------------------
  always #5 clk = ~clk;
  
  //---------------------------------------
  //rst_n Generation
  //---------------------------------------
  initial begin
    rst_n = 0;
    #5 rst_n =1;
  end
  
  //---------------------------------------
  //interface instance
  //---------------------------------------
  req_if req_if(clk,rst_n);
  
  //---------------------------------------
  //DUT instance
  //---------------------------------------
    
  arbiter u_arbiter(.clk(clk), 
                    .rst_n(rst_n),
                    .req(req_if.req),
                    .data0(req_if.data0),
                    .data1(req_if.data1),
                    .data2(req_if.data2),
                    .data3(req_if.data3),
                    .grant(req_if.grant),
                    .data_out(req_if.data_out));
  
  //---------------------------------------
  //passing the interface handle to lower heirarchy using set method 
  //and enabling the wave dump
  //---------------------------------------
  initial begin 
    $display("Start run...");
    uvm_config_db#(virtual req_if)::set(uvm_root::get(),"*","vif",req_if);
   `ifdef FSDB 
       $fsdbDumpfile("top.fsdb");
       $fsdbDumpvars();
    `endif
    //enable wave dump
    $dumpfile("dump.vcd"); 
    $dumpvars;
  end
  
  //---------------------------------------
  //calling test
  //---------------------------------------
  initial begin 
    run_test();
  end
  
endmodule
