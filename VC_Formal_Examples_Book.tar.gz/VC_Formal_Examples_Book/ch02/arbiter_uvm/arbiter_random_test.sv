class arbiter_random_test extends uvm_test;

  `uvm_component_utils(arbiter_random_test)
  
  arb_model_env env;

  //---------------------------------------
  // sequence instance 
  //--------------------------------------- 
  random_sequence seq;

  //---------------------------------------
  // constructor
  //---------------------------------------
  function new(string name = "arbiter_random_test",uvm_component parent=null);
    super.new(name,parent);
  endfunction : new

  //---------------------------------------
  // build_phase
  //---------------------------------------
  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);

    // Create the env
    env = arb_model_env::type_id::create("env", this);
    // Create the sequence
    seq = random_sequence::type_id::create("seq");
  endfunction : build_phase
  
  //---------------------------------------
  // run_phase - starting the test
  //---------------------------------------
  task run_phase(uvm_phase phase);
    
    phase.raise_objection(this);
      seq.start(env.arb_agnt.sequencer);
    phase.drop_objection(this);
    
    //set a drain-time for the environment if desired
    phase.phase_done.set_drain_time(this, 50);
  endtask : run_phase
  
endclass : arbiter_random_test
