This is arbiter.sv 's UVM testbench. You can run it with following command:

step1. g++ -c arbiter.cpp -o arbiter.o

step2. vcs -full64 -sverilog top.sv arbiter.sv -dpi -ntb_opts uvm -debug_acc+all -lca -kdb -fsdb +define+FSDB -timescale=1ns/10ps arbiter.o +UVM_TR_RECORD +UVM_VERBOSITY=HIGH +UVM_TESTNAME=arbiter_random_test -R
 

