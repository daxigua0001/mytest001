#include <stdio.h>
//#include <svdpi.h>

extern "C" int arbiter( short int req,short int data0,short int data1,short int data2,short int data3){
        int grant;
        short int data;
        if(req&0x1) {
                grant = 1;
                data = data0;
        } else if (req&0x2) {
                grant = 2;
                data = data2;
        } else if (req&0x4) {
                grant = 4;
                data = data2;
        } else if (req&0x8) {
                grant = 8;
                data = data2;
        } else { 
                grant = 0;
        }

}

