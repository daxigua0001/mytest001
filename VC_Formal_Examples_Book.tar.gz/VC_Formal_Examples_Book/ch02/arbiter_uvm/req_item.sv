
class req_item extends uvm_sequence_item;
  //---------------------------------------
  //data and control fields
  //---------------------------------------
   rand bit [3:0] req;    
   rand bit [15:0] data0;    
   rand bit [15:0] data1;    
   rand bit [15:0] data2;    
   rand bit [15:0] data3;

   rand bit [3:0] grant;
   rand bit [15:0] data_out;    

  //---------------------------------------
  //Utility and Field macros
  //---------------------------------------
      `uvm_object_utils_begin(req_item)
        `uvm_field_int(req, UVM_ALL_ON|UVM_HEX)
        `uvm_field_int(data0, UVM_ALL_ON|UVM_HEX)
        `uvm_field_int(data1, UVM_ALL_ON|UVM_HEX)
        `uvm_field_int(data2, UVM_ALL_ON|UVM_HEX)
        `uvm_field_int(data3, UVM_ALL_ON|UVM_HEX)
        `uvm_field_int(grant, UVM_ALL_ON|UVM_HEX)
        `uvm_field_int(data_out, UVM_ALL_ON|UVM_HEX)        
    `uvm_object_utils_end
  
  //---------------------------------------
  //Constructor
  //---------------------------------------
  function new(string name = "req_item");
    super.new(name);
  endfunction
  
endclass
