class arb_sequencer extends uvm_sequencer#(req_item);

  `uvm_component_utils(arb_sequencer) 

  //---------------------------------------
  //constructor
  //---------------------------------------
  function new(string name, uvm_component parent);
    super.new(name,parent);
  endfunction
  
endclass
