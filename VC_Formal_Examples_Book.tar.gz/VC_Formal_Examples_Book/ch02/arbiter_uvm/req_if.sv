
interface req_if(input logic clk,rst_n);
  
  //---------------------------------------
  //declaring the signals
  //---------------------------------------
  logic [3:0] req;
  logic [15:0] data0,data1,data2,data3;
  logic [3:0] grant;
  logic [15:0] data_out;

  
  //---------------------------------------
  //driver clocking block
  //---------------------------------------
  clocking driver_cb @(posedge clk);
    //default input #1 output #1;
    output req;
    output data0;
    output data1;
    output data2;
    output data3;
    input  grant;
    input  data_out;
  endclocking
  
  //---------------------------------------
  //monitor clocking block
  //---------------------------------------
  clocking monitor_cb @(posedge clk);
    //default input #1 output #1;
    input req;
    input data0;
    input data1;
    input data2;
    input data3;
    input  grant;
    input  data_out;  
  endclocking
  
  //---------------------------------------
  //driver modport
  //---------------------------------------
  modport DRIVER  (clocking driver_cb,input clk,rst_n);
  
  //---------------------------------------
  //monitor modport  
  //---------------------------------------
  modport MONITOR (clocking monitor_cb,input clk,rst_n);
  
endinterface
