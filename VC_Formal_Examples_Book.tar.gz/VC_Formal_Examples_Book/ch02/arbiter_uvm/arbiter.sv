
module arbiter(rst_n,clk,req,data0,data1,data2,data3,grant,data_out);
   parameter NUM_REQ = 4;
   parameter DATA_WIDTH = 16;

   input rst_n;
   input clk;
   input [NUM_REQ-1:0] req;
   input [DATA_WIDTH-1:0] data0;
   input [DATA_WIDTH-1:0] data1;
   input [DATA_WIDTH-1:0] data2;
   input [DATA_WIDTH-1:0] data3;
   output reg [NUM_REQ-1:0] grant;
   output reg [DATA_WIDTH-1:0] data_out;
   
   always_ff @(posedge clk or negedge rst_n)
   if(~rst_n) begin
     grant<='h0;
     data_out<='h0;
   end else
   begin
     if(req[0]) begin
       grant[0]<=1'b1;
       data_out<=data0;
     end else if(req[1]) begin
       grant[1]<=1'b1;
       data_out<=data1;
     end else if(req[2]) begin
       grant[2]<=1'b1;
       data_out<=data2;
     end else if(req[3]&(data3 != 'h2)) begin
       grant[3]<=1'b1;
       data_out<=data3;
     end else begin
       grant<=4'h0;
     end  
   end
   
   
     assert_grant_3: assert property ( @(posedge clk)
           ~(|req[2:0])&(req[3]) |-> ##1 grant[3]&(data_out==$past(data3)));
     assert_grant_2: assert property ( @(posedge clk)
           ~(|req[1:0])&(req[2]) |-> ##1 grant[2]&(data_out==$past(data2)));     
     assert_grant_1: assert property ( @(posedge clk)
           ~(|req[0:0])&(req[1]) |-> ##1 grant[1]&(data_out==$past(data1)));   
     assert_grant_0: assert property ( @(posedge clk)
           (req[0]) |-> ##1 grant[0]&(data_out==$past(data0)));  
   
   endmodule
