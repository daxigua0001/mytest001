class random_sequence extends uvm_sequence#(req_item);
  
  `uvm_object_utils(random_sequence)
   
  //--------------------------------------- 
  //Constructor
  //---------------------------------------
  function new(string name = "random_sequence");
    super.new(name);
  endfunction
  
  virtual task body();
  repeat(1000000) begin
    `uvm_do(req)
  end
  endtask
endclass
//=========================================================================
