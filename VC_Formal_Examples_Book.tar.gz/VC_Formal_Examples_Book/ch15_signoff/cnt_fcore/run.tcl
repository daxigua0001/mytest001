set_fml_appmode FPV

signoff_config -type all

set design cnt_fcore 

# Compilation Step 
read_file -top $design -format sverilog -sva -vcs cnt_fcore.v

# Clock Definitions 
create_clock clk -period 100

# Reset Definitions 
create_reset rst_n -sense low 

# Initialisation Commands 
sim_run -stable
sim_save_reset

## Proof
check_fv -block 

## Reports
report_fv -list > results.txt
