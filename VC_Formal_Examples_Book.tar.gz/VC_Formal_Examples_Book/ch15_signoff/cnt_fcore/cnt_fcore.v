
module cnt_fcore
(
input   clk,
input   rst_n,

input   inc,
input   dec,
output reg [3:0] cnt
);

always @(posedge clk or negedge rst_n)
    if(!rst_n) begin
        cnt <= 4'b0;
    end
    else begin
       //original code 
        if(inc & !dec)   cnt<= cnt + 1'b1;
        else if(~inc & dec)  cnt<= cnt - 1'b1;

       //fault inject code
        //if(inc & !dec)   cnt<= cnt + 1'b1;
        //else if(!inc & dec)  cnt<= cnt + 1'b1;
    end


ast_stable:  assert property (@(posedge clk) disable iff(!rst_n)
                (!inc && !dec) |=> $stable(cnt) );    

endmodule




