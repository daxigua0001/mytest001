

`define CSR_RELOAD_VALUE_ADDR 0 
`define CSR_CURRENT_VALUE_ADDR 1
`define CSR_TIMER_CTRL_ADDR 2
`define CSR_INTERRUPT_ADDR 3 
module timer_assert(
   input                                  PCLK,
   input                                  PRESETn,
   //input [31:0] csr_regs[4],
   input [31:0] counter,
   input IRQ,
   input read_en,
   input PREADY,
   input PSLVERR,
   input [31:0] PRDATA,
   input wr_reload
   );
//assert_reset_reload: assert property( @(posedge PCLK)  (timer.PRESETn ==0) |=>  (timer.csr_regs_reload==0));

assert_reload_reg_wr: assert property( @(posedge PCLK) 
              (timer.write_en & (timer.PADDR[3:0]==0)) |=>  (timer.csr_regs_reload==$past(timer.PWDATA)));
//cover_reload_reg_wr: cover property( @(posedge PCLK) 
//                        (timer.write_en & (timer.PADDR[3:0]==0)) |=>  (timer.csr_regs_reload==$past(timer.PWDATA)));

assert_ctrl_reg_wr: assert property( @(posedge PCLK) 
              (timer.write_en & (timer.PADDR[3:0]==4'h8)) |=>  (timer.csr_regs_ctrl[0]==$past(timer.PWDATA[0])));


assert_intr_en_reg_wr: assert property( @(posedge PCLK) 
              (timer.write_en & (timer.PADDR[3:0]==4'hc)) |=>  (timer.csr_regs_intr_en[0]==$past(timer.PWDATA[0])));





//assert_reload_read_wr: assert property( @(posedge PCLK)  ((timer.write_en&(timer.PADDR[3:0]==0)&(&timer.PWDATA[1:0])) ##1 read_en&(timer.PADDR==0)  |=>  (PRDATA==32'h0000_0003)));

//cover_IRQ_active: cover property ( @(posedge PCLK) disable iff (~PRESETn) 
//    counter == 32'h1 ##1 IRQ==1 
//);


assert_counter_never_out_range: assert property ( @(posedge PCLK) disable iff (~PRESETn)
    !(counter<0 || counter>timer.csr_regs_reload)
);
assert_counter_eq0_if_IRQ_active: assert property ( @(posedge PCLK) disable iff (~PRESETn)
    IRQ |-> counter==32'h0000_0000
);


assert_counter_stable_if_disble_timer: assert property ( @(posedge PCLK) disable iff (~PRESETn)
    ~(timer.csr_regs_ctrl[0] | wr_reload) |=> $stable(counter)
);

bit [31:0] counter_irq_distance;
bit had_IRQ;
always @(posedge PCLK)
if(IRQ)
    counter_irq_distance<='h0;
else
    counter_irq_distance<=counter_irq_distance+'h1;
always @(posedge PCLK or negedge PRESETn)
if(~PRESETn)
    had_IRQ<=1'b0;
else if(IRQ)
    had_IRQ<=1'b1;


assert_had_IRQ: assert property ( @(posedge PCLK) disable iff (~PRESETn)
    IRQ |=> had_IRQ 
);


        
assert_IRQ_distance_should_be_ge_reload_val:assert property ( @(posedge PCLK) disable iff (~PRESETn)
    had_IRQ&IRQ |-> counter_irq_distance >= timer.csr_regs_reload 
);

//assume_IRQ_distance_lt_100_reload_val:assume property ( @(posedge PCLK) disable iff (~PRESETn)
//    counter_irq_distance <100
//);
//cover_IRQ_distance_eq88:cover property ( @(posedge PCLK) disable iff (~PRESETn)
//    had_IRQ&IRQ&(counter_irq_distance ==88)
//);

//timer disable |-> no irq
assert_no_irq : assert property ( @(posedge PCLK) disable iff (~PRESETn)
    ~timer.enable_timer |=> ~timer.IRQ
);
//counter==0&enable_timer |=> counter==reload_value
assert_0_to_reload : assert property ( @(posedge PCLK) disable iff (~PRESETn)
    ((timer.counter==0) && timer.enable_timer) |=> timer.counter == timer.csr_regs_reload 
);

assert_curr_cnt_read: assert property ( @(posedge PCLK) disable iff (~PRESETn)
    (read_en&(timer.PADDR[3:0]=={`CSR_CURRENT_VALUE_ADDR,2'b00}) |=> PRDATA==$past(counter)) 
);

assert_reload_read: assert property ( @(posedge PCLK) disable iff (~PRESETn)
    (read_en&(timer.PADDR[3:0]=={`CSR_RELOAD_VALUE_ADDR,2'b00}) |=> PRDATA==$past(timer.csr_regs_reload)) 
);

assert_ctrl_read: assert property ( @(posedge PCLK) disable iff (~PRESETn)
    (read_en&(timer.PADDR[3:0]=={`CSR_TIMER_CTRL_ADDR,2'b00}) |=> PRDATA==$past(timer.csr_regs_ctrl)) 
);

assert_intr_en_read: assert property ( @(posedge PCLK) disable iff (~PRESETn)
    (read_en&(timer.PADDR[3:0]=={`CSR_INTERRUPT_ADDR,2'b00}) |=> PRDATA==$past(timer.csr_regs_intr_en)) 
);


//assert_reload_read: assert property( @(posedge PCLK)  (read_en & (timer.PADDR[3:0]==0)) |=>  (PRDATA==csr_regs_reload));
//cover_reload_value_read: cover property( @(posedge PCLK)  (read_en & (timer.PADDR[3:0]==0)) );


assert_PSLVERR:assert property ( @(posedge PCLK) disable iff (~PRESETn) timer.PSLVERR==1'b0);
assert_PREADY:assert property ( @(posedge PCLK) disable iff (~PRESETn) timer.PREADY==1'b1);


assert_IRQ_one_cyle:assert property ( @(posedge PCLK) disable iff (~PRESETn)
    IRQ |-> ##1 ~IRQ );


covergroup cg @(posedge PCLK);
coverpoint timer.enable_timer{
bins b1 = {0};
bins b2 = {1};
}
endgroup

// instantiate a covergroup
cg inst = new();

endmodule
bind timer timer_assert u_timer_assert(.*);



