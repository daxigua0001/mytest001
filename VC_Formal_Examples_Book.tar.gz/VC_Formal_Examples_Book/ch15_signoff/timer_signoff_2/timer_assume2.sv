`define CSR_RELOAD_VALUE_ADDR 0 
`define CSR_CURRENT_VALUE_ADDR 1
`define CSR_TIMER_CTRL_ADDR 2
`define CSR_INTERRUPT_ADDR 3
module timer_assume
#(
    parameter APB_ADDR_WIDTH = 12  //APB slaves are 4KB by default
)
(
    input  reg                      PCLK,
    input  reg                      PRESETn,
    input  reg [APB_ADDR_WIDTH-1:0] PADDR,
    input  reg               [31:0] PWDATA,
    input  reg                      PWRITE,
    input  reg                      PSEL,
    input  reg                      PENABLE
   
    
);

//disable programming reload value when enable counting
    wire write_en=PSEL && PENABLE && PWRITE;
    assume_counter_never_wr_reload_when_enable_timer: assume property ( @(posedge PCLK) disable iff (~PRESETn)
         timer.csr_regs_ctrl[0] |->  !(write_en && (PADDR[3:0]=={`CSR_RELOAD_VALUE_ADDR,2'b00}))
);

//assume_reload_max: assume property ( @(posedge PCLK) disable iff (~PRESETn)
//         timer.csr_regs_reload <4
//);

//cov_reload_max: cover property ( @(posedge PCLK) disable iff (~PRESETn)
//         timer.csr_regs_reload[31]==0 |=>  timer.csr_regs_reload[31]==1 
//);
//
//cov_reload_max2: cover property ( @(posedge PCLK) 
//         timer.csr_regs_reload[3]==0 |=>  timer.csr_regs_reload[3]==1 
//);


endmodule
bind timer timer_assume u_timer_assume(.*);


