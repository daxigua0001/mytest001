set_fml_appmode FPV

signoff_config -type all

set design timer

# Compilation Step 
read_file -top $design -format sverilog -sva -vcs {-f timer.f}

# Clock Definitions 
create_clock PCLK -period 100

# Reset Definitions 
create_reset PRESETn -sense low 

# Initialisation Commands 
sim_run -stable
sim_save_reset

## Proof
check_fv -block 

## Reports
report_fv -list > results.txt
