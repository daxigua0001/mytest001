module sel_sim();


reg clk, rst_n;
reg a,b;
always #5 clk=~clk;

initial begin
    rst_n = 1'b0;
    clk = 1'b0;
    a=1'b0;
    b=1'b0;
    #5 rst_n = 1'b1;
    
    #10;
    a=1'b0; b=1'b0;
    #10;
    a=1'b0; b=1'b1;
    #10;
    a=1'b1; b=1'b0;
    #10;
    a=1'b1; b=1'b1;

    #1000;
    $finish;
end

reg out;
wire sel=1'bx;
always@(*)
  if(sel)
    out = a;
  else
    out = b;


initial begin
      $fsdbDumpfile("top.fsdb");
      $fsdbDumpvars;
      $fsdbDumpMDA;
      $fsdbDumpSVA;
end


endmodule
