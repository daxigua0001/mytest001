
  ################################################################
  # generate assert properties for harvestable module's clock and output signals
  ################################################################
  proc injectx_inst_output { {clock_path ""} {inst_path ""} { condition "" } } {
    set inst [get_cells   $inst_path]
    if { ${clock_path} ne "" } {
       fxp_assume -injectx -name injectx_$clock_path -condition $condition  $clock_path
    }
    set ports     [get_pins -word -of_objects ${inst}];
    set outPorts   [filter_collection $ports {direction == out}];
    foreach_in_collection port $outPorts {
       set outName [get_attribute $port full_name];
       fxp_assume -injectx -name injectx_${inst_path}.$outName -condition $condition  $outName

     }
  }

  proc injectx_inst_input { {clock_path ""} {inst_path ""} { condition "" } } {
    set inst [get_cells   $inst_path]
    if { ${clock_path} ne "" } {
       fxp_assume -injectx -name injectx_$clock_path -condition $condition  $clock_path
    }
    set ports     [get_pins -word -of_objects ${inst}];
    set inPorts   [filter_collection $ports {direction == in}];
    foreach_in_collection port $inPorts {
       set inName [get_attribute $port full_name];
       fxp_assume -injectx -name injectx_${inst_path}_$inName -condition $condition  $inName

     }
  }

#fixme, this injectx_interface has not finished
  proc injectx_interface { {prefix ""} {inst_path ""} { condition "" } } {
    set inst [get_cells   $inst_path]
    set ports     [get_pins -word -of_objects ${inst}];
    #set inPorts   [filter_collection $ports {direction == in}];
    inPorts   [filter_collection $ports hierarchical_name=~"$prefix.*" -regexp ]
    foreach_in_collection port $inPorts {
       set inName [get_attribute $port full_name];
       fxp_assume -injectx -name injectx_${inst_path}_$inName -condition $condition  $inName

     }
  }
  

  proc injectx_clock_domain_regs { {clock_path ""} { condition "" } } {
    if { ${clock_path} ne "" } {
#fxp_assume -injectx -name injectx_$clock_path -condition $condition  $clock_path
    }

    set cells [get_cells -of [get_nets $clock_path -segments ]]
    set cells [filter_collection $cells { is_a_flip_flop == true }];
            
    foreach_in_collection cell $cells {
       set cellName  [get_attribute $cell full_name]
#puts "fxp_assume -injectx -name injectx_$cellName -condition $condition  $cellName"
       fxp_assume -injectx -name injectx_$cellName -condition $condition  $cellName
     }
  }


  proc assert_never_x_inst_output { {inst_path ""} { condition "1" } } {
    set inst [get_cells   $inst_path]
    set ports     [get_pins -word -of_objects ${inst}];
    set outPorts   [filter_collection $ports {direction == out}];
    foreach_in_collection port $outPorts {
       set outName [get_attribute $port full_name];
       fxp_assert -name never_x_${inst_path}.outName -condition $condition  $outName
     }
  }
