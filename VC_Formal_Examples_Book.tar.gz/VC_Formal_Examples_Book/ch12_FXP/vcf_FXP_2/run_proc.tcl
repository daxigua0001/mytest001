set_fml_appmode FXP

# Source Custom VCF Procs
source ../../vcf_procs_TCL/vcf_procs.tcl -echo -verbose

set design soc 

set_blackbox -designs {uart timer}

read_file -top $design -format sverilog -sva -vcs {-f ./riscv.f}
#read_file -top $design -format sverilog -sva -vcs {-f ./riscv.f +define+FXP_BUG_FIX}

##############################################
#snip cfg signals, avoid wb bus reconfig
snip_driver -env u_csr.cfg_xfence_uart0
snip_driver -env u_csr.cfg_xfence_uart1
snip_driver -env u_csr.cfg_xfence_timer

#cfg value stable

fvassume stable_pg_config_uart0 -env -stable -expr { u_csr.cfg_xfence_uart0 } -clock clk
fvassume stable_pg_config_uart1 -env -stable -expr { u_csr.cfg_xfence_uart1 } -clock clk
fvassume stable_pg_config_timer -env -stable -expr { u_csr.cfg_xfence_timer } -clock clk

#cfg value not x
#fvassume stable_pg_config_uart0_neverX -expr { !$isunknown(u_csr.cfg_xfence_uart0) } -clock clk
#fvassume stable_pg_config_uart1_neverX -expr { !$isunknown(u_csr.cfg_xfence_uart1) } -clock clk
#fvassume stable_pg_config_timer_neverX -expr { !$isunknown(u_csr.cfg_xfence_timer) } -clock clk


#assume no x for memory rdata
#fxp_assume -nox soc.u_rom_wrapper.rdata
#fxp_assume -nox soc.u_sram_wrapper.rdata

##############################################333
create_clock clk -period 100
create_reset rst_n -sense low

sim_run -stable
sim_save_reset

#inject x
injectx_inst_out "soc.u0_uart"  "~u_csr.cfg_xfence_uart0"
injectx_inst_out "soc.u1_uart"  "~u_csr.cfg_xfence_uart1"
injectx_inst_out "soc.u0_timer" "~u_csr.cfg_xfence_timer"


#check if x-prop
fxp_assert -name neverX_wb_ack_s2    u_wb_interconnect.wb_ack_s2
fxp_assert -name neverX_wb_err_s2    u_wb_interconnect.wb_err_s2
fxp_assert -name neverX_wb_rdata_s2  u_wb_interconnect.wb_rdata_s2

fxp_assert -name neverX_wb_ack_s3    u_wb_interconnect.wb_ack_s3
fxp_assert -name neverX_wb_err_s3    u_wb_interconnect.wb_err_s3
fxp_assert -name neverX_wb_rdata_s3  u_wb_interconnect.wb_rdata_s3

fxp_assert -name neverX_wb_ack_s6    u_wb_interconnect.wb_ack_s6
fxp_assert -name neverX_wb_err_s6    u_wb_interconnect.wb_err_s6
fxp_assert -name neverX_wb_rdata_s6  u_wb_interconnect.wb_rdata_s6

fxp_assert -name neverX_cpu_irq   u_cpu.cpu_irq

#following properies are used to make sure constraints are right. old version does not support fvcover for FXP. 2022.06-SP2 does.
if { 0 } {
fvcover cov_mask0 -expr { {u_csr.cfg_xfence_timer,u_csr.cfg_xfence_uart1,u_csr.cfg_xfence_uart0} == 3'h0 }
fvcover cov_mask7 -expr { {u_csr.cfg_xfence_timer,u_csr.cfg_xfence_uart1,u_csr.cfg_xfence_uart0} == 3'h7 }

fxp_assert -name noX_1 u0_timer.IRQ
fxp_assert -name noX_2 wb_err_uart0
fxp_assert -name noX_3 wb_err_uart1
}

########################################################
## Proof
########################################################
check_fv -block 

