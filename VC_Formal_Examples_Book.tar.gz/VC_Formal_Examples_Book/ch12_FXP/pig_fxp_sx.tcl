

#############################################################################################
##This is a script to verify SX block RB-harvesting feature , steps to run it:
## Step1: dj -l sx_dc_elab.log -DSTRUCT_VIEW -DMEM_VIEW rt gc::dc_elab/dc_elab_sx
## Step2: afi -vcf -tcl run_sx_rb_harvesting.tcl  (or: vcf -f run_sx_rb_harvesting.tcl)
############################################################################################

set design sx
set_fml_appmode FXP

source $env(STEM)/src/formal/sio/common/sio_common_tcl_lib_vcf.tcl
source $env(STEM)/out/linux_3.10.0_64.VCS/$env(PROJECT)/config/sx_rtl/pub/sim/publish/tiles/tile/$design/publish_rtl/manifest/link_library.tcl

read_file -top $design -format sverilog -sva -vcs " -sverilog -assert svaext +libext+.sv+.v \
        +define+USE_KC_BEHAVIORAL+FORMAL+FPV_VCF \
        -f $env(OUT_HOME)/$env(PROJECT)/config/sx_rtl/pub/sim/publish/tiles/tile/sx/publish_rtl/sx.vf"
#-f $OUT_HOME/$PROJECT/config/sx_formal/pub/sim/from_dut.compfiles.xf "

create_clock {Cpl_GFXCLK} -period 100 -initial 1
create_reset RSMU_GFX_hard_resetb -sense low
create_reset GRBM_GFX_soft_resetb -sense low 

#############################################Constraints##############################################################
set_constant -value 'h0 sx.SE_STRAP_id[2:0]
#randomize  RB harvesting seting 
snip_driver -env sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask
#fvassume stable_harvesting_config  -expr {$stable(sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[3:0])}
#set_constant -value 'hE sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask
fvassume stable_harvesting_config -stable -expr { sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask } -clock Cpl_GFXCLK 
#fvassume -expr { @(edge Cpl_GFXCLK) $stable(sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask) } -clock Cpl_GFXCLK

snip_driver -env sx.sa1sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask
fvassume same_harvesting_config -env -expr {sx.sa1sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask == sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask}

snip_driver -env sx.sa0sx.cgcg_en
#fvassume -expr {sx.sa0sx.cgcg_en == 1} sx.disable_cgcg_en_0 -env -clock sx.Cpl_GFXCLK
set_constant -value 1 sx.sa0sx.cgcg_en
snip_driver -env sx.sa1sx.cgcg_en
set_constant -value 1 sx.sa1sx.cgcg_en

snip_driver -env sx.sa1sx.dft_shift_clk 
fvassume -expr {sx.sa1sx.dft_shift_clk == 0} sx.disable_dft_shift_clk_1 -env -clock sx.Cpl_GFXCLK
snip_driver -env sx.sa0sx.dft_shift_clk 
fvassume -expr {sx.sa0sx.dft_shift_clk == 0} sx.disable_dft_shift_clk_0 -env -clock sx.Cpl_GFXCLK
snip_driver -env sx.sa0sx.dft_clk_gate_ctrl 
fvassume -expr {sx.sa0sx.dft_clk_gate_ctrl == 2'b00} sx.disable_dft_clk_gate_ctrl_0 -env -clock sx.Cpl_GFXCLK
snip_driver -env sx.sa1sx.dft_clk_gate_ctrl 
fvassume -expr {sx.sa1sx.dft_clk_gate_ctrl == 2'b00} sx.disable_dft_clk_gate_ctrl_1 -env -clock sx.Cpl_GFXCLK

############################## INITIALIZE DESIGN BY SIMULATION#########################
sim_force sa0sx.TTOP_SX_mgcg_override -apply 1
sim_force sa1sx.TTOP_SX_mgcg_override -apply 1
sim_run -stable
sim_set_state -uninitialized -apply 0
sim_save_reset

##############################################Inject X##############################################################
##inject X on  related harvesting domain : 1.harvestable clock fanout registers 3.SX input? #### 
#SA0 Packer0 RB0 harvestable	1	
injectx_clock_domain_regs "sa0sx.sx_col0_dyn_sclk" "~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[0]"
injectx_clock_domain_regs "sa0sx.sx_col0_wr_dyn_sclk" "~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[0]"
injectx_clock_domain_regs "sa0sx.sx_col0_exp_dyn_sclk" "~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[0]"
injectx_clock_domain_regs "sa0sx.sx_col0_req_dyn_sclk" "~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[0]"
injectx_clock_domain_regs "sa0sx.sx_col0_bld_dyn_sclk" "~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[0]"
injectx_clock_domain_regs "sa0sx.sx_col0_downconvert_dyn_sclk" "~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[0]"
injectx_clock_domain_regs "sa0sx.sx_col0_dbif_dyn_sclk" "~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[0]"
fxp_assume -injectx -name injectx_SA0SX_DB0_quad_free -condition ~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[0]  SA0SX_DB0_quad_free
if {1} {
#SA0 Packer1 RB0 harvestable	2	
injectx_clock_domain_regs "sa0sx.sx_col1_dyn_sclk" "~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[1]"
injectx_clock_domain_regs "sa0sx.sx_col1_wr_dyn_sclk" "~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[1]"
injectx_clock_domain_regs "sa0sx.sx_col1_exp_dyn_sclk" "~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[1]"
injectx_clock_domain_regs "sa0sx.sx_col1_req_dyn_sclk" "~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[1]"
injectx_clock_domain_regs "sa0sx.sx_col1_bld_dyn_sclk" "~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[1]"
injectx_clock_domain_regs "sa0sx.sx_col1_downconvert_dyn_sclk" "~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[1]"
injectx_clock_domain_regs "sa0sx.sx_col1_dbif_dyn_sclk" "~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[1]"
fxp_assume -injectx -name injectx_SA0SX_DB1_quad_free -condition ~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[1]  SA0SX_DB1_quad_free
#SA1 Packer0 RB0 harvestable	3	
injectx_clock_domain_regs "sa1sx.sx_col0_dyn_sclk" "~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[2]"
injectx_clock_domain_regs "sa1sx.sx_col0_wr_dyn_sclk" "~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[2]"
injectx_clock_domain_regs "sa1sx.sx_col0_exp_dyn_sclk" "~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[2]"
injectx_clock_domain_regs "sa1sx.sx_col0_req_dyn_sclk" "~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[2]"
injectx_clock_domain_regs "sa1sx.sx_col0_bld_dyn_sclk" "~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[2]"
injectx_clock_domain_regs "sa1sx.sx_col0_downconvert_dyn_sclk" "~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[2]"
injectx_clock_domain_regs "sa1sx.sx_col0_dbif_dyn_sclk" "~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[2]"
fxp_assume -injectx -name injectx_SA1SX_DB0_quad_free -condition ~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[2]  SA1SX_DB0_quad_free
#SA1 Packer1 RB0 harvestable     5	
injectx_clock_domain_regs "sa1sx.sx_col1_dyn_sclk" "~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[3]"
injectx_clock_domain_regs "sa1sx.sx_col1_wr_dyn_sclk" "~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[3]"
injectx_clock_domain_regs "sa1sx.sx_col1_exp_dyn_sclk" "~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[3]"
injectx_clock_domain_regs "sa1sx.sx_col1_req_dyn_sclk" "~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[3]"
injectx_clock_domain_regs "sa1sx.sx_col1_bld_dyn_sclk" "~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[3]"
injectx_clock_domain_regs "sa1sx.sx_col1_downconvert_dyn_sclk" "~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[3]"
injectx_clock_domain_regs "sa1sx.sx_col1_dbif_dyn_sclk" "~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[3]"
fxp_assume -injectx -name injectx_SA1SX_DB1_quad_free -condition ~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[3]  SA1SX_DB1_quad_free
}
if { 1 } {

##inject X on  related harvesting domain : 1.harvestable modules' output 2.icg output clock 3.SX input? #### 
#inject X on SA0 Packer0
#injectx_clock_domain_regs "sa0sx.sx_col0_dyn_sclk" "~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[0]"
#injectx_inst_output "" "sa0sx.u0sx_color_write" "~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[0]"
#injectx_inst_output "" "sa0sx.usx_color_export.u0_sx_color_valids" "~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[0]"
#injectx_inst_output "" "sa0sx.usx_color_export.u0_sx_color_scoreboard_packer" "~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[0]"
#injectx_inst_output "" "sa0sx.usx_color_export.sx_color_oreo_memory_gen_blk[0]" "~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[0]"
#injectx_inst_output "" "sa0sx.usx_color_export.u0_sx_color_requester" "~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[0]"
#injectx_inst_output "" "sa0sx.usx_color_export.u0_sx_color_blend" "~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[0]"
#injectx_inst_output "" "sa0sx.usx_color_export.u0_sx_color_dbif" "~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[0]"
##inject X on SA0 Packer1
#injectx_clock_domain_regs "sa0sx.sx_col1_dyn_sclk" "~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[1]"
#injectx_inst_output "" "sa0sx.u1sx_color_write" "~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[1]"
#injectx_inst_output "" "sa0sx.usx_color_export.u1_sx_color_valids" "~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[1]"
#injectx_inst_output "" "sa0sx.usx_color_export.u1_sx_color_scoreboard_packer" "~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[1]"
#injectx_inst_output "" "sa0sx.usx_color_export.sx_color_oreo_memory_gen_blk[0]" "~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[1]"
#injectx_inst_output "" "sa0sx.usx_color_export.u1_sx_color_requester" "~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[1]"
#injectx_inst_output "" "sa0sx.usx_color_export.u1_sx_color_blend" "~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[1]"
#injectx_inst_output "" "sa0sx.usx_color_export.u1_sx_color_dbif" "~sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[1]"
##inject X on SA1 Packer0
#injectx_clock_domain_regs "sa1sx.sx_col0_dyn_sclk" "~sx.sa1sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[2]"
#injectx_inst_output "" "sa1sx.u0sx_color_write" "~sx.sa1sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[2]"
#injectx_inst_output "" "sa1sx.usx_color_export.u0_sx_color_valids" "~sx.sa1sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[2]"
#injectx_inst_output "" "sa1sx.usx_color_export.u0_sx_color_scoreboard_packer" "~sx.sa1sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[2]"
#injectx_inst_output "" "sa1sx.usx_color_export.sx_color_oreo_memory_gen_blk[0]" "~sx.sa1sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[2]"
#injectx_inst_output "" "sa1sx.usx_color_export.u0_sx_color_requester" "~sx.sa1sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[2]"
#injectx_inst_output "" "sa1sx.usx_color_export.u0_sx_color_blend" "~sx.sa1sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[2]"
#injectx_inst_output "" "sa1sx.usx_color_export.u0_sx_color_dbif" "~sx.sa1sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[2]"
##inject X on SA1 Packer1
#injectx_clock_domain_regs "sa1sx.sx_col1_dyn_sclk" "~sx.sa1sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[3]"
#injectx_inst_output "" "sa1sx.u1sx_color_write" "~sx.sa1sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[3]"
#injectx_inst_output "" "sa1sx.usx_color_export.u1_sx_color_valids" "~sx.sa1sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[3]"
#injectx_inst_output "" "sa1sx.usx_color_export.u1_sx_color_scoreboard_packer" "~sx.sa1sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[3]"
#injectx_inst_output "" "sa1sx.usx_color_export.sx_color_oreo_memory_gen_blk[0]" "~sx.sa1sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[3]"
#injectx_inst_output "" "sa1sx.usx_color_export.u1_sx_color_requester" "~sx.sa1sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[3]"
#injectx_inst_output "" "sa1sx.usx_color_export.u1_sx_color_blend" "~sx.sa1sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[3]"
#injectx_inst_output "" "sa1sx.usx_color_export.u1_sx_color_dbif" "~sx.sa1sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[3]"



#####################################################Observer never X ####################################################
##observe never X on: 1. input-fans points 2. non-harvest domain 3.dut's output non-harvest domain 4.harvest signals when relavent harvest configure is invalid #### 

#input fans logic should never be x 
#fxp_assert -name input_fans_color_blend  sx.sa0sx.usx_color_export.u0_sx_color_blend.perf_mrt_blend_bypass[1:0]
fxp_assert -name input_fans_col0_wr_busy_q  sx.sa0sx.col0_wr_busy_q

#non-harvestable should never be x (perfmon/dbg_mux/cac)
#fxp_assert -name non_harvestable_scan0 sx.sa0sx.perfmon_sclk
assert_never_x_inst_output "sa0sx.usx_perfmon" "1"
assert_never_x_inst_output "sa0sx.u_sx_dbg_mux" "1"
assert_never_x_inst_output "sa1sx.usx_perfmon" "1"
assert_never_x_inst_output "sa1sx.u_sx_dbg_mux" "1"

set cacCells [get_cells   {sa*sx.SX_CAC_*}]
foreach_in_collection cell $cacCells {
   set cellName [get_attribute $cell full_name];
   fxp_assert -name neverX_$cellName -condition 1  $cellName
}

#Usx_ati_grbm_se_interface* sx_rbiu_*
assert_never_X_inst_output "sa0sx.usx_ati_sa_cfg_reg" "1"
assert_never_X_inst_output "sa0sx.usx_ati_rb_backend_cfg_reg" "1"
#assert_never_X_inst_output "Busy flop, busy_counter and so forth." "1"
assert_never_X_inst_output "sa0sx.usx_destination_sort" "1"
#assert_never_X_inst_output "Perf event, debug busy and so forth" "1"
assert_never_X_inst_output "sa0sx.usx_position_write" "1"
assert_never_X_inst_output "sa0sx.usx_position_export" "1"
assert_never_X_inst_output "sa0sx.usx_position_export.usx_position_paif" "1"
#assert_never_X_inst_output "Perf event, debug busy and so forth" "1"
assert_never_X_inst_output "sa0sx.usx_index_write" "1"
assert_never_X_inst_output "sa0sx.usx_index_export" "1"
assert_never_X_inst_output "sa0sx.usx_index_export.usx_index_paif" "1"

##output of harvestable signals never X if packer_active_mask==0
fxp_assert -name neverX_SX_DB0_quad_send -condition 1  sa0sx.SX_DB0_quad_send
fxp_assert -name neverX_SX_DB0_quad_fgcg -condition 1  sa0sx.SX_DB0_quad_fgcg
fxp_assert -name neverX_SX_DB0_quad_format -condition sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[0] sa0sx.SX_DB0_quad_format
fxp_assert -name neverX_SX_DB0_quad_context_id -condition sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[0] sa0sx.SX_DB0_quad_context_id
fxp_assert -name neverX_SX_DB0_quad_pix_enable -condition sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[0] sa0sx.SX_DB0_quad_pix_enable
fxp_assert -name neverX_SX_DB0_quad_exp_enable -condition sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[0] sa0sx.SX_DB0_quad_exp_enable
fxp_assert -name neverX_SX_DB0_quad_blend_bypass -condition sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[0] sa0sx.SX_DB0_quad_blend_bypass
fxp_assert -name neverX_SX_DB0_quad_dont_rd_dest -condition sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[0] sa0sx.SX_DB0_quad_dont_rd_dest
fxp_assert -name neverX_SX_DB0_quad_data -condition sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[0] sa0sx.SX_DB0_quad_data
fxp_assert -name neverX_SX_DB0_quad_mrt -condition sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[0] sa0sx.SX_DB0_quad_mrt
fxp_assert -name neverX_SX_DB0_quad_wave_id -condition sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[0] sa0sx.SX_DB0_quad_wave_id
fxp_assert -name neverX_SX_DB0_quad_last_export_of_mrt -condition sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[0] sa0sx.SX_DB0_quad_last_export_of_mrt
fxp_assert -name neverX_SX_DB0_quad_last_mrt_of_wave -condition sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[0] sa0sx.SX_DB0_quad_last_mrt_of_wave
fxp_assert -name neverX_SX_DB1_quad_send -condition 1 sa0sx.SX_DB1_quad_send
fxp_assert -name neverX_SX_DB1_quad_fgcg -condition 1 sa0sx.SX_DB1_quad_fgcg
fxp_assert -name neverX_SX_DB1_quad_format -condition sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[1] sa0sx.SX_DB1_quad_format
fxp_assert -name neverX_SX_DB1_quad_context_id -condition sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[1] sa0sx.SX_DB1_quad_context_id
fxp_assert -name neverX_SX_DB1_quad_pix_enable -condition sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[1] sa0sx.SX_DB1_quad_pix_enable
fxp_assert -name neverX_SX_DB1_quad_exp_enable -condition sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[1] sa0sx.SX_DB1_quad_exp_enable
fxp_assert -name neverX_SX_DB1_quad_blend_bypass -condition sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[1] sa0sx.SX_DB1_quad_blend_bypass
fxp_assert -name neverX_SX_DB1_quad_dont_rd_dest -condition sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[1] sa0sx.SX_DB1_quad_dont_rd_dest
fxp_assert -name neverX_SX_DB1_quad_data -condition sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[1] sa0sx.SX_DB1_quad_data
fxp_assert -name neverX_SX_DB1_quad_mrt -condition sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[1] sa0sx.SX_DB1_quad_mrt
fxp_assert -name neverX_SX_DB1_quad_wave_id -condition sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[1] sa0sx.SX_DB1_quad_wave_id
fxp_assert -name neverX_SX_DB1_quad_last_export_of_mrt -condition sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[1] sa0sx.SX_DB1_quad_last_export_of_mrt
fxp_assert -name neverX_SX_DB1_quad_last_mrt_of_wave -condition sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[1] sa0sx.SX_DB1_quad_last_mrt_of_wave
fxp_assert -name neverX_SX_PA_pos_send -condition 1 sa0sx.SX_PA_pos_send
fxp_assert -name neverX_SX_PA_pos_fgcg -condition 1 sa0sx.SX_PA_pos_fgcg
fxp_assert -name neverX_SX_PA_pos_data0 -condition 1 sa0sx.SX_PA_pos_data0
fxp_assert -name neverX_SX_PA_pos_data1 -condition 1 sa0sx.SX_PA_pos_data1
fxp_assert -name neverX_SX_PA_pos_data2 -condition 1 sa0sx.SX_PA_pos_data2
fxp_assert -name neverX_SX_PA_pos_data3 -condition 1 sa0sx.SX_PA_pos_data3
fxp_assert -name neverX_PA_SX_req_free -condition 1 sa0sx.PA_SX_req_free
fxp_assert -name neverX_SX_SPI_db_scbd1_free -condition 1 sa0sx.SX_SPI_db_scbd1_free
fxp_assert -name neverX_SX_SPI_pos_scbd_free -condition 1 sa0sx.SX_SPI_pos_scbd_free
fxp_assert -name neverX_SX_SPI_idx_scbd_free -condition 1 sa0sx.SX_SPI_idx_scbd_free
fxp_assert -name neverX_SX_SPI_db0_free -condition 1 sa0sx.SX_SPI_db0_free
fxp_assert -name neverX_SX_SPI_db0_num -condition sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[0] sa0sx.SX_SPI_db0_num
fxp_assert -name neverX_SX_SPI_db0_bus_id -condition sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[0] sa0sx.SX_SPI_db0_bus_id
fxp_assert -name neverX_SX_SPI_db1_free -condition 1 sa0sx.SX_SPI_db1_free
fxp_assert -name neverX_SX_SPI_db1_num -condition sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[1] sa0sx.SX_SPI_db1_num
fxp_assert -name neverX_SX_SPI_db1_bus_id -condition sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[1] sa0sx.SX_SPI_db1_bus_id
fxp_assert -name neverX_SX_SPI_pos_free -condition 1 sa0sx.SX_SPI_pos_free
fxp_assert -name neverX_SX_SPI_idx_free -condition 1 sa0sx.SX_SPI_idx_free
fxp_assert -name neverX_SX_SX_pm_out_bus -condition 1 sa0sx.SX_SX_pm_out_bus

fxp_assert -name neverX_sa1_SX_SX_expcmd0_out_valid -condition 1 sa1sx.SX_SX_expcmd0_out_valid
fxp_assert -name neverX_sa1_SX_SX_expcmd0_out_fgcg -condition 1 sa1sx.SX_SX_expcmd0_out_fgcg
fxp_assert -name neverX_sa1_SX_SX_expcmd0_out_wave64 -condition 1 sa1sx.SX_SX_expcmd0_out_wave64
fxp_assert -name neverX_sa1_SX_SX_expcmd0_out_wave_type -condition 1 sa1sx.SX_SX_expcmd0_out_wave_type
fxp_assert -name neverX_sa1_SX_SX_expcmd0_out_base_addr0 -condition 1 sa1sx.SX_SX_expcmd0_out_base_addr0
fxp_assert -name neverX_sa1_SX_SX_expcmd0_out_qd_type -condition 1 sa1sx.SX_SX_expcmd0_out_qd_type
fxp_assert -name neverX_sa1_SX_SX_expcmd0_out_qd_mask -condition 1 sa1sx.SX_SX_expcmd0_out_qd_mask
fxp_assert -name neverX_sa1_SX_SX_expcmd0_out_scorebd_type -condition 1 sa1sx.SX_SX_expcmd0_out_scorebd_type
fxp_assert -name neverX_sa1_SX_SX_expcmd0_out_simd_id -condition 1 sa1sx.SX_SX_expcmd0_out_simd_id
fxp_assert -name neverX_sa1_SX_SX_expcmd0_out_cleanup -condition 1 sa1sx.SX_SX_expcmd0_out_cleanup
fxp_assert -name neverX_sa1_SX_SX_expcmd0_out_last_quad -condition 1 sa1sx.SX_SX_expcmd0_out_last_quad
fxp_assert -name neverX_sa1_SX_SX_expcmd0_out_target -condition 1 sa1sx.SX_SX_expcmd0_out_target
fxp_assert -name neverX_sa1_SX_SX_expcmd0_out_target_comp -condition 1 sa1sx.SX_SX_expcmd0_out_target_comp
fxp_assert -name neverX_sa1_SX_SX_expcmd0_out_done -condition 1 sa1sx.SX_SX_expcmd0_out_done
fxp_assert -name neverX_sa1_SX_SX_expcmd0_out_last -condition 1 sa1sx.SX_SX_expcmd0_out_last
fxp_assert -name neverX_sa1_SX_SX_expcmd0_out_state_id -condition 1 sa1sx.SX_SX_expcmd0_out_state_id
fxp_assert -name neverX_sa1_SX_SX_expcmd0_out_pipe_id -condition 1 sa1sx.SX_SX_expcmd0_out_pipe_id
fxp_assert -name neverX_sa1_SX_SX_expcmd0_out_row_id -condition 1 sa1sx.SX_SX_expcmd0_out_row_id
fxp_assert -name neverX_sa1_SX_SX_expvdata0_out_fgcg -condition 1 sa1sx.SX_SX_expvdata0_out_fgcg
fxp_assert -name neverX_sa1_SX_SX_expvdata0_out_fgcg_dup -condition 1 sa1sx.SX_SX_expvdata0_out_fgcg_dup
fxp_assert -name neverX_sa1_SX_SX_expvdata0_out_valid -condition 1 sa1sx.SX_SX_expvdata0_out_valid
fxp_assert -name neverX_sa1_SX_SX_expvdata0_out_wr_en -condition 1 sa1sx.SX_SX_expvdata0_out_wr_en
fxp_assert -name neverX_sa1_SX_SX_expvdata0_out_data -condition 1 sa1sx.SX_SX_expvdata0_out_data
fxp_assert -name neverX_sa1_SX_DB0_quad_send -condition 1 sa1sx.SX_DB0_quad_send
fxp_assert -name neverX_sa1_SX_DB0_quad_fgcg -condition 1 sa1sx.SX_DB0_quad_fgcg
fxp_assert -name neverX_sa1_SX_DB0_quad_format -condition sx.sa1sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[2] sa1sx.SX_DB0_quad_format
fxp_assert -name neverX_sa1_SX_DB0_quad_context_id -condition sx.sa1sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[2] sa1sx.SX_DB0_quad_context_id
fxp_assert -name neverX_sa1_SX_DB0_quad_pix_enable -condition sx.sa1sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[2] sa1sx.SX_DB0_quad_pix_enable
fxp_assert -name neverX_sa1_SX_DB0_quad_exp_enable -condition sx.sa1sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[2] sa1sx.SX_DB0_quad_exp_enable
fxp_assert -name neverX_sa1_SX_DB0_quad_blend_bypass -condition sx.sa1sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[2] sa1sx.SX_DB0_quad_blend_bypass
fxp_assert -name neverX_sa1_SX_DB0_quad_dont_rd_dest -condition sx.sa1sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[2] sa1sx.SX_DB0_quad_dont_rd_dest
fxp_assert -name neverX_sa1_SX_DB0_quad_data -condition sx.sa1sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[2] sa1sx.SX_DB0_quad_data
fxp_assert -name neverX_sa1_SX_DB0_quad_mrt -condition sx.sa1sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[2] sa1sx.SX_DB0_quad_mrt
fxp_assert -name neverX_sa1_SX_DB0_quad_wave_id -condition sx.sa1sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[2] sa1sx.SX_DB0_quad_wave_id
fxp_assert -name neverX_sa1_SX_DB0_quad_last_export_of_mrt -condition sx.sa1sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[2] sa1sx.SX_DB0_quad_last_export_of_mrt
fxp_assert -name neverX_sa1_SX_DB0_quad_last_mrt_of_wave -condition sx.sa1sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[2] sa1sx.SX_DB0_quad_last_mrt_of_wave
fxp_assert -name neverX_sa1_SX_DB1_quad_send -condition 1 sa1sx.SX_DB1_quad_send
fxp_assert -name neverX_sa1_SX_DB1_quad_fgcg -condition 1 sa1sx.SX_DB1_quad_fgcg
fxp_assert -name neverX_sa1_SX_DB1_quad_format -condition sx.sa1sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[3] sa1sx.SX_DB1_quad_format
fxp_assert -name neverX_sa1_SX_DB1_quad_context_id -condition sx.sa1sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[3] sa1sx.SX_DB1_quad_context_id
fxp_assert -name neverX_sa1_SX_DB1_quad_pix_enable -condition sx.sa1sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[3] sa1sx.SX_DB1_quad_pix_enable
fxp_assert -name neverX_sa1_SX_DB1_quad_exp_enable -condition sx.sa1sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[3] sa1sx.SX_DB1_quad_exp_enable
fxp_assert -name neverX_sa1_SX_DB1_quad_blend_bypass -condition sx.sa1sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[3] sa1sx.SX_DB1_quad_blend_bypass
fxp_assert -name neverX_sa1_SX_DB1_quad_dont_rd_dest -condition sx.sa1sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[3] sa1sx.SX_DB1_quad_dont_rd_dest
fxp_assert -name neverX_sa1_SX_DB1_quad_data -condition sx.sa1sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[3] sa1sx.SX_DB1_quad_data
fxp_assert -name neverX_sa1_SX_DB1_quad_mrt -condition sx.sa1sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[3] sa1sx.SX_DB1_quad_mrt
fxp_assert -name neverX_sa1_SX_DB1_quad_wave_id -condition sx.sa1sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[3] sa1sx.SX_DB1_quad_wave_id
fxp_assert -name neverX_sa1_SX_DB1_quad_last_export_of_mrt -condition sx.sa1sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[3] sa1sx.SX_DB1_quad_last_export_of_mrt
fxp_assert -name neverX_sa1_SX_DB1_quad_last_mrt_of_wave -condition sx.sa1sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[3] sa1sx.SX_DB1_quad_last_mrt_of_wave
fxp_assert -name neverX_sa1_SX_SPI_db_scbd1_free -condition 1 sa1sx.SX_SPI_db_scbd1_free
fxp_assert -name neverX_sa1_SX_SPI_db0_free -condition 1 sa1sx.SX_SPI_db0_free
fxp_assert -name neverX_sa1_SX_SPI_db0_num -condition sx.sa1sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[2] sa1sx.SX_SPI_db0_num
fxp_assert -name neverX_sa1_SX_SPI_db0_bus_id -condition sx.sa1sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[2] sa1sx.SX_SPI_db0_bus_id
fxp_assert -name neverX_sa1_SX_SPI_db1_free -condition 1 sa1sx.SX_SPI_db1_free
fxp_assert -name neverX_sa1_SX_SPI_db1_num -condition sx.sa1sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[3] sa1sx.SX_SPI_db1_num
fxp_assert -name neverX_sa1_SX_SPI_db1_bus_id -condition sx.sa1sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask[3] sa1sx.SX_SPI_db1_bus_id
}
#fvcover sx_sanity -expr { SA1SX_DB1_quad_send==1 }  #fvcover FXP not support?

#following properies are used to make sure constraints are right. old version does not support fvcover for FXP. 2022.06-SP2 does.
if { 0 } {
fxp_assert -name sa0_format sa0sx.usx_color_export.u0_sx_color_dbif.format_7_to_6_single_quad
fvcover cov_mask0 -expr { sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask == 4'h0 }
fvcover cov_mask1 -expr { sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask == 4'h1 }
fvcover cov_mask2 -expr { sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask == 4'h2 }
fvcover cov_mask3 -expr { sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask == 4'h3 }
fvcover cov_mask4 -expr { sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask == 4'h4 }
fvcover cov_mask5 -expr { sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask == 4'h5 }
fvcover cov_mask6 -expr { sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask == 4'h6 }
fvcover cov_mask7 -expr { sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask == 4'h7 }
fvcover cov_mask8 -expr { sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask == 4'h8 }
fvcover cov_mask9 -expr { sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask == 4'h9 }
fvcover cov_maska -expr { sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask == 4'ha }
fvcover cov_maskb -expr { sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask == 4'hb }
fvcover cov_maskc -expr { sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask == 4'hc }
fvcover cov_maskd -expr { sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask == 4'hd }
fvcover cov_maske -expr { sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask == 4'he }
fvcover cov_maskF -expr { sx.sa0sx.usx_ati_rb_backend_cfg_reg.rb_active_pipe_mask == 4'hF }
}

check_fv

