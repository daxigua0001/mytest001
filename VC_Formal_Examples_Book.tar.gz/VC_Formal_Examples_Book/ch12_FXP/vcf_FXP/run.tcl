set_fml_appmode FXP

set design soc 

set_blackbox -designs {uart timer}

read_file -top $design -format sverilog -sva -vcs {-f ./riscv.f}
#read_file -top $design -format sverilog -sva -vcs {-f ./riscv.f +define+FXP_BUG_FIX}

##############################################
set_constant -value 0 { u_csr.cfg_xfence_uart0 } 
set_constant -value 0 { u_csr.cfg_xfence_uart1 } 
set_constant -value 0 { u_csr.cfg_xfence_timer } 

##############################################333
create_clock clk -period 100
create_reset rst_n -sense low

sim_run -stable
sim_save_reset

##############################################
fxp_generate -type {bbout oba undef undriven uninit xassign unresin }

#check if x-prop
fxp_assert -name neverX_wb_ack_s2    u_wb_interconnect.wb_ack_s2
fxp_assert -name neverX_wb_err_s2    u_wb_interconnect.wb_err_s2
fxp_assert -name neverX_wb_rdata_s2  u_wb_interconnect.wb_rdata_s2

fxp_assert -name neverX_wb_ack_s3    u_wb_interconnect.wb_ack_s3
fxp_assert -name neverX_wb_err_s3    u_wb_interconnect.wb_err_s3
fxp_assert -name neverX_wb_rdata_s3  u_wb_interconnect.wb_rdata_s3

fxp_assert -name neverX_wb_ack_s6    u_wb_interconnect.wb_ack_s6
fxp_assert -name neverX_wb_err_s6    u_wb_interconnect.wb_err_s6
fxp_assert -name neverX_wb_rdata_s6  u_wb_interconnect.wb_rdata_s6

fxp_assert -name neverX_cpu_irq   u_cpu.cpu_irq

#following properies are used to make sure constraints are right. old version does not support fvcover for FXP. 2022.06-SP2 does.
if { 0 } {

fxp_assert -name noX_1 u0_timer.IRQ
fxp_assert -name noX_2 wb_err_uart0
fxp_assert -name noX_3 wb_err_uart1

}

########################################################
## Proof
########################################################
check_fv -block 

