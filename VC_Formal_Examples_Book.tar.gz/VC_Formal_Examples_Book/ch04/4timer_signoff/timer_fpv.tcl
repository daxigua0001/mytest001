set_fml_appmode FPV

set design timer 

# Enable Formal Signoff metrics
signoff_config -type all

# Compilation Step 
read_file -cov all -top $design -format sverilog -sva -vcs {-f timer.f}

# Clock Definitions 
create_clock PCLK -period 100

# Reset Definitions 
create_reset PRESETn -sense low 

# Initialisation Commands 
sim_run -stable
sim_save_reset

fvcover test -expr {counter==32'hff}
#fvcover test2 -expr {write_en&(PADDR[3:0]==0)&(&PWDATA)) ##1 read_en }

# Set Max Run Time
set_fml_var fml_max_time 5M

# Proof
check_fv -block 

# Reports
report_fv -list > results.txt
