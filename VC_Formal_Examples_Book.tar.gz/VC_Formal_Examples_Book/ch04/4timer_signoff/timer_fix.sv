`define CSR_RELOAD_VALUE_ADDR 0 
`define CSR_CURRENT_VALUE_ADDR 1
`define CSR_TIMER_CTRL_ADDR 2
`define CSR_INTERRUPT_ADDR 3 

module timer
#(
    parameter APB_ADDR_WIDTH = 12  //APB slaves are 4KB by default
)
(
    input  reg                      PCLK,
    input  reg                      PRESETn,
    input  reg [APB_ADDR_WIDTH-1:0] PADDR,
    input  reg               [31:0] PWDATA,
    input  reg                      PWRITE,
    input  reg                      PSEL,
    input  reg                      PENABLE,
    output reg               [31:0] PRDATA,
    output reg                      PREADY,
    output reg                      IRQ// interrupt
);

    // always ready to capture the data into the timer, assume never transfare failure
    assign PREADY  = 1'b1;
    wire read_en=PSEL && PENABLE && !PWRITE &&(PADDR[APB_ADDR_WIDTH-1:4]==0) ;
    wire write_en=PSEL && PENABLE && PWRITE;

    
    // Control and State registers for this timer
    
    reg  [31:0]  csr_regs [0:3];

  always @(posedge PCLK or negedge PRESETn)
  begin
    if (~PRESETn)
      csr_regs[`CSR_RELOAD_VALUE_ADDR] <= 32'h0000_0000;
    else if (write_en && (PADDR[3:0]=={`CSR_RELOAD_VALUE_ADDR,2'b00}))
      csr_regs[`CSR_RELOAD_VALUE_ADDR] <= PWDATA;
  end
  always @(posedge PCLK or negedge PRESETn)
  begin
    if (~PRESETn)
      csr_regs[`CSR_CURRENT_VALUE_ADDR] <= 32'h0000_0000;
    else if (write_en && (PADDR[3:0]=={`CSR_CURRENT_VALUE_ADDR,2'b00}))
      csr_regs[`CSR_CURRENT_VALUE_ADDR] <= PWDATA;
  end  
  always @(posedge PCLK or negedge PRESETn)
  begin
    if (~PRESETn)
      csr_regs[`CSR_RELOAD_VALUE_ADDR] <= 32'h0000_0000;
    else if (write_en && (PADDR[3:0]=={`CSR_RELOAD_VALUE_ADDR,2'b00}))
      csr_regs[`CSR_RELOAD_VALUE_ADDR] <= PWDATA;
  end
  always @(posedge PCLK or negedge PRESETn)
  begin
    if (~PRESETn)
      csr_regs[`CSR_TIMER_CTRL_ADDR] <= 32'h0000_0000;
    else if (write_en && (PADDR[3:0]=={`CSR_TIMER_CTRL_ADDR,2'b00}))
      csr_regs[`CSR_TIMER_CTRL_ADDR][0] <= PWDATA[0];
  end  

 always @(posedge PCLK or negedge PRESETn)
  begin
    if (~PRESETn)
      PRDATA <= 32'h0000_0000;
    else if (read_en )
      case(PADDR[3:0])
          {`CSR_RELOAD_VALUE_ADDR,2'b00}:
        PRDATA<= csr_regs[`CSR_RELOAD_VALUE_ADDR];
          {`CSR_CURRENT_VALUE_ADDR,2'b00}:
        PRDATA<= csr_regs[`CSR_CURRENT_VALUE_ADDR];
          {`CSR_TIMER_CTRL_ADDR,2'b00}:
        PRDATA<= csr_regs[`CSR_TIMER_CTRL_ADDR];//bit 0 is valid for timer enable
          {`CSR_INTERRUPT_ADDR,2'b00}:
        PRDATA<= csr_regs[`CSR_INTERRUPT_ADDR]; //bit 0 is valid for interrupt enable
      endcase
  end



  //timer counter 
  reg [31:0] counter;

  wire enable_timer= csr_regs[`CSR_TIMER_CTRL_ADDR][0];
  wire wr_reload = write_en&(PADDR[3:0]=={`CSR_RELOAD_VALUE_ADDR,2'b00});
  wire counter_eq0=  enable_timer&&(counter==32'h0000_0000);
  always @(posedge PCLK or negedge PRESETn)
  begin
    if (~PRESETn)
      counter <= 32'h0000_0000;
    else if (wr_reload)
      counter <= PWDATA;      
    else if (counter_eq0)
      counter <= csr_regs[`CSR_RELOAD_VALUE_ADDR];
    else if (enable_timer)
      counter <= counter -32'h0000_0001;
  end

  // Trigger an interrupt when decrement to 0 and interrupt enabled
  // and hold it until clear by software
  wire dec_ctrl=1'b1 ; //fixme
  wire timer_interrupt_set= (timer_enable & csr_regs[`CSR_INTERRUPT_ADDR][0] & (counter==32'h00000001));
  wire timer_interrupt_clear= write_en&(PADDR[3:0]== {`CSR_INTERRUPT_ADDR,2'b00}) & PWDATA[0];
  reg timer_interrupt;

  // Registering interrupt output
  always @(posedge PCLK or negedge PRESETn)
  begin
    if (~PRESETn)
      timer_interrupt <= 1'b0;
    else if (timer_interrupt_set|timer_interrupt_clear)
      timer_interrupt <= timer_interrupt_set;
  end

  always @(posedge PCLK or negedge PRESETn)
  begin
    if (~PRESETn)
      IRQ <= 1'b0;
    else if (IRQ)
      IRQ <= 1'b0;
    else if (timer_interrupt_set)
      IRQ <= 1'b1;
  end  


endmodule
