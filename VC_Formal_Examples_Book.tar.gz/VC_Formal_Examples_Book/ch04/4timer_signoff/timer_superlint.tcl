clear -all
check_superlint -init
#config_rtlds -rule -disable -domain {LINT DFT AUTO_FORMAL}
#config_rtlds -rule -enable -tag {INT_NR_OVFL}

analyze -clear
analyze -sv09 timer.sv 
elaborate
check_superlint -extract

#elaborate -bbox_a 1024

# Setup clocks and reset
clock PCLK 
reset {~PRESETn}

# Extract the checks 
check_superlint -extract

cover -name IRQ_active {IRQ ==1'b1}

check_superlint -prove
