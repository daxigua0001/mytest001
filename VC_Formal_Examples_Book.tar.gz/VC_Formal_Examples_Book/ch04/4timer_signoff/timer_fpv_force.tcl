set_fml_appmode FPV

set design timer 

# Enable Formal Signoff metrics
signoff_config -type all

# Compilation Step 
read_file -cov all -top $design -format sverilog -sva -vcs {-f timer.f}

# Clock Definitions 
create_clock PCLK -period 100

# Reset Definitions 
create_reset PRESETn -sense low 

# Initialisation Commands 
sim_run -stable
#sim_force counter -apply 32'hffff_ffff
sim_save_reset

# Set Max Run Time
set_fml_var fml_max_time 5M

# Proof
check_fv -block 

# Reports
report_fv -list > results.txt
