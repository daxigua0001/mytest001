module timer_assume
#(
    parameter APB_ADDR_WIDTH = 12  //APB slaves are 4KB by default
)
(
    input  reg                      PCLK,
    input  reg                      PRESETn,
    input  reg [APB_ADDR_WIDTH-1:0] PADDR,
    input  reg               [31:0] PWDATA,
    input  reg                      PWRITE,
    input  reg                      PSEL,
    input  reg                      PENABLE
);

endmodule
bind timer timer_assume u_timer_assume(.*);


