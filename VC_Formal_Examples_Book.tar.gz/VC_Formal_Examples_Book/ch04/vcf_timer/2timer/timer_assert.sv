module timer_assert(
   input                                  PCLK,
   input                                  PRESETn,
   input [31:0] counter,
   input IRQ,
   input wr_reload
   );



cover_IRQ_active: cover property ( @(posedge PCLK) disable iff (~PRESETn) 
    counter == 32'h1 ##1 IRQ==1 
);


assert_counter_never_out_range: assert property ( @(posedge PCLK) disable iff (~PRESETn)
    !(counter<0 || counter>timer.csr_regs_reload)
);
assert_counter_eq0_if_IRQ_active: assert property ( @(posedge PCLK) disable iff (~PRESETn)
    IRQ |-> counter==32'h0000_0000
);


assert_counter_stable_if_disble_timer: assert property ( @(posedge PCLK) disable iff (~PRESETn)
                          ~(timer.csr_regs_ctrl[0] | wr_reload) |=> $stable(counter)
);

reg [31:0] counter_irq_distance;
always @(posedge PCLK)
if(~PRESETn)
        counter_irq_distance<='h0;
else if(IRQ)
        counter_irq_distance<='h0;
else
        counter_irq_distance<=counter_irq_distance+'h1;

assert_IRQ_distance_should_be_ge_reload_val:assert property ( @(posedge PCLK) disable iff (~PRESETn)
    IRQ |-> counter_irq_distance >= timer.csr_regs_reload 
);

assert_no_irq_if_disable_timer : assert property ( @(posedge PCLK) disable iff (~PRESETn)
    ~timer.enable_timer |=> ~timer.IRQ
);
assert_counter_reload_when_counter_eq0 : assert property ( @(posedge PCLK) disable iff (~PRESETn)
    ((timer.counter==0) && timer.enable_timer) |=> timer.counter == timer.csr_regs_reload 
);


endmodule
bind timer timer_assert u_timer_assert(.*);



