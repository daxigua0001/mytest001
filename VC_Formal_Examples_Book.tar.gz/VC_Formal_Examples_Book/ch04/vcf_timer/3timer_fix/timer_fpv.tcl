set_fml_appmode FPV

set design timer 

# Compilation Step 
read_file -top $design -format sverilog -sva -vcs {-f timer.f}

# Clock Definitions 
create_clock PCLK -period 100

# Reset Definitions 
create_reset PRESETn -sense low 

# Initialisation Commands 
sim_run -stable
sim_save_reset

# Set Max Run Time
set_fml_var fml_max_time 5M

# Proof
check_fv -block 

# Reports
report_fv -list > results.txt
