

`define CSR_RELOAD_VALUE_ADDR 0 
`define CSR_CURRENT_VALUE_ADDR 1
`define CSR_TIMER_CTRL_ADDR 2
`define CSR_INTERRUPT_ADDR 3 
module timer_assert(
   input                                  PCLK,
   input                                  PRESETn,
   input [31:0] counter,
   input IRQ,
   input wr_reload
   );



cover_IRQ_active: cover property ( @(posedge PCLK) disable iff (~PRESETn) 
    counter == 32'h1 ##1 IRQ==1 
);


assert_counter_never_out_range: assert property ( @(posedge PCLK) disable iff (~PRESETn)
    !(counter<0 || counter>timer.csr_regs_reload)
);
assert_counter_eq0_if_IRQ_active: assert property ( @(posedge PCLK) disable iff (~PRESETn)
    IRQ |-> counter==32'h0000_0000
);


assert_counter_stable_if_disble_timer: assert property ( @(posedge PCLK) disable iff (~PRESETn)
    ~(timer.csr_regs_ctrl[0] | wr_reload) |=> $stable(counter)
);

bit [31:0] counter_irq_distance;
bit had_IRQ;
always @(posedge PCLK)
if(IRQ)
    counter_irq_distance<='h0;
else
    counter_irq_distance<=counter_irq_distance+'h1;

always @(posedge PCLK or negedge PRESETn)
if(~PRESETn)
    had_IRQ<=1'b0;
else if(IRQ)
    had_IRQ<=1'b1;
        
assert_IRQ_distance_should_be_ge_reload_val:assert property ( @(posedge PCLK) disable iff (~PRESETn)
    had_IRQ&IRQ |-> counter_irq_distance >= timer.csr_regs_reload 
);

//assume_IRQ_distance_lt_100_reload_val:assume property ( @(posedge PCLK) disable iff (~PRESETn)
//    counter_irq_distance <100
//);

assert_no_irq : assert property ( @(posedge PCLK) disable iff (~PRESETn)
    ~timer.enable_timer |=> ~timer.IRQ
);
assert_0_to_reload : assert property ( @(posedge PCLK) disable iff (~PRESETn)
    ((timer.counter==0) && timer.enable_timer) |=> timer.counter == timer.csr_regs_reload 
);


endmodule
bind timer timer_assert u_timer_assert(.*);



