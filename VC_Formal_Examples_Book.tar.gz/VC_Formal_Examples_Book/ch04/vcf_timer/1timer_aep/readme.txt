timer_aep.tcl is for running VC formal AEP check
timer_aep_fix.tcl is for running fixed RTL version

run AEP check for timer.sv first with following command:
vcf -f timer_aep.tcl -gui &
run AEP check for timer_fix.sv with following command:
vcf -f timer_aep.tcl -gui &

To clean up , use:
rm -rf vcf* vcst* verdi* elab_summary* novas.*
