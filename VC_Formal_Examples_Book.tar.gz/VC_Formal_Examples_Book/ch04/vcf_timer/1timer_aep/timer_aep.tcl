set_fml_appmode AEP

set design timer 

read_file -top $design -format verilog \
-aep all -vcs {timer.sv}

create_clock PCLK -period 100 
create_reset PRESETn -sense low

sim_run -stable 
sim_save_reset

check_fv
