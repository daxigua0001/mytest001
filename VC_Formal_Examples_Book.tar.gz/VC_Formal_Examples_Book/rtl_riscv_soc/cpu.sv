
module cpu(
    input clk,
    input rst_n,

    input cpu_irq,

  // wishbone bus master
    output  [31:0] wb_addr,
    output  [31:0] wb_wdata,
    output  [3:0]  wb_sel,
    output         wb_we,
    output         wb_stb,
    output         wb_cyc,
    input [31:0]   wb_rdata,
    input          wb_ack,
    input          wb_err,

  //dbg output
    output [7:0]   cpu_dbg_out
);

// ==== Parameter  ====

//OPCODE
localparam    OP_ARITH_R      = 7'b0110011;   // rd <- rs1 OP rs2
localparam    OP_ARITH_I      = 7'b0010011;   // rd <- rs1 OP Iimm
localparam    OP_BRANCH       = 7'b1100011;   // if(rs1 OP rs2) PC<-PC+Bimm
localparam    OP_JAL          = 7'b1101111;   // rd <- PC+4; PC<-PC+Jimm
localparam    OP_JALR         = 7'b1100111;   // rd <- PC+4; PC<-rs1+Iimm
localparam    OP_LOAD         = 7'b0000011;   // rd <- mem[rs1+Iimm]
localparam    OP_STORE        = 7'b0100011;   // mem[rs1+Simm] <- rs2
localparam    OP_LUI          = 7'b0110111;   // rd <- Uimm
localparam    OP_AUIPC        = 7'b0010111;   // rd <- PC + Uimm
localparam    OP_SYSTEM       = 7'b1110011;   // rd <- CSR <- rs1/uimm5
localparam    OP_INVALID      = 7'b1111111;

//wishbone command
localparam    WB_NO    = 2'b00;
localparam    WB_READ    = 2'b01;
localparam    WB_WRITE   = 2'b10;

// Arithmetic and Branch of FUNCT3 
localparam    F3_ARITH_ADDSUB     = 3'b000;
localparam    F3_ARITH_SHIFTL     = 3'b001;
localparam    F3_ARITH_SHIFTR     = 3'b101;
localparam    F3_ARITH_SLT        = 3'b010;
localparam    F3_ARITH_SLTU       = 3'b011;
localparam    F3_ARITH_XOR        = 3'b100;
localparam    F3_ARITH_OR         = 3'b110;
localparam    F3_ARITH_AND        = 3'b111;

//Branch of Func3
localparam    F3_BRANCH_BEQ       = 3'b000;
localparam    F3_BRANCH_BNE       = 3'b001;
localparam    F3_BRANCH_BLT       = 3'b100;
localparam    F3_BRANCH_BGE       = 3'b101;
localparam    F3_BRANCH_BLTU      = 3'b110;
localparam    F3_BRANCH_BGEU      = 3'b111;

//load store type
localparam    F3_MEM_BYTE         = 3'b000;
localparam    F3_MEM_HALF_WORD    = 3'b001;
localparam    F3_MEM_WORD         = 3'b010;

//Func7
localparam    FUNCT7_DEFAULT          = 7'b0;
localparam    FUNCT7_ALT              = 7'b0100000; 

//state
localparam    FETCH         = 5'b00001;
localparam    DECODE        = 5'b00010;
localparam    EXECUTE       = 5'b00100;
localparam    MEM_ACCESS    = 5'b01000;
localparam    TRAP          = 5'b10000;



reg  need_writeback;
reg  [31:0] pc;
reg  do_intr;
reg  [31:0] result_value;
reg  [31:0] load_value;
reg  [31:0] pc_next;
reg  bus_busy;

reg  [4:0]    state;
reg  [31:0] instr;  // current instruction

reg  branch_type;

// Wishbone bus interface 
reg [31:0] bus_rdata;
reg [31:0] bus_wdata;
reg [3:0]  bus_wmask;
reg [31:0] bus_addr;
reg [1:0]  bus_command;

wire  bus_error;

// x0-x31
reg   [31:0] regs [31:0];

reg [31:0] rs1_data;
reg [31:0] rs2_data;
reg   cpu_irq_detect;

// ================= RTL =====================

//debug signals
assign  cpu_dbg_out = {2'b0,rst_n,state[4:0]};

//instruction decode
wire [4:0] instr_rs1 = instr[19:15];
wire [4:0] instr_rs2 = instr[24:20];
wire [4:0] instr_rd = instr[11:7];
wire [4:0] instr_shamt = instr[24:20];
wire [2:0] instr_func3 = instr[14:12];
wire instr_mem_signed = ~instr_func3[2];
wire instr_csr_use_imm = instr_func3[2];
wire [11:0] instr_csr_addr = instr[31:20];

reg [6:0]  instr_op;
always @(*) begin
    case(instr[6:0])
        7'b0110011: instr_op= OP_ARITH_R;
        7'b0010011: instr_op= OP_ARITH_I;
        7'b1100011: instr_op= OP_BRANCH;
        7'b1101111: instr_op= OP_JAL;
        7'b1100111: instr_op= OP_JALR;
        7'b0000011: instr_op= OP_LOAD;
        7'b0100011: instr_op= OP_STORE;
        7'b0110111: instr_op= OP_LUI;
        7'b0010111: instr_op= OP_AUIPC;  
//        7'b1110011: instr_op= OP_SYSTEM;
        default: instr_op= OP_INVALID;  
    endcase
end    

reg [6:0]  bus_rdata_opcode;
always @(*) begin
    case(bus_rdata[6:0])
        7'b0110011: bus_rdata_opcode= OP_ARITH_R;
        7'b0010011: bus_rdata_opcode= OP_ARITH_I;
        7'b1100011: bus_rdata_opcode= OP_BRANCH;
        7'b1101111: bus_rdata_opcode= OP_JAL;
        7'b1100111: bus_rdata_opcode= OP_JALR;
        7'b0000011: bus_rdata_opcode= OP_LOAD;
        7'b0100011: bus_rdata_opcode= OP_STORE;
        7'b0110111: bus_rdata_opcode= OP_LUI;
        7'b0010111: bus_rdata_opcode= OP_AUIPC;  
        7'b1110011: bus_rdata_opcode= OP_SYSTEM;
        default: bus_rdata_opcode= OP_INVALID;  
    endcase
end   



reg [6:0]  instr_func7;
always @(*) begin
    case(instr[31:25])
        7'b0100000: instr_func7= FUNCT7_ALT;
        default: instr_func7= FUNCT7_DEFAULT;
    endcase
end

reg [2:0] instr_func3_branch;
always @(*) begin
    case(instr_func3)
        3'b000: instr_func3_branch= F3_BRANCH_BEQ;
        3'b001: instr_func3_branch= F3_BRANCH_BNE;
        3'b100: instr_func3_branch= F3_BRANCH_BLT;
        3'b101: instr_func3_branch= F3_BRANCH_BGE;
        3'b110: instr_func3_branch= F3_BRANCH_BLTU;
        default: instr_func3_branch= F3_BRANCH_BGEU;  
    endcase
end

reg [2:0] instr_func3_arith;
always @(*) begin
    case(instr_func3)
        3'b000: instr_func3_arith = F3_ARITH_ADDSUB;
        3'b001: instr_func3_arith = F3_ARITH_SHIFTL;
        3'b101: instr_func3_arith = F3_ARITH_SHIFTR;
        3'b010: instr_func3_arith = F3_ARITH_SLT;
        3'b011: instr_func3_arith = F3_ARITH_SLTU;
        3'b100: instr_func3_arith = F3_ARITH_XOR;
        3'b110: instr_func3_arith = F3_ARITH_OR;
        default:instr_func3_arith = F3_ARITH_AND;
    endcase
end    



reg [2:0]  instr_func3_mem;
always @(*) begin
    case(instr_func3[1:0])
        2'b00: instr_func3_mem= F3_MEM_BYTE;
        2'b01: instr_func3_mem= F3_MEM_HALF_WORD;
        default: instr_func3_mem= F3_MEM_WORD;  
    endcase
end


wire op_arith_reg = (instr_op == OP_ARITH_R);
wire op_arith_imm = (instr_op == OP_ARITH_I);
wire op_arith     = (op_arith_reg | op_arith_imm);
wire op_branch    = (instr_op == OP_BRANCH);
wire op_jal       = (instr_op == OP_JAL);
wire op_jalr      = (instr_op == OP_JALR);
wire op_lui       = (instr_op == OP_LUI);
wire op_auipc     = (instr_op == OP_AUIPC);
wire op_load      = (instr_op == OP_LOAD);
wire op_store     = (instr_op == OP_STORE);

// immediate 
wire signed_imm = instr[31];
wire [31:0] imm_I = { (signed_imm ? 21'h1FFFFF : 21'h0), instr[30:20] };
wire [31:0] imm_S = { (signed_imm ? 21'h1FFFFF : 21'h0), instr[30:25], instr[11:8], instr[7] };
`ifndef FPV_BUG_FIX
wire [31:0] imm_B = { (signed_imm ? 20'hFFFF : 20'h0), instr[7], instr[30:25], instr[11:8], 1'b0 };
`else
wire [31:0] imm_B = { (signed_imm ? 20'hFFFFF : 20'h0), instr[7], instr[30:25], instr[11:8], 1'b0 };
`endif
wire [31:0] imm_U = { instr[31:12], 12'h0 };
wire [31:0] imm_J = { (signed_imm ? 12'hFFF : 12'h0), instr[19:12], instr[20], instr[30:25], instr[24:21], 1'b0 };


// Register 
always  @(posedge clk) begin
    if (~rst_n) begin
        integer i;
        for (i = 0; i < 32; i = i + 1)
            regs[i] <= 32'h0;
    end
    else begin
        if (need_writeback) begin
            if (instr_rd != 5'h0) begin
                regs[instr_rd] <= result_value;
            end
        end
    end
end

//writeback logic
always @(*) begin
    need_writeback = 1'b0;

    if (~(op_branch | op_store)) begin
        if (op_load & (state == MEM_ACCESS) & ~bus_busy) begin
            need_writeback = 1'b1;
        end

        if (~op_load & (state == EXECUTE)) begin
            need_writeback = 1'b1;
        end
    end
end


wire [31:0] trap_addr = 32'h0000_0800;
// ==== ALU ====

wire [31:0] alu_src1 = rs1_data;
wire [31:0] alu_src2 = (op_arith_reg | op_branch) ? rs2_data : imm_I;
wire [31:0] arith_add = alu_src1 + alu_src2;


wire  arith_equal = (alu_src1 == alu_src2);


wire is_beq = arith_equal;
wire is_bne = ~arith_equal;
wire is_blt = $signed(alu_src1) < $signed(alu_src2);
wire is_bge = ~is_blt;        //greater than or equal,signed
wire is_bltu = $unsigned(alu_src1) < $unsigned(alu_src2);
wire is_bgeu = ~is_bltu;      //greater than or equal, unsigned

`ifndef FPV_BUG_FIX
wire [31:0] arith_shift_right = ($signed(alu_src1) >> (op_arith_imm ? { 27'h0, instr_shamt } : alu_src2[4:0]));
`else 
wire [31:0] arith_shift_right = ($signed(alu_src1) >>> (op_arith_imm ? { 27'h0, instr_shamt } : alu_src2[4:0]));
`endif
wire [31:0] logic_shift_right = ((alu_src1) >> (op_arith_imm ? { 27'h0, instr_shamt } : alu_src2[4:0]));


reg  [31:0] alu_calc;
// ALU calculation
always @(*) begin
    alu_calc = 32'h0;
    
    case (instr_func3_arith)
        F3_ARITH_ADDSUB: begin
            if (op_arith_reg && (instr_func7 == FUNCT7_ALT)) begin
                alu_calc = alu_src1 - alu_src2;
            end
            else begin
                alu_calc = alu_src1 + alu_src2;
            end
        end
        F3_ARITH_AND: begin
            alu_calc = alu_src1 & alu_src2;
        end
        F3_ARITH_OR: begin
            alu_calc = alu_src1 | alu_src2;
        end
        F3_ARITH_XOR: begin
            alu_calc = alu_src1 ^ alu_src2;
        end
        F3_ARITH_SLT: begin
            alu_calc = ($signed(alu_src1) < $signed(alu_src2)) ? 32'h1 : 32'h0;
        end
        F3_ARITH_SLTU: begin
            alu_calc = ($unsigned(alu_src1) < $unsigned(alu_src2)) ? 32'h1 : 32'h0;
        end
        F3_ARITH_SHIFTL: begin
            alu_calc = alu_src1 << (op_arith_imm ? { 27'h0, instr_shamt } : alu_src2[4:0]);   //note, shift alu_src2 low 5bits
        end
        /* F3_ARITH_SHIFTR */
        default: begin
            if (instr_func7 == FUNCT7_ALT) begin
                alu_calc = arith_shift_right;
            end
            else begin
                alu_calc = logic_shift_right;
            end
        end
    endcase
end

// Writeback value 
always @(*) begin
    result_value = 32'h0;
    
    if((op_arith_imm | op_arith_reg)) begin
        result_value = alu_calc;
    end    
    else if (op_lui) begin
            result_value = imm_U;
        end
    else if (op_auipc) begin
            result_value = pc + imm_U;
        end
    else if (op_jal | op_jalr) begin
            result_value = pc + 32'h4;
        end
    else if (op_load) begin
            result_value = load_value;
        end
    else 
        result_value = 32'h0;
end




wire [31:0] store_data = (op_store & ((state==EXECUTE) | (state ==MEM_ACCESS))) ? rs2_data : 32'h0;

wire [1:0] addr_low_2bits = bus_addr[1:0];
reg        bus_align_err;

always @(*) begin
    bus_wdata = 32'h0;
    bus_wmask = 4'h0;
    bus_align_err = 1'b0;

    case (instr_func3_mem)
        F3_MEM_BYTE: begin
            bus_align_err = 1'b0;

            case (addr_low_2bits)
                2'b00: begin
                    bus_wmask = 4'b0001; 
                    bus_wdata = { 24'h0, store_data[7:0] };
                end
                2'b01: begin
                    bus_wmask = 4'b0010;
                    bus_wdata = { 16'h0, store_data[7:0], 8'h0 };
                end
                2'b10: begin
                    bus_wmask = 4'b0100;
                    bus_wdata = { 8'h0, store_data[7:0], 16'h0 };
                end
                2'b11: begin
                    bus_wmask = 4'b1000; 
                    bus_wdata = { store_data[7:0], 24'h0 };
                end
            endcase
        end
        F3_MEM_HALF_WORD: begin
            bus_align_err = (addr_low_2bits == 2'b01 || addr_low_2bits == 2'b11);

            if (addr_low_2bits == 2'b00) begin
                bus_wmask = 4'b0011;
                bus_wdata = { 16'h0, store_data[15:0] };
            end
            else if (addr_low_2bits == 2'b10) begin
                bus_wmask = 4'b1100;
                bus_wdata = { store_data[15:0], 16'h0 };
            end
        end
        /*F3_MEM_WORD*/
        default: begin  
            bus_wmask = 4'b1111;
            bus_wdata = store_data;
            bus_align_err = (addr_low_2bits != 2'h0) ? 1'b1 : 1'b0;
        end
    endcase
end

wire pc_align_error = (pc[1:0] != 2'b00);

// bus command and bus address logic
always @(*) begin
    bus_command = WB_NO;
    bus_addr = 32'h0;

    if (state ==FETCH) begin
        bus_addr = pc;

        if ((~pc_align_error) && (~cpu_irq_detect)) begin
            bus_command = WB_READ;
        end
    end
    else if ((state==EXECUTE) || (state==MEM_ACCESS)) begin      
        if (op_load) begin
            bus_addr = rs1_data + imm_I;
        end
        else if (op_store) begin
            bus_addr = rs1_data + imm_S;
        end

        if (state == EXECUTE) begin
            if (~bus_align_err) begin
                if (op_load) begin
                    bus_command = WB_READ;
                end
                else if (op_store) begin
                    bus_command = WB_WRITE;
                end
            end
        end
    end
end


//bus interface unit
biu  u_biu(
    .clk(clk),
    .rst_n(rst_n),

    .cmd_in(bus_command),
    .busy_out(bus_busy),
    .rdata_out(bus_rdata),
    .wdata_in(bus_wdata),
    .wmask_in(bus_wmask),
    .addr_in({bus_addr[31:2],2'h0}),
    .err_out(bus_error),

    //wishbone mater
    .wb_addr(wb_addr),
    .wb_wdata(wb_wdata),
    .wb_sel(wb_sel),
    .wb_we(wb_we),
    .wb_stb(wb_stb),
    .wb_cyc(wb_cyc),
    .wb_rdata(wb_rdata),
    .wb_ack(wb_ack),
    .wb_err(wb_err)    
);


always  @(posedge clk or negedge rst_n) begin
    if(~rst_n) begin
        cpu_irq_detect <= 1'b0;
    end
    else if(state == FETCH && cpu_irq_detect) begin
        cpu_irq_detect <= 1'b0;
    end
    else if(cpu_irq) begin
        cpu_irq_detect <= 1'b1;
    end
end
                   
// ==== FSM and program counter ====
always  @(posedge clk or negedge rst_n) begin
    if (~rst_n) begin
        pc <= 32'h0;
        state <= FETCH;
        instr <= 32'h0;
        rs1_data <= 32'h0;
        rs2_data <= 32'h0;
    end
    else begin
        case (state)        
            FETCH: begin
                if (pc_align_error || cpu_irq_detect) begin
                    state <= TRAP;
                end
                else begin
                    state <= DECODE;
                end
            end        
            DECODE: begin
                if (bus_error) begin
                    state <= TRAP;
                end
                else if (~bus_busy) begin
                    if (bus_rdata_opcode == OP_INVALID) begin
                        state <= TRAP;
                    end
                    else begin
                        instr <= bus_rdata;
                        rs1_data <= regs[bus_rdata[19:15]];
                        rs2_data <= regs[bus_rdata[24:20]];
                        state <= EXECUTE;
                    end
                end
            end
            EXECUTE: begin
                if (op_load | op_store) begin
                    if (bus_align_err) begin
                        state <= TRAP;
                    end
                    else begin
                        state <= MEM_ACCESS;
                    end
                end
                else begin
                    state <= FETCH;
                    pc <= pc_next;
                end
            end
            MEM_ACCESS: begin
                if (bus_error) begin
                    state <= TRAP;
                end
                else if (~bus_busy) begin
                    state <= FETCH;
                    pc <= pc_next;
                end
            end
            TRAP: begin
                pc <= trap_addr;    //PC jump to trap_addr 
                state <= FETCH;
            end
            default: begin  //unreachable
                state <= FETCH;
            end
        endcase
    end
end


always @(*) begin
    load_value = 32'h0;
    
    case (instr_func3_mem)
        F3_MEM_BYTE: begin
            case (addr_low_2bits)
                2'b00: begin
                    load_value = { (instr_mem_signed & bus_rdata[7]) ? 24'hFFFFFF : 24'h0, bus_rdata[7:0] };
                end
                2'b01: begin
                    load_value = { (instr_mem_signed & bus_rdata[15]) ? 24'hFFFFFF : 24'h0, bus_rdata[15:8] };
                end
                2'b10: begin
                    load_value = { (instr_mem_signed & bus_rdata[23]) ? 24'hFFFFFF : 24'h0, bus_rdata[23:16] };
                end
                2'b11: begin
                    load_value = { (instr_mem_signed & bus_rdata[31]) ? 24'hFFFFFF : 24'h0, bus_rdata[31:24] };
                end
            endcase
        end
        F3_MEM_HALF_WORD: begin
            if (addr_low_2bits == 2'b00) begin
                `ifndef FPV_BUG_FIX
                load_value = { (instr_mem_signed & bus_rdata[16]) ? 16'hFFFF : 16'h0, bus_rdata[15:0] };
                `else
                load_value = { (instr_mem_signed & bus_rdata[15]) ? 16'hFFFF : 16'h0, bus_rdata[15:0] };
                `endif
            end
            else if (addr_low_2bits == 2'b10) begin
                load_value = { (instr_mem_signed & bus_rdata[31]) ? 16'hFFFF : 16'h0, bus_rdata[31:16] };
            end
        end
        /*F3_MEM_WORD*/
        default: begin // Word access
            load_value = bus_rdata;
        end
    endcase
end


always @(*) begin
    branch_type = 1'b0;
    
    case (instr_func3_branch)
        F3_BRANCH_BEQ: branch_type = is_beq;
        F3_BRANCH_BGE: branch_type = is_bge;
        F3_BRANCH_BGEU:branch_type = is_bgeu;
        F3_BRANCH_BLT: branch_type = is_blt;
        F3_BRANCH_BLTU:branch_type = is_bltu;
        F3_BRANCH_BNE: branch_type = is_bne;
        default: branch_type = 1'b0;
    endcase
end


always @(*) begin
    pc_next = pc + 32'h4;

    case (1'b1)
        (op_jal): begin
            pc_next = pc + imm_J;
        end
        (op_jalr): begin
            `ifndef FPV_BUG_FIX
            pc_next = rs1_data + imm_I;
            `else
            pc_next = ((rs1_data + imm_I) & 32'hffff_fffe);       //bug fix 
            `endif
        end
        (op_branch): begin
            if (branch_type) begin
                pc_next = pc + imm_B;
            end
        end
        default: begin
            pc_next = pc + 32'h4;
        end
    endcase
end


//firstly , make some covers to make sure no over constraint or other env issues
//cover_ADD_instr: cover property (@(posedge clk) disable iff (~rst_n) 
//                ((instr[6:0] == OP_ARITH_I ) && (instr[14:12] == 3'b000) && (state== EXECUTE));
//
//  @(posedge clk) disable iff (~rst_n)
//((instr[6:0] == OP_ARITH_I ) && (instr[14:12] == 3'b000) && state== EXECUTE)
//        |=> regs[instr_r[11:7]] == ($past(imm_I) + $past(regs[instr[19:15]]));


covergroup cg_state @(posedge clk);
coverpoint state {
bins state_execute = {EXECUTE};
bins state_wm = {MEM_ACCESS};
}
endgroup
cg_state inst = new();

cover_state_EXECUTE: cover property ( @(posedge clk) disable iff (~rst_n)
                                      state == EXECUTE 
);
cover_state_MEM_ACCESS: cover property ( @(posedge clk) disable iff (~rst_n)
                                      state == MEM_ACCESS
);


//VCS coverage off
//====================================================
//ASSERTION
//====================================================
//assertion helper code
reg [31:0]  instr_r;
always @(posedge clk) begin
    if (~rst_n) begin
      instr_r <= 32'b0;
    end
    else begin
      instr_r <= instr[31:0];
    end
end

reg [31:0]  pc_r;
always @(posedge clk) begin
    if (~rst_n) begin
      pc_r <= 32'b0;
    end
    else begin
      pc_r <= pc[31:0];
    end
end



//assume_stable_instr: assume property ( 
//  @(posedge clk) disable iff (~rst_n)
//      $stable(instr)
//);


`ifndef FPV_BUG_FIX
assume_no_cpu_irq: assume property (
 @(posedge clk) disable iff (~rst_n)
    cpu_irq== 1'b0
    );
`endif


assume_instr_LUI: assume property ( 
  @(posedge clk) disable iff (~rst_n)
      ((instr[6:0] == OP_LUI) 
       || (instr[6:0] == OP_AUIPC)
       || (instr[6:0] == OP_ARITH_I)
       || (instr[6:0] == OP_JAL)
       || (instr[6:0] == OP_JALR)
       || (instr[6:0] == OP_LOAD)
       || (instr[6:0] == OP_ARITH_R)
       || (instr[6:0] == OP_SYSTEM)
       
       )
       |-> (instr[11:7] != 0)
);

//start comments

//ok
property op_LUI_prop;
  @(posedge clk) disable iff (~rst_n)
(instr[6:0] == OP_LUI) |=> regs[instr_r[11:7]] == {instr_r[31:12],12'h000};
endproperty
assert_LUI: assert property (op_LUI_prop );


property op_AUIPC_prop;
  @(posedge clk) disable iff (~rst_n)
((instr[6:0] == OP_AUIPC) && state== EXECUTE) |=> regs[instr_r[11:7]] == ($past(pc) + {instr_r[31:12],12'h000});
endproperty
assert_AUIPC: assert property (op_AUIPC_prop );


//ok, rd = imm + rs
property op_ADDI_prop;
  @(posedge clk) disable iff (~rst_n)
((instr[6:0] == OP_ARITH_I ) && (instr[14:12] == 3'b000) && state== EXECUTE)
        |=> regs[instr_r[11:7]] == ($past(imm_I) + $past(regs[instr[19:15]]));
endproperty
assert_ADDI: assert property (op_ADDI_prop );

property op_SLTI_prop;
  @(posedge clk) disable iff (~rst_n)
((instr[6:0] == OP_ARITH_I ) && (instr[14:12] == 3'b010) && state== EXECUTE)
        |=> regs[instr_r[11:7]] == ($past($signed(regs[instr[19:15]])) < $past($signed(imm_I))) ? 1'b1  :1'b0;
endproperty
assert_SLTI: assert property (op_SLTI_prop );

property op_SLTIU_prop;
  @(posedge clk) disable iff (~rst_n)
((instr[6:0] == OP_ARITH_I ) && (instr[14:12] == 3'b011) && state== EXECUTE)
        |=> regs[instr_r[11:7]] == ($past($unsigned(regs[instr[19:15]])) < $past($unsigned(imm_I))) ? 1'b1  :1'b0;
endproperty
assert_SLTIU: assert property (op_SLTIU_prop );


property op_ANDI_prop;
  @(posedge clk) disable iff (~rst_n)
((instr[6:0] == OP_ARITH_I ) && (instr[14:12] == 3'b111) && state== EXECUTE)
        |=> regs[instr_r[11:7]] == ($past($signed(regs[instr[19:15]])) & $past($signed(imm_I))) ;
endproperty
assert_ANDI: assert property (op_ANDI_prop );

property op_ORI_prop;
  @(posedge clk) disable iff (~rst_n)
((instr[6:0] == OP_ARITH_I ) && (instr[14:12] == 3'b110) && state== EXECUTE)
        |=> regs[instr_r[11:7]] == ($past($signed(regs[instr[19:15]])) | $past($signed(imm_I))) ;
endproperty
assert_ORI: assert property (op_ORI_prop );


property op_XORI_prop;
  @(posedge clk) disable iff (~rst_n)
((instr[6:0] == OP_ARITH_I ) && (instr[14:12] == 3'b100) && state== EXECUTE)
        |=> regs[instr_r[11:7]] == ($past($signed(regs[instr[19:15]])) ^ $past($signed(imm_I))) ;
endproperty
assert_XORI: assert property (op_XORI_prop );


//shift left logical imm, SHIFTL
property op_SLLI_prop;
  @(posedge clk) disable iff (~rst_n)
((instr[6:0] == OP_ARITH_I ) && (instr[14:12] == 3'b001) && (instr[31:25] ==7'b0) && state== EXECUTE)
        |=> regs[instr_r[11:7]] == $past(regs[instr[19:15]]) << $past(instr[24:20]) ;
endproperty
assert_SLLI: assert property (op_SLLI_prop );


//shift right logical imm, SHIFTR
property op_SRLI_prop;
  @(posedge clk) disable iff (~rst_n)
((instr[6:0] == OP_ARITH_I ) && (instr[14:12] == 3'b101) && (instr[31:25] ==7'b0) && state== EXECUTE)
        |=> regs[instr_r[11:7]] == $past(regs[instr[19:15]]) >> $past(instr[24:20]) ;
endproperty
assert_SRLI: assert property (op_SRLI_prop );


//shift right arith imm, SHIFTR
//property op_SRAI_prop1;
//  @(posedge clk) disable iff (~rst_n)
//((instr[6:0] == OP_ARITH_I ) && (instr[14:12] == 3'b101) && (instr[31:25] ==7'b0100000) && state== EXECUTE)
//        |=> regs[instr_r[11:7]][31] == $past(regs[instr[19:15]][31]);
//endproperty
//assert_SRAI_1: assert property (op_SRAI_prop1 );

property op_SRAI_prop2;
  @(posedge clk) disable iff (~rst_n)
((instr[6:0] == OP_ARITH_I ) && (instr[14:12] == 3'b101) && (instr[31:25] ==7'b0100000) && state== EXECUTE)
  `ifndef ASSERT_BUG_FIX
        |=> $signed({1'b0,regs[instr_r[11:7]][30:0]}) == (($past($signed(regs[instr[19:15]])) >>> $past(instr[24:20])) & 32'h7fff_ffff) ;
  `else
        |=> $signed({1'b0,regs[instr_r[11:7]][30:0]}) == (($past($signed(regs[instr[19:15]])) >>> $past(instr[24:20])) & $signed(32'h7fff_ffff)) ;
  `endif
endproperty
assert_SRAI_2: assert property (op_SRAI_prop2 );
wire signed [30:0] t1,t2,t3;
assign t1 = ($signed(32'h8000_0000) >>>3)&31'h7fff_ffff ;
assign t2 = ($signed(32'h8000_0000)>>>3)&$signed(31'h7fff_ffff);
assign t3 = ($signed(32'h8000_0000) >>>3) ;


property op_SRAI_prop;
  @(posedge clk) disable iff (~rst_n)
((instr[6:0] == OP_ARITH_I ) && (instr[14:12] == 3'b101) && (instr[31:25] ==7'b0100000) && state== EXECUTE)
        |=> $signed(regs[instr_r[11:7]][31:0]) == (($past($signed(regs[instr[19:15]])) >>> $past(instr[24:20]))) ;
endproperty
assert_SRAI: assert property (op_SRAI_prop );




//JAL, PC <- PC+imm_J
property op_JAL_prop1;
  @(posedge clk) disable iff (~rst_n)
((instr[6:0] == 7'b1101111) && state== EXECUTE)
        |=> pc == $past(pc) + $past(imm_J) ;
endproperty
assert_JAL_1: assert property (op_JAL_prop1 );


//JAL, rd <- PC+4
property op_JAL_prop2;     
  @(posedge clk) disable iff (~rst_n)
((instr[6:0] == 7'b1101111) && state== EXECUTE)
        |=> regs[instr_r[11:7]] == $past(pc) + 4 ;
endproperty
assert_JAL_2: assert property (op_JAL_prop2 );



//JALR, PC <- rs1 +imm_J
property op_JALR_prop1;
  @(posedge clk) disable iff (~rst_n)
((instr[6:0] == 7'b1100111) && state== EXECUTE)
        |=> pc == (($past(regs[instr[19:15]]) + $past(imm_I)) & 32'hffff_fffe) ;
endproperty
assert_JALR_1: assert property (op_JALR_prop1 );


//JALR, rd <- PC+4
property op_JALR_prop2;     
  @(posedge clk) disable iff (~rst_n)
((instr[6:0] == 7'b1100111) && state== EXECUTE)
        |=> regs[instr_r[11:7]] == $past(pc) + 4 ;
endproperty
assert_JALR_2: assert property (op_JALR_prop2 );


//helper code for branch operations
wire [31:0] imm_B_ref={{20{instr[31]}},instr[7],instr[30:25],instr[11:8],1'b0};

property op_BEQ_prop;     
  @(posedge clk) disable iff (~rst_n)
((instr[6:0] == 7'b1100011) && (instr[14:12] == 3'b000)  && state== EXECUTE)
        |=> pc == (( $past(regs[instr[19:15]]) == $past(regs[instr[24:20]]) )? ($past(pc) + $past(imm_B_ref)) : ($past(pc)+4));
endproperty
assert_BEQ: assert property (op_BEQ_prop );
//assume_temp: assume property(@(posedge clk) pc+imm_B_ref < 32'h8000_0000);

//BNE
property op_BNE_prop;     
  @(posedge clk) disable iff (~rst_n)
((instr[6:0] == 7'b1100011) && (instr[14:12] == 3'b001)  && state== EXECUTE)
    |=> pc == (( $past(regs[instr[19:15]]) != $past(regs[instr[24:20]]) )? ($past(pc) + $past(imm_B_ref)) : ($past(pc)+4));
endproperty
assert_BNE: assert property (op_BNE_prop );


//BLT
property op_BLT_prop;     
  @(posedge clk) disable iff (~rst_n)
((instr[6:0] == 7'b1100011) && (instr[14:12] == 3'b100)  && state== EXECUTE)
    |=> pc == (( ($past($signed(regs[instr[19:15]]))) < ($past($signed(regs[instr[24:20]]))) )? ($past(pc) + $past(imm_B_ref)) : ($past(pc)+4));
endproperty
assert_BLT: assert property (op_BLT_prop );

//BLTU
property op_BLTU_prop;     
  @(posedge clk) disable iff (~rst_n)
((instr[6:0] == 7'b1100011) && (instr[14:12] == 3'b110)  && state== EXECUTE)
    |=> pc == (( ($past($unsigned(regs[instr[19:15]]))) < ($past($unsigned(regs[instr[24:20]]))) )? ($past(pc) + $past(imm_B_ref)) : ($past(pc)+4));
endproperty
assert_BLTU: assert property (op_BLTU_prop );

//BGE
property op_BGE_prop;     
  @(posedge clk) disable iff (~rst_n)
((instr[6:0] == 7'b1100011) && (instr[14:12] == 3'b101)  && state== EXECUTE)
    |=> pc == (( ($past($signed(regs[instr[19:15]]))) >= ($past($signed(regs[instr[24:20]]))) )? ($past(pc) + $past(imm_B_ref)) : ($past(pc)+4));
endproperty
assert_BGE: assert property (op_BGE_prop );


//BGEU
property op_BGEU_prop;     
  @(posedge clk) disable iff (~rst_n)
((instr[6:0] == 7'b1100011) && (instr[14:12] == 3'b111)  && state== EXECUTE)
    |=> pc == (( ($past($unsigned(regs[instr[19:15]]))) >= ($past($unsigned(regs[instr[24:20]]))) )? ($past(pc) + $past(imm_B_ref)) : ($past(pc)+4));
endproperty
assert_BGEU: assert property (op_BGEU_prop );



//SW, store word
//assume no addr align_error
assume_sw : assume property(
    @(posedge clk) disable iff (~rst_n)
((instr[6:0] == 7'b0100011) && (instr[14:12] == 3'b010)  && state== EXECUTE)
    |=> ($past(bus_align_err)==1'b0)
);


//SW
property op_SW_prop;     
  @(posedge clk) disable iff (~rst_n)
((instr[6:0] == 7'b0100011) && (instr[14:12] == 3'b010)  && state== EXECUTE)
    |=> wb_addr == (( ($past(regs[instr[19:15]]))  + $past(imm_S))&32'hFFFFFFFC) ;      //low 2bits tie 0
endproperty
assert_SW: assert property (op_SW_prop );

property op_SW_prop2;     
  @(posedge clk) disable iff (~rst_n)
((instr[6:0] == 7'b0100011) && (instr[14:12] == 3'b010)  && state== EXECUTE)
    |-> ##[1:4] wb_wdata == ( ($past($unsigned(regs[instr[24:20]])))) ;
endproperty
assert_SW2: assert property (op_SW_prop2 );


//SH
assume_SH : assume property(
    @(posedge clk) disable iff (~rst_n)
((instr[6:0] == 7'b0100011) && (instr[14:12] == 3'b001)  && state== EXECUTE)
    |=> ($past(bus_align_err)==1'b0)
);

property op_SH_prop;     
  @(posedge clk) disable iff (~rst_n)
((instr[6:0] == 7'b0100011) && (instr[14:12] == 3'b001)  && state== EXECUTE)
    |=> wb_addr == (( ($past(regs[instr[19:15]]))  + $past(imm_S))&32'hFFFFFFFC) ;      //low 2bits tie 0
endproperty
assert_SH: assert property (op_SH_prop );

//wb_wdata tie some bits 0 according to addr align
//property op_SH_prop2;     
//  @(posedge clk) disable iff (~rst_n)
//((instr[6:0] == 7'b0100011) && (instr[14:12] == 3'b001)  && state== EXECUTE)
//    |-> ##[1:4] wb_wdata == ( ($past($unsigned(regs[instr[24:20]])))) ;
//endproperty
//assert_SH2: assert property (op_SH_prop2 );


//SB
assume_SB : assume property(
    @(posedge clk) disable iff (~rst_n)
((instr[6:0] == 7'b0100011) && (instr[14:12] == 3'b000)  && state== EXECUTE)
    |=> ($past(bus_align_err)==1'b0)
);

property op_SB_prop;     
  @(posedge clk) disable iff (~rst_n)
((instr[6:0] == 7'b0100011) && (instr[14:12] == 3'b000)  && state== EXECUTE)
    |=> wb_addr == (( ($past(regs[instr[19:15]]))  + $past(imm_S))&32'hFFFFFFFC) ;      //low 2bits tie 0
endproperty
assert_SB: assert property (op_SB_prop );




//ADD
property op_ADD_prop;
  @(posedge clk) disable iff (~rst_n)
((instr[6:0] == 7'b0110011) && (instr[14:12] == 3'b000) &&(instr[31:25]==7'b0000000) && state== EXECUTE)
        |=> regs[instr_r[11:7]] == ($past(regs[instr[24:20]]) + $past(regs[instr[19:15]]));
endproperty
assert_ADD: assert property (op_ADD_prop );


//SUB
property op_SUB_prop;
  @(posedge clk) disable iff (~rst_n)
((instr[6:0] == 7'b0110011) && (instr[14:12] == 3'b000) &&(instr[31:25]==7'b0100000) && state== EXECUTE)
        |=> regs[instr_r[11:7]] == ($past(regs[instr[19:15]]) - $past(regs[instr[24:20]]));
endproperty
assert_SUB: assert property (op_SUB_prop );


//SLL, shift left logical
property op_SLL_prop;
  @(posedge clk) disable iff (~rst_n)
((instr[6:0] == 7'b0110011) && (instr[14:12] == 3'b001) &&(instr[31:25]==7'b0000000) && state== EXECUTE)
        |=> regs[instr_r[11:7]] == ($past(regs[instr[19:15]]) << $past(regs[instr[24:20]][4:0]));
endproperty
assert_SLL: assert property (op_SLL_prop );


//SLT,  set left than
property op_SLT_prop;
  @(posedge clk) disable iff (~rst_n)
((instr[6:0] == 7'b0110011) && (instr[14:12] == 3'b010) &&(instr[31:25]==7'b0000000) && state== EXECUTE)
        |=> regs[instr_r[11:7]] == ($past($signed(regs[instr[19:15]])) < $past($signed(regs[instr[24:20]]))) ? 1'b1: 1'b0;
endproperty
assert_SLT: assert property (op_SLT_prop );


//SLTU, set left than unsigned
property op_SLTU_prop;
  @(posedge clk) disable iff (~rst_n)
((instr[6:0] == 7'b0110011) && (instr[14:12] == 3'b011) &&(instr[31:25]==7'b0000000) && state== EXECUTE)
        |=> regs[instr_r[11:7]] == ($past($unsigned(regs[instr[19:15]])) < $past($unsigned(regs[instr[24:20]]))) ? 1'b1: 1'b0;
endproperty
assert_SLTU: assert property (op_SLTU_prop );


//XOR, shift right logical
property op_XOR_prop;
  @(posedge clk) disable iff (~rst_n)
((instr[6:0] == 7'b0110011) && (instr[14:12] == 3'b100) &&(instr[31:25]==7'b0000000) && state== EXECUTE)
        |=> regs[instr_r[11:7]] == ($past(regs[instr[19:15]]) ^ $past(regs[instr[24:20]]));
endproperty
assert_XOR: assert property (op_XOR_prop );



//SRL, shift right logical
property op_SRL_prop;
  @(posedge clk) disable iff (~rst_n)
((instr[6:0] == 7'b0110011) && (instr[14:12] == 3'b101) &&(instr[31:25]==7'b0000000) && state== EXECUTE)
        |=> regs[instr_r[11:7]] == ($past(regs[instr[19:15]]) >> $past(regs[instr[24:20]][4:0]));
endproperty
assert_SRL: assert property (op_SRL_prop );

//SRA, shift right arith
property op_SRA_prop;
  @(posedge clk) disable iff (~rst_n)
((instr[6:0] == 7'b0110011) && (instr[14:12] == 3'b101) &&(instr[31:25]==7'b0100000) && state== EXECUTE)
        |=> $signed(regs[instr_r[11:7]]) == ($past($signed(regs[instr[19:15]])) >>> $past((regs[instr[24:20]][4:0])));
endproperty
assert_SRA: assert property (op_SRA_prop );


//OR, shift right logical
property op_OR_prop;
  @(posedge clk) disable iff (~rst_n)
((instr[6:0] == 7'b0110011) && (instr[14:12] == 3'b110) &&(instr[31:25]==7'b0000000) && state== EXECUTE)
        |=> regs[instr_r[11:7]] == ($past(regs[instr[19:15]]) | $past(regs[instr[24:20]]));
endproperty
assert_OR: assert property (op_OR_prop );


//AND
property op_AND_prop;
  @(posedge clk) disable iff (~rst_n)
((instr[6:0] == 7'b0110011) && (instr[14:12] == 3'b111) &&(instr[31:25]==7'b0000000) && state== EXECUTE)
        |=> regs[instr_r[11:7]] == ($past(regs[instr[19:15]]) & $past(regs[instr[24:20]]));
endproperty
assert_AND: assert property (op_AND_prop );


//LW
//sequence local_LW_seq;
//   logic [3:0] local_data;
//   (((instr[6:0] == 7'b0000011) && (instr[14:12] == 3'b010) && state== EXECUTE), local_data = instr_r[11:7]) 
//     ##[1:8] (wb_ack &&(regs[local_data] == wb_rdata));
//endsequence



reg [4:0]   LW_rs1_save;
reg [31:0]  LW_addr_save;
always@(posedge clk) begin
  if(~rst_n) begin
    LW_rs1_save <= 5'b0;
    LW_addr_save <= 32'b0;
  end
  //else if((((instr[6:0] == 7'b0000011) && (instr[14:12] == 3'b010) && state== EXECUTE))) begin
  else if((((instr[6:0] == 7'b0000011) && state== EXECUTE))) begin
    LW_rs1_save <= instr[11:7];
    LW_addr_save <= regs[instr[19:15]] + {(instr[31] ? 21'h1FFFFF : 21'h0), instr[30:20]};
  end
end


//--------LW---------------------------
assume_LW_addr: assume property ( 
  @(posedge clk) disable iff (~rst_n)
    (((instr[6:0] == 7'b0000011) && (instr[14:12] == 3'b010) && state== EXECUTE)) |=> (LW_addr_save >= 32'h2000_0000) && (LW_addr_save <= 32'h2000_0FFF) &&  (LW_addr_save[1:0]==2'b00)
);


property op_LW_prop1;
  @(posedge clk) disable iff (~rst_n)
((instr[6:0] == 7'b0000011) && (instr[14:12] == 3'b010) && state== EXECUTE)
        |-> ##[1:3] (wb_addr == (LW_addr_save & 32'hFFFFFFFC));      //TODO
endproperty
assert_LW1: assert property (op_LW_prop1 );


property op_LW_prop2;
  @(posedge clk) disable iff (~rst_n)
((instr[6:0] == 7'b0000011) && (instr[14:12] == 3'b010) && state== EXECUTE)
        |-> ##[1:20] ($past(wb_ack,2) && (regs[LW_rs1_save] == $past(wb_rdata,2)));
endproperty
assert_LW2: assert property (op_LW_prop2 );



//--------LH---------------------------
assume_LH_addr: assume property ( 
  @(posedge clk) disable iff (~rst_n)
    (((instr[6:0] == 7'b0000011) && (instr[14:12] == 3'b001) && state== EXECUTE)) |=> (LW_addr_save >= 32'h2000_0000) && (LW_addr_save <= 32'h2000_0FFF) &&  (LW_addr_save[0]==1'b0)
);

property op_LH_prop1;
  @(posedge clk) disable iff (~rst_n)
((instr[6:0] == 7'b0000011) && (instr[14:12] == 3'b001) && state== EXECUTE)
        |-> ##[1:3] (wb_addr == (LW_addr_save & 32'hFFFFFFFC));      //TODO
endproperty
assert_LH1: assert property (op_LH_prop1 );


property op_LH_prop2;
  @(posedge clk) disable iff (~rst_n)
((instr[6:0] == 7'b0000011) && (instr[14:12] == 3'b001) && state== EXECUTE) 
        |-> ##[1:5] ($past(wb_ack,2) && (regs[LW_rs1_save] == ((LW_addr_save[1:0]==2'b00) ? {{16{$past(wb_rdata[15],2)}},$past(wb_rdata[15:0],2)} : {{16{$past(wb_rdata[31],2)}},$past(wb_rdata[31:16],2)} )));
endproperty
assert_LH2: assert property (op_LH_prop2 );

//--------LHU---------------------------
assume_LHU_addr: assume property ( 
  @(posedge clk) disable iff (~rst_n)
    (((instr[6:0] == 7'b0000011) && (instr[14:12] == 3'b101) && state== EXECUTE)) |=> (LW_addr_save >= 32'h2000_0000) && (LW_addr_save <= 32'h2000_0FFF) &&  (LW_addr_save[0]==1'b0)
);

property op_LHU_prop1;
  @(posedge clk) disable iff (~rst_n)
((instr[6:0] == 7'b0000011) && (instr[14:12] == 3'b101) && state== EXECUTE)
        |-> ##[1:3] (wb_addr == (LW_addr_save & 32'hFFFFFFFC));      //TODO
endproperty
assert_LHU1: assert property (op_LHU_prop1 );


property op_LHU_prop2;
  @(posedge clk) disable iff (~rst_n)
((instr[6:0] == 7'b0000011) && (instr[14:12] == 3'b101) && state== EXECUTE) 
        |-> ##[1:20] ($past(wb_ack,2) && (regs[LW_rs1_save] == ((LW_addr_save[1:0]==2'b00) ? {{16{1'b0}},$past(wb_rdata[15:0],2)} : {{16{1'b0}},$past(wb_rdata[31:16],2)} )));
endproperty
assert_LHU2: assert property (op_LHU_prop2 );



//--------LB---------------------------
assume_LB_addr: assume property ( 
  @(posedge clk) disable iff (~rst_n)
    (((instr[6:0] == 7'b0000011) && (instr[14:12] == 3'b000) && state== EXECUTE)) |=> (LW_addr_save >= 32'h2000_0000) && (LW_addr_save <= 32'h2000_0FFF)  
);

property op_LB_prop1;
  @(posedge clk) disable iff (~rst_n)
((instr[6:0] == 7'b0000011) && (instr[14:12] == 3'b000) && state== EXECUTE)
        |-> ##[1:3] (wb_addr == (LW_addr_save & 32'hFFFFFFFC));      //TODO
endproperty
assert_LB1: assert property (op_LB_prop1 );


property op_LB_prop2;
  @(posedge clk) disable iff (~rst_n)
((instr[6:0] == 7'b0000011) && (instr[14:12] == 3'b000) && state== EXECUTE) 
        |-> ##[1:20] ($past(wb_ack,2) && (regs[LW_rs1_save] == ((LW_addr_save[1:0]==2'b00) 
                                        ? {{24{$past(wb_rdata[7],2)}},$past(wb_rdata[7:0],2)} : 
                                        ( (LW_addr_save[1:0]==2'b01) ?{{24{$past(wb_rdata[15],2)}},$past(wb_rdata[15:8],2)}: 
                                        ( (LW_addr_save[1:0]==2'b10) ?{{24{$past(wb_rdata[23],2)}},$past(wb_rdata[23:16],2)}: 
                                         {{24{$past(wb_rdata[31],2)}},$past(wb_rdata[31:24],2)} )))));
endproperty
assert_LB2: assert property (op_LB_prop2 );


//--------LBU---------------------------
assume_LBU_addr: assume property ( 
  @(posedge clk) disable iff (~rst_n)
    (((instr[6:0] == 7'b0000011) && (instr[14:12] == 3'b100) && state== EXECUTE)) |=> (LW_addr_save >= 32'h2000_0000) && (LW_addr_save <= 32'h2000_0FFF)  
);

property op_LBU_prop1;
  @(posedge clk) disable iff (~rst_n)
((instr[6:0] == 7'b0000011) && (instr[14:12] == 3'b100) && state== EXECUTE)
        |-> ##[1:3] (wb_addr == (LW_addr_save & 32'hFFFFFFFC));      //TODO
endproperty
assert_LBU1: assert property (op_LBU_prop1 );


property op_LBU_prop2;
  @(posedge clk) disable iff (~rst_n)
((instr[6:0] == 7'b0000011) && (instr[14:12] == 3'b100) && state== EXECUTE) 
        |-> ##[1:20] ($past(wb_ack,2) && (regs[LW_rs1_save] == ((LW_addr_save[1:0]==2'b00) 
                                        ? {{24{1'b0}},$past(wb_rdata[7:0],2)} : 
                                        ( (LW_addr_save[1:0]==2'b01) ?{{24{1'b0}},$past(wb_rdata[15:8],2)}: 
                                        ( (LW_addr_save[1:0]==2'b10) ?{{24{1'b0}},$past(wb_rdata[23:16],2)}: 
                                         {{24{1'b0}},$past(wb_rdata[31:24],2)} )))));
endproperty
assert_LBU2: assert property (op_LBU_prop2 );

//*/
//end comments

x_detect_assert: assert property (@(posedge clk) disable iff (~rst_n) !$isunknown({instr[14:12],instr[6:0]})); 


assert_onehot_state: assert property (@(posedge clk) disable iff (~rst_n) ($onehot(state) ==1));
assert_onehot0_state: assert property (@(posedge clk) disable iff (~rst_n) ($onehot0(state) ==1));


property   cnt_underflow(cnt);     
  @(posedge clk) disable iff (~rst_n)
     (cnt == 8'b0) |=>  (cnt != 8'hFF)  ;
endproperty
assert_cnt_underflow : assert property (cnt_underflow(instr[7:0]) );

//VCS coverage on

endmodule
