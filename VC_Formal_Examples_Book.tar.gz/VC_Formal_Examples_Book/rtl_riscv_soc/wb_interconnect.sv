module wb_interconnect #(
    parameter NUM_SLAVES= 8,
    
    parameter SLV0_ADDR_BEGIN = 0,               //ROM
    parameter SLV0_ADDR_END = 32'h1FFF,

    parameter SLV1_ADDR_BEGIN = 32'h2000_0000,   //SRAM s1
    parameter SLV1_ADDR_END = 32'h2000_1FFF,

    parameter SLV2_ADDR_BEGIN = 32'h4000_0000,   //TIMER s2 
    parameter SLV2_ADDR_END = 32'h4000_0FFF,

    parameter SLV3_ADDR_BEGIN = 32'h4000_1000,   //UART0 s3
    parameter SLV3_ADDR_END = 32'h4000_1FFF,

    parameter SLV4_ADDR_BEGIN = 32'h4000_2000,   //GPIO s4
    parameter SLV4_ADDR_END = 32'h4000_2FFF,

    parameter SLV5_ADDR_BEGIN = 32'h4000_3000,   //CSR s5
    parameter SLV5_ADDR_END = 32'h4000_3FFF,

    parameter SLV6_ADDR_BEGIN = 32'h4000_4000,   //UART1 S6
    parameter SLV6_ADDR_END = 32'h4000_4FFF,

    parameter SLV7_ADDR_BEGIN = 32'h4000_5000,   //DEFAULT slave , s7
    parameter SLV7_ADDR_END = 32'h4000_5FFF

)(
    input         clk,
    input         rst_n,

//wb master interface
    input  [31:0] wb_addr_m0,
    input  [31:0] wb_wdata_m0,
    input  [3:0]  wb_sel_m0,
    input         wb_we_m0,
    input         wb_stb_m0,
    input         wb_cyc_m0,
    output [31:0] wb_rdata_m0,
    output        wb_ack_m0,
    output        wb_err_m0,

//wb slave if
    output  [31:0] wb_addr_s0,
    output  [31:0] wb_wdata_s0,
    output  [3:0]  wb_sel_s0,
    output         wb_we_s0,
    output         wb_stb_s0,
    output         wb_cyc_s0,
    input [31:0]   wb_rdata_s0,
    input          wb_ack_s0,
    input          wb_err_s0,

    output  [31:0] wb_addr_s1,
    output  [31:0] wb_wdata_s1,
    output  [3:0]  wb_sel_s1,
    output         wb_we_s1,
    output         wb_stb_s1,
    output         wb_cyc_s1,
    input [31:0]   wb_rdata_s1,
    input          wb_ack_s1,
    input          wb_err_s1,

    output  [31:0] wb_addr_s2,
    output  [31:0] wb_wdata_s2,
    output  [3:0]  wb_sel_s2,
    output         wb_we_s2,
    output         wb_stb_s2,
    output         wb_cyc_s2,
    input [31:0]   wb_rdata_s2,
    input          wb_ack_s2,
    input          wb_err_s2,

    output  [31:0] wb_addr_s3,
    output  [31:0] wb_wdata_s3,
    output  [3:0]  wb_sel_s3,
    output         wb_we_s3,
    output         wb_stb_s3,
    output         wb_cyc_s3,
    input [31:0]   wb_rdata_s3,
    input          wb_ack_s3,
    input          wb_err_s3,

    output  [31:0] wb_addr_s4,
    output  [31:0] wb_wdata_s4,
    output  [3:0]  wb_sel_s4,
    output         wb_we_s4,
    output         wb_stb_s4,
    output         wb_cyc_s4,
    input [31:0]   wb_rdata_s4,
    input          wb_ack_s4,
    input          wb_err_s4,

    output  [31:0] wb_addr_s5,
    output  [31:0] wb_wdata_s5,
    output  [3:0]  wb_sel_s5,
    output         wb_we_s5,
    output         wb_stb_s5,
    output         wb_cyc_s5,
    input [31:0]   wb_rdata_s5,
    input          wb_ack_s5,
    input          wb_err_s5,

    output  [31:0] wb_addr_s6,
    output  [31:0] wb_wdata_s6,
    output  [3:0]  wb_sel_s6,
    output         wb_we_s6,
    output         wb_stb_s6,
    output         wb_cyc_s6,
    input [31:0]   wb_rdata_s6,
    input          wb_ack_s6,
    input          wb_err_s6,

    output  [31:0] wb_addr_s7,
    output  [31:0] wb_wdata_s7,
    output  [3:0]  wb_sel_s7,
    output         wb_we_s7,
    output         wb_stb_s7,
    output         wb_cyc_s7,
    input [31:0]   wb_rdata_s7,
    input          wb_ack_s7,
    input          wb_err_s7    
);


wire [NUM_SLAVES-1:0] select_m0;

assign select_m0[0] = (wb_addr_m0 >= SLV0_ADDR_BEGIN) && (wb_addr_m0 <= SLV0_ADDR_END) & wb_cyc_m0 & wb_stb_m0;
assign select_m0[1] = (wb_addr_m0 >= SLV1_ADDR_BEGIN) && (wb_addr_m0 <= SLV1_ADDR_END) & wb_cyc_m0 & wb_stb_m0;
assign select_m0[2] = (wb_addr_m0 >= SLV2_ADDR_BEGIN) && (wb_addr_m0 <= SLV2_ADDR_END) & wb_cyc_m0 & wb_stb_m0;
assign select_m0[3] = (wb_addr_m0 >= SLV3_ADDR_BEGIN) && (wb_addr_m0 <= SLV3_ADDR_END) & wb_cyc_m0 & wb_stb_m0;
assign select_m0[4] = (wb_addr_m0 >= SLV4_ADDR_BEGIN) && (wb_addr_m0 <= SLV4_ADDR_END) & wb_cyc_m0 & wb_stb_m0;
assign select_m0[5] = (wb_addr_m0 >= SLV5_ADDR_BEGIN) && (wb_addr_m0 <= SLV5_ADDR_END) & wb_cyc_m0 & wb_stb_m0;
assign select_m0[6] = (wb_addr_m0 >= SLV6_ADDR_BEGIN) && (wb_addr_m0 <= SLV6_ADDR_END) & wb_cyc_m0 & wb_stb_m0;
//assign select_m0[7] = (wb_addr_m0 >= SLV7_ADDR_BEGIN) && (wb_addr_m0 <= SLV7_ADDR_END) & wb_cyc_m0 & wb_stb_m0;
assign select_m0[7] = ~(| select_m0[6:0]);



reg addr_valid_m0;
always @(*) begin
    addr_valid_m0 = 1'b0;
    for(int i = 0; i < NUM_SLAVES; i++)
        addr_valid_m0 |= select_m0[i];
end





reg      ack;
reg      err_i;
reg  [31:0]    read_data;
always@(*) begin
    read_data = 32'h0;
    ack = 1'h0;
    err_i = 1'h0;
    if(select_m0[0]) begin
        read_data = wb_rdata_s0;
        ack       = wb_ack_s0;
        err_i     = wb_err_s0;
    end
    else if(select_m0[1]) begin
        read_data = wb_rdata_s1;
        ack       = wb_ack_s1;
        err_i     = wb_err_s1;
    end    
    else if(select_m0[2]) begin
        read_data = wb_rdata_s2;
        ack       = wb_ack_s2;
        err_i     = wb_err_s2;
    end 
    else if(select_m0[3]) begin
        read_data = wb_rdata_s3;
        ack       = wb_ack_s3;
        err_i     = wb_err_s3;
    end
    else if(select_m0[4]) begin
        read_data = wb_rdata_s4;
        ack       = wb_ack_s4;
        err_i     = wb_err_s4;
    end 
    else if(select_m0[5]) begin
        read_data = wb_rdata_s5;
        ack       = wb_ack_s5;
        err_i     = wb_err_s5;
    end     
    else if(select_m0[6]) begin
        read_data = wb_rdata_s6;
        ack       = wb_ack_s6;
        err_i     = wb_err_s6;
    end 
    else if(select_m0[7]) begin
        read_data = wb_rdata_s7;
        ack       = wb_ack_s7;
        err_i     = wb_err_s7;
    end 

end



//assign wb_err_m0   = (~addr_valid_m0 & wb_cyc_m0 & wb_stb_m0) || err_i ;
assign wb_err_m0   = err_i; 
assign wb_ack_m0   = ack ;
assign wb_rdata_m0 = read_data ;

assign  wb_we_s0 = (select_m0[0] ? wb_we_m0 : 1'b0) ;
assign  wb_we_s1 = (select_m0[1] ? wb_we_m0 : 1'b0) ;
assign  wb_we_s2 = (select_m0[2] ? wb_we_m0 : 1'b0) ;
assign  wb_we_s3 = (select_m0[3] ? wb_we_m0 : 1'b0) ;
assign  wb_we_s4 = (select_m0[4] ? wb_we_m0 : 1'b0) ;
assign  wb_we_s5 = (select_m0[5] ? wb_we_m0 : 1'b0) ;
assign  wb_we_s6 = (select_m0[6] ? wb_we_m0 : 1'b0) ;
assign  wb_we_s7 = (select_m0[7] ? wb_we_m0 : 1'b0) ;

assign  wb_stb_s0 = (select_m0[0] ? wb_stb_m0 : 1'b0) ;
assign  wb_stb_s1 = (select_m0[1] ? wb_stb_m0 : 1'b0) ;
assign  wb_stb_s2 = (select_m0[2] ? wb_stb_m0 : 1'b0) ;
assign  wb_stb_s3 = (select_m0[3] ? wb_stb_m0 : 1'b0) ;
assign  wb_stb_s4 = (select_m0[4] ? wb_stb_m0 : 1'b0) ;
assign  wb_stb_s5 = (select_m0[5] ? wb_stb_m0 : 1'b0) ;
assign  wb_stb_s6 = (select_m0[6] ? wb_stb_m0 : 1'b0) ;
assign  wb_stb_s7 = (select_m0[7] ? wb_stb_m0 : 1'b0) ;

assign  wb_cyc_s0 = (select_m0[0] ? wb_cyc_m0 : 1'b0) ;
assign  wb_cyc_s1 = (select_m0[1] ? wb_cyc_m0 : 1'b0) ;
assign  wb_cyc_s2 = (select_m0[2] ? wb_cyc_m0 : 1'b0) ;
assign  wb_cyc_s3 = (select_m0[3] ? wb_cyc_m0 : 1'b0) ;
assign  wb_cyc_s4 = (select_m0[4] ? wb_cyc_m0 : 1'b0) ;
assign  wb_cyc_s5 = (select_m0[5] ? wb_cyc_m0 : 1'b0) ;
assign  wb_cyc_s6 = (select_m0[6] ? wb_cyc_m0 : 1'b0) ;
assign  wb_cyc_s7 = (select_m0[7] ? wb_cyc_m0 : 1'b0) ;

assign  wb_wdata_s0 = (select_m0[0] ? wb_wdata_m0 : 1'b0) ;
assign  wb_wdata_s1 = (select_m0[1] ? wb_wdata_m0 : 1'b0) ;
assign  wb_wdata_s2 = (select_m0[2] ? wb_wdata_m0 : 1'b0) ;
assign  wb_wdata_s3 = (select_m0[3] ? wb_wdata_m0 : 1'b0) ;
assign  wb_wdata_s4 = (select_m0[4] ? wb_wdata_m0 : 1'b0) ;
assign  wb_wdata_s5 = (select_m0[5] ? wb_wdata_m0 : 1'b0) ;
assign  wb_wdata_s6 = (select_m0[6] ? wb_wdata_m0 : 1'b0) ;
assign  wb_wdata_s7 = (select_m0[7] ? wb_wdata_m0 : 1'b0) ;

assign  wb_sel_s0 = (select_m0[0] ? wb_sel_m0 : 1'b0) ;
assign  wb_sel_s1 = (select_m0[1] ? wb_sel_m0 : 1'b0) ;
assign  wb_sel_s2 = (select_m0[2] ? wb_sel_m0 : 1'b0) ;
assign  wb_sel_s3 = (select_m0[3] ? wb_sel_m0 : 1'b0) ;
assign  wb_sel_s4 = (select_m0[4] ? wb_sel_m0 : 1'b0) ;
assign  wb_sel_s5 = (select_m0[5] ? wb_sel_m0 : 1'b0) ;
assign  wb_sel_s6 = (select_m0[6] ? wb_sel_m0 : 1'b0) ;
assign  wb_sel_s7 = (select_m0[7] ? wb_sel_m0 : 1'b0) ;

assign  wb_addr_s0 = (select_m0[0] ? wb_addr_m0 : 1'b0) ;
assign  wb_addr_s1 = (select_m0[1] ? wb_addr_m0 : 1'b0) ;
assign  wb_addr_s2 = (select_m0[2] ? wb_addr_m0 : 1'b0) ;
assign  wb_addr_s3 = (select_m0[3] ? wb_addr_m0 : 1'b0) ;
assign  wb_addr_s4 = (select_m0[4] ? wb_addr_m0 : 1'b0) ;
assign  wb_addr_s5 = (select_m0[5] ? wb_addr_m0 : 1'b0) ;
assign  wb_addr_s6 = (select_m0[6] ? wb_addr_m0 : 1'b0) ;
assign  wb_addr_s7 = (select_m0[7] ? wb_addr_m0 : 1'b0) ;


endmodule
