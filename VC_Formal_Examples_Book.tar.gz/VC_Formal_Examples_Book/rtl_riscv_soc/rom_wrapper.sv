module rom_wrapper #(
    parameter ADDR_WIDTH = 10
)(
    input clk,
    input rst_n,

//    wb bus_slave
    input  [31:0] wb_addr,
    input  [31:0] wb_wdata,
    input  [3:0]  wb_sel,
    input         wb_we,
    input         wb_stb,
    input         wb_cyc,
    output[31:0]  wb_rdata,
    output        wb_ack,
    output        wb_err
);

reg  [31:0] rdata;
reg  ack;
wire err;


//memory array 
reg [31:0] memory [2**ADDR_WIDTH-1:0];

reg [7:0] idx;
reg [7:0] test_idx;

initial 
begin
if($value$plusargs("test_idx=%d",test_idx))
idx=test_idx;
else
idx=0;
if(idx == 0)
  $readmemh("tests/fibonacci", memory);
else if(idx == 1)
  $readmemh("tests/all_instr", memory);   
else if(idx == 10)
  $readmemh("tests/csr.txt", memory);
else if(idx == 11)
  $readmemh("tests/gpio.txt", memory);  
else if(idx == 12)
  $readmemh("tests/uart.txt", memory); 
else if(idx == 13)
  $readmemh("tests/uart_en.txt", memory); 
else if(idx == 14)
  $readmemh("tests/timer.txt", memory); 

end   //end of initial




wire [ADDR_WIDTH-1:0] word_addr = wb_addr[ADDR_WIDTH+1:2];    // Word-based address

always @(posedge clk or negedge rst_n) begin
    if (~rst_n) begin
        rdata <= 32'h0;
    end
    else if (wb_stb) begin
        rdata <= memory[word_addr];
    end
end

assign err = wb_cyc && wb_stb && wb_we;    //response error when write ROM    

always @(posedge clk or negedge rst_n) begin
    if (~rst_n) begin
        ack <= 1'h0;
    end
    else begin
        ack <= wb_stb & ~err;
    end
end



assign wb_ack = ack & wb_stb & ~err;
assign wb_rdata = rdata;
assign wb_err = err;

endmodule
