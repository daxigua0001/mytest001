module csr #(
    parameter ADDR_WIDTH = 10
)(
    input clk,
    input rst_n,

    output   reg  cfg_uart0_en,
    output   reg  cfg_uart1_en,
    output   reg  [1:0]   cfg_test_sig_sel,
    output   reg  cfg_xfence_uart0,
    output   reg  cfg_xfence_uart1,
    output   reg  cfg_xfence_timer,

    input  [ADDR_WIDTH-1:0] wb_addr,
    input  [31:0] wb_wdata,
    input  [3:0]  wb_sel,
    input         wb_we,
    input         wb_stb,
    input         wb_cyc,
    output[31:0]  wb_rdata,
    output reg    wb_ack,
    output        wb_err

);

reg [31:0]   rdata;
reg [31:0]   test_reg;

	always @(posedge clk or negedge rst_n)  begin
      if(!rst_n) begin
        wb_ack <= 1'b0;
      end
      else if(wb_ack) begin
        wb_ack <= 1'b0;
      end
      else begin
		wb_ack <= (wb_stb)&&(wb_cyc);
      end    
    end


    wire read_en  = wb_stb && wb_cyc && ~wb_we && ~wb_ack;
    wire write_en = wb_we && wb_cyc && wb_stb && wb_ack;

    
    // Control and State registers for this timer
    

	always @(posedge clk or negedge rst_n)  begin
      if(!rst_n) begin
        cfg_uart0_en <= 1'b0;
        cfg_uart1_en <= 1'b0;
      end
      else if(write_en && (wb_addr[9:0] == 'h0) && wb_sel[0]) begin
        cfg_uart0_en <= wb_wdata[0];
        cfg_uart1_en <= wb_wdata[1];
      end
   end   

//test mode signal select
	always @(posedge clk or negedge rst_n)  begin
      if(!rst_n) begin
        cfg_test_sig_sel<= 2'b0;
      end
      else if(write_en && (wb_addr[9:0] == 'h4) && wb_sel[0]) begin
        cfg_test_sig_sel<= wb_wdata[1:0];
      end
   end   

//test reg
	always @(posedge clk or negedge rst_n)  begin
      if(!rst_n) begin
        test_reg <= 32'b0;
      end
      //else if(write_en && (wb_addr[9:0] == 'h4)) begin
      else if(write_en && (wb_addr[9:0] == 'h8)) begin     //bug fix
        if(wb_sel[0]) test_reg[7:0]   <= wb_wdata[7:0];
        if(wb_sel[1]) test_reg[15:8]  <= wb_wdata[15:8];
        if(wb_sel[2]) test_reg[23:16] <= wb_wdata[23:16];
        if(wb_sel[3]) test_reg[31:24] <= wb_wdata[31:24];
      end
   end   

//cfg_fence
	always @(posedge clk or negedge rst_n)  begin
      if(!rst_n) begin
        cfg_xfence_uart0 <= 1'b1;  //1 means disable xfence
        cfg_xfence_uart1 <= 1'b1;
        cfg_xfence_timer <= 1'b1;
      end
      else if(write_en && (wb_addr[9:0] == 'hc) && wb_sel[0]) begin
        cfg_xfence_uart0 <= wb_wdata[0];
        cfg_xfence_uart1 <= wb_wdata[1];
        cfg_xfence_timer <= wb_wdata[2];
      end
   end  


	always @(posedge clk or negedge rst_n)  begin
      if(!rst_n) begin
        rdata<= 32'b0;
      end
      else if(read_en ) 
        case(wb_addr)
        10'h0:
          rdata<= {30'b0,cfg_uart1_en,cfg_uart0_en};
        10'h4:
          rdata<= {30'b0,cfg_test_sig_sel};
        10'h8:
          rdata<= test_reg;
        10'hc:
          rdata<= {29'b0,cfg_xfence_timer,cfg_xfence_uart1,cfg_xfence_uart0};
        default: rdata<= 32'b0;
        endcase
    end  


// Bus connections
assign wb_err = 1'b0;
assign wb_rdata = rdata;

endmodule
