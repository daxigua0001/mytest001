module cg (
input          clk,            // Clock
input          enable,      // Clock enable    
output         gclk            // Gated clock
);
// CLOCK GATE: LATCH + AND
reg enable_latch;
always @(clk or enable)
  if (~clk)
    enable_latch = enable;

assign  gclk = (clk & enable_latch);
endmodule

