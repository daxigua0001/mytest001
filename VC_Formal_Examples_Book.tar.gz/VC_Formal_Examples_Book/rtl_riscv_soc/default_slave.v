module default_slave (
    input clk,
    input rst_n,

    input  [31:0] wb_addr,
    input  [31:0] wb_wdata,
    input  [3:0]  wb_sel,
    input         wb_we,
    input         wb_stb,
    input         wb_cyc,
    output[31:0]  wb_rdata,
    output  reg   wb_ack,
    output        wb_err

);


	always @(posedge clk or negedge rst_n)  begin
      if(!rst_n) begin
        wb_ack <= 1'b0;
      end
      else if(wb_ack) begin
        wb_ack <= 1'b0;
      end
      else begin
		wb_ack <= wb_cyc;       //report err when access
      end    
    end



// Bus connections
assign wb_err = 1'b0;
assign wb_rdata = 32'b0;

endmodule
