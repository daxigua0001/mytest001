
module biu(
    input clk,
    input rst_n,

    // Interface to cpu 
    input[1:0] cmd_in,
    output busy_out,
    output err_out,

    input [31:0] addr_in,
    output [31:0] rdata_out,
    input [31:0] wdata_in,
    input [3:0] wmask_in,

    // WB interface
    output  [31:0] wb_addr,
    output  [31:0] wb_wdata,
    output  [3:0]  wb_sel,
    output         wb_we,
    output         wb_stb,
    output         wb_cyc,
    input [31:0]   wb_rdata,
    input          wb_ack,
    input          wb_err
);

localparam    IDLE = 2'b00;
localparam    WAIT_ACK     = 2'b01;

localparam    WB_NO    = 2'b00;
localparam    WB_READ    = 2'b01;
localparam    WB_WRITE   = 2'b10;

reg [31:0] write_data;
reg [3:0] write_mask;
reg [31:0] read_data;
reg [31:0] address;
reg busy;
reg error;
reg [1:0] state;


reg we, stb, cyc;

always @(posedge clk) begin
    if (~rst_n) begin
        read_data <= 32'h0;
        busy <= 1'b0;
        state <= IDLE;
        address <= 32'h0;
        write_mask <= 4'h0;
        write_data <= 32'h0;
        we <= 1'h0;
        stb <= 1'h0;
        cyc <= 1'h0;
        error <= 1'h0;
    end
    else begin
        case (state)  
            WAIT_ACK: begin
                if (wb_err) begin
                    error <= 1'b1;
                    stb <= 1'b0;
                    cyc <= 1'b0;
                    we <= 1'b0;
                    state <= IDLE;
                    busy <= 1'b0;
                end
                else if (wb_ack) begin
                    if (~we) begin
                        read_data <= wb_rdata;
                    end
                    stb <= 1'b0;
                    cyc <= 1'b0;
                    we <= 1'b0;
                    state <= IDLE;
                    busy <= 1'b0;
                end
            end
            default: begin
                if (cmd_in != WB_NO) begin
                    busy <= 1'b1;

                    address <= addr_in;
                    write_data <= wdata_in;
                    write_mask <= wmask_in;

                    error <= 1'h0;

                    we <= (cmd_in == WB_READ) ? 1'b0 : 1'b1;
                    stb <= 1'b1;
                    cyc <= 1'b1;

                    state <= WAIT_ACK;
                end
            end
        endcase
    end
end

assign rdata_out = read_data;
assign busy_out = busy;
assign err_out = error;

assign wb_addr = address;
assign wb_wdata = write_data;
assign wb_sel = we ? write_mask : 4'b1111; 
assign wb_we = we;
assign wb_stb = stb;
assign wb_cyc = cyc;


endmodule
