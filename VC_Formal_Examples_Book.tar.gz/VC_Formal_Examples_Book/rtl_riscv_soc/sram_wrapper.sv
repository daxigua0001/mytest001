module sram_wrapper #(
    parameter ADDR_WIDTH = 10
)(
    input clk,
    input rst_n,

    input  [31:0] wb_addr,
    input  [31:0] wb_wdata,
    input  [3:0]  wb_sel,
    input         wb_we,
    input         wb_stb,
    input         wb_cyc,
    output[31:0]  wb_rdata,
    output        wb_ack,
    output        wb_err
);

localparam    IDLE = 2'b00;
localparam    BUSY = 2'b01;


// RAM
reg  [31:0] memory [2**ADDR_WIDTH-1:0];

initial begin
    for (int i = 0; i < 2**ADDR_WIDTH; i++)
        memory[i] = 32'h0;
end

wire [ADDR_WIDTH-1:0] word_addr = wb_addr[ADDR_WIDTH+1:2];    // Word-based address

wire [31:0] word_wmask = {
    (wb_sel[3] ? 8'hFF : 8'h0),
    (wb_sel[2] ? 8'hFF : 8'h0),
    (wb_sel[1] ? 8'hFF : 8'h0),
    (wb_sel[0] ? 8'hFF : 8'h0)
};

reg [31:0] rdata;
reg        ack;
reg [1:0]  state;

always @(posedge clk) begin
    if (~rst_n) begin
        rdata <= 32'h0;
        ack <= 1'h0;
        state <= IDLE;
    end
    else begin
        case (state)
            IDLE: begin
                if (wb_stb & wb_cyc & ~wb_err) begin
                    ack <= 1'h1;
                    state <= BUSY;

                    rdata <= memory[word_addr];
                end
            end
            /*BUSY*/
            default: begin
                ack <= 1'h0;
                state <= IDLE;

                if (wb_we) begin
                    memory[word_addr] <= (rdata & ~word_wmask) | (wb_wdata & word_wmask);
                end
            end
        endcase
    end
end

// Bus connections
assign wb_ack = ack;
assign wb_err = 1'b0;
assign wb_rdata = rdata;

endmodule
