
module  x_fence
(
//  input    clk,
//  input    rst_n,

//cfg
  input  cfg_xfence_timer,
  input  cfg_xfence_uart0,
  input  cfg_xfence_uart1,

//input from timer
  input  [31:0]   wb_rdata_timer,
  input  wb_ack_timer,
  input  wb_err_timer,
  input  irq_timer,

//input from uart0
  input  [31:0]   wb_rdata_uart0,
  input  wb_ack_uart0,
  input  wb_err_uart0,

//input from uart1
  input  [31:0]   wb_rdata_uart1,
  input  wb_ack_uart1,
  input  wb_err_uart1,

//output for timer
  output  [31:0]   wb_rdata_s2,
  output  wb_ack_s2,
  output  wb_err_s2,
  output  irq_timer_o,

//output for uart0
  output  [31:0]   wb_rdata_s3,
  output  wb_ack_s3,
  output  wb_err_s3,

//output for uart1
  output  [31:0]   wb_rdata_s6,
  output  wb_ack_s6,
  output  wb_err_s6

);

assign  wb_rdata_s2 = {32{cfg_xfence_timer}} & wb_rdata_timer;
assign  wb_ack_s2 = cfg_xfence_timer & wb_ack_timer;
assign  wb_err_s2 = cfg_xfence_timer & wb_err_timer;

`ifndef FXP_BUG_FIX
assign  irq_timer_o = irq_timer;     //bug, no fence logic
`else
assign  irq_timer_o = cfg_xfence_timer & irq_timer;
`endif


//assign  wb_rdata_s3 =  wb_rdata_uart0;
assign  wb_rdata_s3 = {32{cfg_xfence_uart0}} & wb_rdata_uart0;
assign  wb_ack_s3 = cfg_xfence_uart0 & wb_ack_uart0;
assign  wb_err_s3 = cfg_xfence_uart0 & wb_err_uart0;

assign  wb_rdata_s6 = {32{cfg_xfence_uart1}} & wb_rdata_uart1;
assign  wb_ack_s6 = cfg_xfence_uart1 & wb_ack_uart1;
assign  wb_err_s6 = cfg_xfence_uart1 & wb_err_uart1;

endmodule
