/*
GPIO CSR registers:
GPIO Data Direction Register: GPIO_OE_EN (RW),reset=0x0. A set bit indicates that that GPIO should be an output. 
GPIO Data Out Register:       GPIO_OUT_REG (RW) The data output register .  pin.  
GPIO Data In Register:        GPIO_IN_REG (RO) The data input register of length N 
 */
`define CSR_GPIO_OUT_REG_ADDR 0
`define CSR_GPIO_IN_REG_ADDR 4
`define CSR_GPIO_DIRECT_OUT_ADDR 'h8
module gpio #
(
    parameter NUM_GPIO = 8, // number of GPIO pins 

    parameter ADDR_WIDTH = 10
)
(
    input  wire                 clk,
    input  wire                 rst_n,

    //Host interface
    input		                wb_cyc_i,
    input		                wb_stb_i, 
    input                       wb_we_i,
    input	[ADDR_WIDTH-1:0]	wb_addr_i,
    input	[31:0]	            wb_dat_i,
    input	[3:0]	            wb_sel_i,
    output	wire	            wb_err_o,
    output	reg		            wb_ack_o,
    output	reg	[31:0]          wb_dat_o,    

    input  wire [NUM_GPIO-1:0]  gpio_i,
    output wire [NUM_GPIO-1:0]  gpio_o,
    output wire [NUM_GPIO-1:0]  gpio_oe //GPIO pin ouput enable
);


    reg [31:0] csr_gpio_out_reg;
    reg [31:0] csr_gpio_direct_out;
    reg [NUM_GPIO-1:0] csr_gpio_mux_out;
    
    //as input pad is asynchronize to this gpio block, use 2-FlipFlop to register
    reg [NUM_GPIO-1:0] gpio_i_q1;
    reg [NUM_GPIO-1:0] gpio_i_q2;
    always @(posedge clk or negedge rst_n)
        if(~rst_n) begin
            gpio_i_q1<={NUM_GPIO{1'b0}};
            gpio_i_q2<={NUM_GPIO{1'b0}};
        end else begin
            gpio_i_q1<= gpio_i;
            gpio_i_q2<=gpio_i_q1;
        end
    
    assign gpio_o = csr_gpio_out_reg[NUM_GPIO-1:0];
    assign gpio_oe= csr_gpio_direct_out[NUM_GPIO-1:0];


    //Following part is for CSR registers' logic
    
    // Read enables
    wire csr_data_re = (!wb_we_i & wb_stb_i & wb_cyc_i)& ~wb_ack_o ;
    // output data bus
    always@*
    case(wb_addr_i)
            `CSR_GPIO_OUT_REG_ADDR: csr_gpio_mux_out = csr_gpio_out_reg[NUM_GPIO-1:0];
            `CSR_GPIO_IN_REG_ADDR:  csr_gpio_mux_out = gpio_i_q2;
            `CSR_GPIO_DIRECT_OUT_ADDR:   csr_gpio_mux_out = csr_gpio_direct_out[NUM_GPIO-1:0];
            default: csr_gpio_mux_out = {NUM_GPIO{1'b0}};
    endcase
    always @(posedge clk or negedge rst_n)
       if(~rst_n)
         wb_dat_o<=32'h0000_0000; 
        else if(csr_data_re)  begin
         wb_dat_o<={{32-NUM_GPIO{1'b0}},csr_gpio_mux_out}; 
        end
    
//gpio_out wr decode        
    wire csr_gpio_out_reg_we0=(wb_addr_i[3:0]==`CSR_GPIO_OUT_REG_ADDR) ? {wb_we_i & wb_stb_i} & wb_cyc_i & wb_sel_i[0] & wb_ack_o: 1'b0;
    wire csr_gpio_out_reg_we1=(wb_addr_i[3:0]==`CSR_GPIO_OUT_REG_ADDR) ? {wb_we_i & wb_stb_i} & wb_cyc_i & wb_sel_i[1] & wb_ack_o: 1'b0;
    wire csr_gpio_out_reg_we2=(wb_addr_i[3:0]==`CSR_GPIO_OUT_REG_ADDR) ? {wb_we_i & wb_stb_i} & wb_cyc_i & wb_sel_i[2] & wb_ack_o: 1'b0;
    wire csr_gpio_out_reg_we3=(wb_addr_i[3:0]==`CSR_GPIO_OUT_REG_ADDR) ? {wb_we_i & wb_stb_i} & wb_cyc_i & wb_sel_i[3] & wb_ack_o: 1'b0;
   
    always @(posedge clk or negedge rst_n)
       if(~rst_n)
         csr_gpio_out_reg<=32'h0; 
        else   begin
         if(csr_gpio_out_reg_we0)
             csr_gpio_out_reg[7:0]<=wb_dat_i[7:0];
         if(csr_gpio_out_reg_we1)
             csr_gpio_out_reg[15:8]<=wb_dat_i[15:8];
         if(csr_gpio_out_reg_we2)
             csr_gpio_out_reg[23:16]<=wb_dat_i[23:16];
         if(csr_gpio_out_reg_we3)
             csr_gpio_out_reg[31:24]<=wb_dat_i[31:24];             
        end
  

//gpio_direct_out wr decode         
    wire csr_gpio_direct_out_we0=(wb_addr_i==`CSR_GPIO_DIRECT_OUT_ADDR) ? {wb_we_i & wb_stb_i} & wb_cyc_i & wb_sel_i[0] & wb_ack_o : 1'b0;
    wire csr_gpio_direct_out_we1=(wb_addr_i==`CSR_GPIO_DIRECT_OUT_ADDR) ? {wb_we_i & wb_stb_i} & wb_cyc_i & wb_sel_i[1] & wb_ack_o : 1'b0;
    wire csr_gpio_direct_out_we2=(wb_addr_i==`CSR_GPIO_DIRECT_OUT_ADDR) ? {wb_we_i & wb_stb_i} & wb_cyc_i & wb_sel_i[2] & wb_ack_o : 1'b0;
    wire csr_gpio_direct_out_we3=(wb_addr_i==`CSR_GPIO_DIRECT_OUT_ADDR) ? {wb_we_i & wb_stb_i} & wb_cyc_i & wb_sel_i[3] & wb_ack_o : 1'b0;

    always @(posedge clk or negedge rst_n)  begin
       if(~rst_n)
         csr_gpio_direct_out<=32'h0; //default set input 
        else   begin
         if(csr_gpio_direct_out_we0)
             csr_gpio_direct_out[7:0]<=wb_dat_i[7:0];
         if(csr_gpio_direct_out_we1)
             csr_gpio_direct_out[15:8]<=wb_dat_i[15:8];
         if(csr_gpio_direct_out_we2)
             csr_gpio_direct_out[23:16]<=wb_dat_i[23:16];
         if(csr_gpio_direct_out_we3)
             csr_gpio_direct_out[31:24]<=wb_dat_i[31:24];               
        end
    end    
    

// always ready to capture the data, assume never transfare failure
    	always @(posedge clk or negedge rst_n)
        if(~rst_n)
          wb_ack_o <= 1'b0;
        else if(wb_ack_o)
          wb_ack_o <= 1'b0;
        else
       	  wb_ack_o <= (wb_stb_i)&&(wb_cyc_i);

   assign wb_err_o=1'b0;
    
endmodule



