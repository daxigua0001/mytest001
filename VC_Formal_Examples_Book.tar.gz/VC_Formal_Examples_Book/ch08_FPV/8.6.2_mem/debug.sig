<?xml version="1.0" encoding="UTF-8"?>
<wavelist version="3">
  <insertion-point-position>9</insertion-point-position>
  <wave>
    <expr>clk</expr>
    <label/>
    <radix/>
  </wave>
  <wave>
    <expr>&lt;embedded&gt;::top.check_rd2addr_different</expr>
    <label/>
    <radix/>
  </wave>
  <wave>
    <expr>rd_en_q1</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>rd_addr_q1</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>rd_data</expr>
    <label/>
    <radix/>
  </wave>
  <wave>
    <expr>rstb</expr>
    <label/>
    <radix/>
  </wave>
  <wave>
    <expr>wr_en_q0</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>wr_addr_q0</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>wr_data_q0</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>wr_addr_last</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>wr_addr_q1</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>wr_data_last</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>wr_data_q1</expr>
    <label/>
    <radix/>
  </wave>
  <wave>
    <expr>wr_en_last</expr>
    <label/>
    <radix/>
  </wave>
  <wave>
    <expr>wr_en_q1_flag</expr>
    <label/>
    <radix/>
  </wave>
  <wave>
    <expr>wr_data_last[7]</expr>
    <label/>
    <radix/>
  </wave>
  <wave>
    <expr>wr_data_q1[7]</expr>
    <label/>
    <radix/>
  </wave>
</wavelist>
