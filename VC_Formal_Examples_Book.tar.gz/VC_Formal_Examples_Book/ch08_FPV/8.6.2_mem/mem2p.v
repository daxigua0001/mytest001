
module mem2p (
QB, 
 CLKA, CLKB, MEA, MEB, RSTA, RSTB, WEA, ADRA, ADRB, DA
);
   parameter DATA_WIDTH = 32;
   parameter ADDR_WIDTH = 5;
   //parameter ADDR_WIDTH = $clog2(MEM_DEPTH);
   parameter MEM_DEPTH=2**ADDR_WIDTH;
   
//output ports
output [DATA_WIDTH-1:0] QB;
//input ports
input CLKA;
input CLKB;
input MEA;
input MEB;
input RSTA;
input RSTB;
input WEA;
input [ADDR_WIDTH-1:0] ADRA;
input [ADDR_WIDTH-1:0] ADRB;
input [DATA_WIDTH-1:0] DA;

   reg  [DATA_WIDTH-1:0] data[0:MEM_DEPTH-1];
   reg  [DATA_WIDTH-1:0] QB_int,QB_flopped;

   always_ff @(posedge CLKA)  begin
        if (MEA|WEA) begin
            data[ADRA] <= DA;
        end
   end
   always_ff @(posedge CLKB)  begin
        if ((MEB)) begin
            QB_flopped <= data[ADRB];
        end
        QB_int <= QB_flopped;
   end
   assign QB = QB_int;


endmodule
