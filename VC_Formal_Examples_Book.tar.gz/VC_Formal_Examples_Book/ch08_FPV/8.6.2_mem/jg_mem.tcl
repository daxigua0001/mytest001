# ----------------------------------------
#  Copyright (c) 2017 Cadence Design Systems, Inc. All Rights
#  Reserved.  Unpublished -- rights reserved under the copyright 
#  laws of the United States.
# ----------------------------------------
clear -all

# Analyze design under verification files
set ROOT_PATH ./
set RTL_PATH ${ROOT_PATH}/
set PROP_PATH ${ROOT_PATH}/

analyze -sv12 \
  ${RTL_PATH}/mem2p.v \
  ${RTL_PATH}/top_fix.sv 

  
# Elaborate design and properties
elaborate -top top

# Set up Clocks and Resets
clock clk
reset ~rstb
reset -non_resettable_regs 0
# Get design information to check general complexity
get_design_info 
#liang added 
#cover -name test {addr0 == 8 ##10 addr0 == 3}
#constraints
assume -name "never_rd_wr_same_addr" { ! (rd_en && wr_en && (rd_addr==wr_addr)) }

# Prove properties
prove -all

# Report proof results
report

