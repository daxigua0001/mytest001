module sram_wrapper #(
    parameter [31:0] BaseAddr = 32'h2000_0000
)(
    input clk,
    input rst_n,

    input  [31:0] wb_addr,
    input  [31:0] wb_wdata,
    input  [3:0]  wb_sel,
    input         wb_we,
    input         wb_stb,
    input         wb_cyc,
    output[31:0]  wb_rdata,
    output        wb_ack,
    output        wb_err
);

localparam    IDLE = 2'b00;
localparam    BUSY = 2'b01;


// RAM
//reg  [31:0] memory [0:2047];
reg  [31:0] memory [0:7]; //hack to shrink memory


initial begin
    for (int i = 0; i < 2048; i++)
        memory[i] = 32'h0;
end

wire [10:0] word_addr = wb_addr[12:2];    // Word-based address


wire [31:0] word_wmask = {
    (wb_sel[3] ? 8'hFF : 8'h0),
    (wb_sel[2] ? 8'hFF : 8'h0),
    (wb_sel[1] ? 8'hFF : 8'h0),
    (wb_sel[0] ? 8'hFF : 8'h0)
};

wire [31:0] wb_wdata_buf;
`ifdef BUF_WR_DATA
BUF wb_data_BUF(.in(wb_wdata),.out(wb_wdata_buf)); //setup issue3, unresolved cell cause behavior abnormal
`else
assign wb_wdata_buf=wb_wdata;
`endif

reg [31:0] rdata;
reg        ack;
reg [1:0]  state;

always @(posedge clk) begin
    if (~rst_n) begin
        rdata <= 32'h0;
        ack <= 1'h0;
        state <= IDLE;
    end
    else begin
        case (state)
            IDLE: begin
                if (wb_stb & wb_cyc & ~wb_err) begin
                    ack <= 1'h1;
                    state <= BUSY;

                    rdata <= memory[word_addr[2:0]];
                end
            end
            /*BUSY*/
            default: begin
                // Transaction complete, deassert ack
                ack <= 1'h0;
                state <= IDLE;

                if (wb_we) begin
                    memory[word_addr[2:0]] <= (rdata & ~word_wmask) | (wb_wdata_buf & word_wmask);
                end
            end
        endcase
    end
end

// Bus connections
assign wb_ack = ack;
assign wb_err = 1'b0;
assign wb_rdata = rdata;


//assertions 
assert_SRAM_write_in:assert property( @(posedge clk) disable iff (~rst_n)
( wb_we==1 && wb_sel==4'b1111 && wb_addr==32'h2000_0000 && state != IDLE) 
    |=> memory[0] == $past(wb_wdata) );


endmodule
