module soc(
    input clk,
    input rst_n,

    inout PAD_IO_0,
    inout PAD_IO_1,
    inout PAD_IO_2,
    inout PAD_IO_3,
    inout PAD_IO_4,
    inout PAD_IO_5,
    inout PAD_IO_6,
    inout PAD_IO_7,
    input test_mode_pin

);


//===============parameter==================
parameter  NUM_GPIO = 8;
parameter  UART_FIFO_DEPTH = 2 ;


//===============signals==================

    wire  [31:0] wb_addr;
    wire  [31:0] wb_wdata;
    wire  [3:0]  wb_sel;
    wire         wb_we;
    wire         wb_stb;
    wire         wb_cyc;
    wire[31:0]   wb_rdata;
    wire         wb_ack;
    wire         wb_err;

    wire  [31:0] wb_addr_s0;
    wire  [31:0] wb_wdata_s0;
    wire  [3:0]  wb_sel_s0;
    wire         wb_we_s0;
    wire         wb_stb_s0;
    wire         wb_cyc_s0;
    wire[31:0]   wb_rdata_s0;
    wire         wb_ack_s0;
    wire         wb_err_s0;

    wire  [31:0] wb_addr_s1;
    wire  [31:0] wb_wdata_s1;
    wire  [3:0]  wb_sel_s1;
    wire         wb_we_s1;
    wire         wb_stb_s1;
    wire         wb_cyc_s1;
    wire[31:0]   wb_rdata_s1;
    wire         wb_ack_s1;
    wire         wb_err_s1;

    wire  [31:0] wb_addr_s2;
    wire  [31:0] wb_wdata_s2;
    wire  [3:0]  wb_sel_s2;
    wire         wb_we_s2;
    wire         wb_stb_s2;
    wire         wb_cyc_s2;
    wire[31:0]   wb_rdata_s2;
    wire         wb_ack_s2;
    wire         wb_err_s2;

    wire  [31:0] wb_addr_s3;
    wire  [31:0] wb_wdata_s3;
    wire  [3:0]  wb_sel_s3;
    wire         wb_we_s3;
    wire         wb_stb_s3;
    wire         wb_cyc_s3;
    wire[31:0]   wb_rdata_s3;
    wire         wb_ack_s3;
    wire         wb_err_s3;

    wire  [31:0] wb_addr_s4;
    wire  [31:0] wb_wdata_s4;
    wire  [3:0]  wb_sel_s4;
    wire         wb_we_s4;
    wire         wb_stb_s4;
    wire         wb_cyc_s4;
    wire[31:0]   wb_rdata_s4;
    wire         wb_ack_s4;
    wire         wb_err_s4;    

    wire  [31:0] wb_addr_s5;
    wire  [31:0] wb_wdata_s5;
    wire  [3:0]  wb_sel_s5;
    wire         wb_we_s5;
    wire         wb_stb_s5;
    wire         wb_cyc_s5;
    wire[31:0]   wb_rdata_s5;
    wire         wb_ack_s5;
    wire         wb_err_s5; 

    wire  [31:0] wb_addr_s6;
    wire  [31:0] wb_wdata_s6;
    wire  [3:0]  wb_sel_s6;
    wire         wb_we_s6;
    wire         wb_stb_s6;
    wire         wb_cyc_s6;
    wire[31:0]   wb_rdata_s6;
    wire         wb_ack_s6;
    wire         wb_err_s6; 

    wire  [31:0] wb_addr_s7;
    wire  [31:0] wb_wdata_s7;
    wire  [3:0]  wb_sel_s7;
    wire         wb_we_s7;
    wire         wb_stb_s7;
    wire         wb_cyc_s7;
    wire[31:0]   wb_rdata_s7;
    wire         wb_ack_s7;
    wire         wb_err_s7;     

// Connecting wires
wire  ext_irq;
wire  irq_timer_o;
wire  uart0_tx;
wire  uart0_rx;
wire  uart1_tx;
wire  uart1_rx;
wire [7:0]  core_dbg_out;
wire [NUM_GPIO-1:0]  gpio_i;
wire [NUM_GPIO-1:0]  gpio_o;
wire [NUM_GPIO-1:0]  gpio_oe;
wire [7:0] uart0_debug;
wire [7:0] uart1_debug;

wire  cfg_uart0_en;
wire  cfg_uart1_en;

wire [1:0]  cfg_test_sig_sel;

wire [31:0]   wb_rdata_timer;
wire wb_ack_timer;
wire wb_err_timer;
wire irq_timer;

wire [31:0]   wb_rdata_uart0;
wire wb_ack_uart0;
wire wb_err_uart0;

wire [31:0]   wb_rdata_uart1;
wire wb_ack_uart1;
wire wb_err_uart1;


//===============RTL==================

assign  ext_irq = irq_timer_o;

// CPU Core and main interconnect
core u_core(
    .clk(clk),
    .rst_n(rst_n),
    .cpu_irq(ext_irq),

    .wb_addr(wb_addr),
    .wb_wdata(wb_wdata),
    .wb_sel(wb_sel),
    .wb_we(wb_we),
    .wb_stb(wb_stb),
    .wb_cyc(wb_cyc),
    .wb_rdata(wb_rdata),
    .wb_ack(wb_ack),
    .wb_err(wb_err),

    .core_dbg_out(core_dbg_out)
);



wb_interconnect #(
    .NUM_SLAVES(8)
    ) 
  u_wb_interconnect(
    .clk(clk),
    .rst_n(rst_n),
//wb master if
    .wb_addr_m0(wb_addr),
    .wb_wdata_m0(wb_wdata),
    .wb_sel_m0(wb_sel),
    .wb_we_m0(wb_we),
    .wb_stb_m0(wb_stb),
    .wb_cyc_m0(wb_cyc),
    .wb_rdata_m0(wb_rdata),
    .wb_ack_m0(wb_ack),
    .wb_err_m0(wb_err),


//wb slave if
    .wb_addr_s0(wb_addr_s0),
    .wb_wdata_s0(wb_wdata_s0),
    .wb_sel_s0(wb_sel_s0),
    .wb_we_s0(wb_we_s0),
    .wb_stb_s0(wb_stb_s0),
    .wb_cyc_s0(wb_cyc_s0),
    .wb_rdata_s0(wb_rdata_s0),
    .wb_ack_s0(wb_ack_s0),
    .wb_err_s0(wb_err_s0),

    .wb_addr_s1(wb_addr_s1),
    .wb_wdata_s1(wb_wdata_s1),
    .wb_sel_s1(wb_sel_s1),
    .wb_we_s1(wb_we_s1),
    .wb_stb_s1(wb_stb_s1),
    .wb_cyc_s1(wb_cyc_s1),
    .wb_rdata_s1(wb_rdata_s1),
    .wb_ack_s1(wb_ack_s1),
    .wb_err_s1(wb_err_s1),

    .wb_addr_s2(wb_addr_s2),
    .wb_wdata_s2(wb_wdata_s2),
    .wb_sel_s2(wb_sel_s2),
    .wb_we_s2(wb_we_s2),
    .wb_stb_s2(wb_stb_s2),
    .wb_cyc_s2(wb_cyc_s2),
    .wb_rdata_s2(wb_rdata_s2),
    .wb_ack_s2(wb_ack_s2),
    .wb_err_s2(wb_err_s2),

    .wb_addr_s3(wb_addr_s3),
    .wb_wdata_s3(wb_wdata_s3),
    .wb_sel_s3(wb_sel_s3),
    .wb_we_s3(wb_we_s3),
    .wb_stb_s3(wb_stb_s3),
    .wb_cyc_s3(wb_cyc_s3),
    .wb_rdata_s3(wb_rdata_s3),
    .wb_ack_s3(wb_ack_s3),
    .wb_err_s3(wb_err_s3),

    .wb_addr_s4(wb_addr_s4),
    .wb_wdata_s4(wb_wdata_s4),
    .wb_sel_s4(wb_sel_s4),
    .wb_we_s4(wb_we_s4),
    .wb_stb_s4(wb_stb_s4),
    .wb_cyc_s4(wb_cyc_s4),
    .wb_rdata_s4(wb_rdata_s4),
    .wb_ack_s4(wb_ack_s4),
    .wb_err_s4(wb_err_s4),  

    .wb_addr_s5(wb_addr_s5),
    .wb_wdata_s5(wb_wdata_s5),
    .wb_sel_s5(wb_sel_s5),
    .wb_we_s5(wb_we_s5),
    .wb_stb_s5(wb_stb_s5),
    .wb_cyc_s5(wb_cyc_s5),
    .wb_rdata_s5(wb_rdata_s5),
    .wb_ack_s5(wb_ack_s5),
    .wb_err_s5(wb_err_s5),   

    .wb_addr_s6(wb_addr_s6),
    .wb_wdata_s6(wb_wdata_s6),
    .wb_sel_s6(wb_sel_s6),
    .wb_we_s6(wb_we_s6),
    .wb_stb_s6(wb_stb_s6),
    .wb_cyc_s6(wb_cyc_s6),
    .wb_rdata_s6(wb_rdata_s6),
    .wb_ack_s6(wb_ack_s6),
    .wb_err_s6(wb_err_s6), 

    .wb_addr_s7(wb_addr_s7),
    .wb_wdata_s7(wb_wdata_s7),
    .wb_sel_s7(wb_sel_s7),
    .wb_we_s7(wb_we_s7),
    .wb_stb_s7(wb_stb_s7),
    .wb_cyc_s7(wb_cyc_s7),
    .wb_rdata_s7(wb_rdata_s7),
    .wb_ack_s7(wb_ack_s7),
    .wb_err_s7(wb_err_s7)          

);
        

// Peripherals
rom_wrapper  u_rom_wrapper(
    .clk(clk),
    .rst_n(rst_n),
    .wb_addr(wb_addr_s0),
    .wb_wdata(wb_wdata_s0),
    .wb_sel(wb_sel_s0),
    .wb_we(wb_we_s0),
    .wb_stb(wb_stb_s0),
    .wb_cyc(wb_cyc_s0),
    .wb_rdata(wb_rdata_s0),
    .wb_ack(wb_ack_s0),
    .wb_err(wb_err_s0)
);
parameter  MEM_ADDR_WIDTH = 10;
sram_wrapper #(.ADDR_WIDTH(MEM_ADDR_WIDTH) ) u_sram_wrapper(
    .clk(clk),
    .rst_n(rst_n),
    .wb_addr(wb_addr_s1),
    .wb_wdata(wb_wdata_s1),
    .wb_sel(wb_sel_s1),
    .wb_we(wb_we_s1),
    .wb_stb(wb_stb_s1),
    .wb_cyc(wb_cyc_s1),
    .wb_rdata(wb_rdata_s1),
    .wb_ack(wb_ack_s1),
    .wb_err(wb_err_s1)    
);

timer   #(
    .ADDR_WIDTH(10)  //
)
u0_timer (
    .clk(clk),
    .rst_n(rst_n),
    //wishbone interface
    .wb_cyc_i(wb_cyc_s2),
    .wb_stb_i(wb_stb_s2), 
    .wb_we_i(wb_we_s2),
    .wb_addr_i(wb_addr_s2[9:0]),
   	.wb_dat_i(wb_wdata_s2),
    .wb_sel_i(wb_sel_s2),
    .wb_err_o(wb_err_timer),
    .wb_ack_o(wb_ack_timer),
    .wb_dat_o(wb_rdata_timer),    
    .IRQ(irq_timer)// interrupt
);

uart   #(
        .ADDR_WIDTH(10)
        )
u0_uart (
    .clk(clk),
    .rst_n(rst_n),

    .uart_debug(uart0_debug),

    .rx(uart0_rx),
    .tx(uart0_tx),

    //wishbone interface
    .wb_cyc_i(wb_cyc_s3),
    .wb_stb_i(wb_stb_s3), 
    .wb_we_i(wb_we_s3),
    .wb_addr_i(wb_addr_s3[9:0]),
   	.wb_dat_i(wb_wdata_s3),
    .wb_sel_i(wb_sel_s3),
    .wb_err_o(wb_err_uart0),
    .wb_ack_o(wb_ack_uart0),
    .wb_dat_o(wb_rdata_uart0)
);


gpio   #(
        .ADDR_WIDTH(10),
        .NUM_GPIO(NUM_GPIO)
        )
u_gpio (
    .clk(clk),
    .rst_n(rst_n),

    .gpio_i(gpio_i),
    .gpio_o(gpio_o),
    .gpio_oe(gpio_oe),

    //wishbone interface
    .wb_cyc_i(wb_cyc_s4),
    .wb_stb_i(wb_stb_s4), 
    .wb_we_i(wb_we_s4),
    .wb_addr_i(wb_addr_s4[9:0]),
   	.wb_dat_i(wb_wdata_s4),
    .wb_sel_i(wb_sel_s4),
    .wb_err_o(wb_err_s4),
    .wb_ack_o(wb_ack_s4),
    .wb_dat_o(wb_rdata_s4)
);



//config and status registers
csr #(
        .ADDR_WIDTH(10)
     )
u_csr (
    .clk(clk),
    .rst_n(rst_n),

    .cfg_uart0_en(cfg_uart0_en),
    .cfg_uart1_en(cfg_uart1_en),
    .cfg_test_sig_sel(cfg_test_sig_sel),
    .cfg_xfence_timer(cfg_xfence_timer),
    .cfg_xfence_uart0(cfg_xfence_uart0),
    .cfg_xfence_uart1(cfg_xfence_uart1),    

    //wishbone interface
    .wb_cyc(wb_cyc_s5),
    .wb_stb(wb_stb_s5), 
    .wb_we(wb_we_s5),
    .wb_addr(wb_addr_s5[9:0]),
   	.wb_wdata(wb_wdata_s5),
    .wb_sel(wb_sel_s5),
    .wb_err(wb_err_s5),
    .wb_ack(wb_ack_s5),
    .wb_rdata(wb_rdata_s5)      
      );

uart   #(
        .ADDR_WIDTH(10)
        )
u1_uart (
    .clk(clk),
    .rst_n(rst_n),

    .uart_debug(uart1_debug),

    .rx(uart1_rx),
    .tx(uart1_tx),

    //wishbone interface
    .wb_cyc_i(wb_cyc_s6),
    .wb_stb_i(wb_stb_s6), 
    .wb_we_i(wb_we_s6),
    .wb_addr_i(wb_addr_s6[9:0]),
   	.wb_dat_i(wb_wdata_s6),
    .wb_sel_i(wb_sel_s6),
    .wb_err_o(wb_err_uart1),
    .wb_ack_o(wb_ack_uart1),
    .wb_dat_o(wb_rdata_uart1)
);


default_slave   u_default_slave (
    .clk(clk),
    .rst_n(rst_n),

    //wishbone interface
    .wb_cyc(wb_cyc_s7),
    .wb_stb(wb_stb_s7), 
    .wb_we(wb_we_s7),
    .wb_sel(wb_sel_s7),
    .wb_addr(wb_addr_s7[31:0]),
   	.wb_wdata(wb_wdata_s7),
    .wb_err(wb_err_s7),
    .wb_ack(wb_ack_s7),
    .wb_rdata(wb_rdata_s7)
);



pinmux   u_pinmux(
.clk(clk),
.rst_n(rst_n),

.test_mode(test_mode_pin),

.uart0_rx(uart0_rx),
.uart0_tx(uart0_tx),

.uart1_rx(uart1_rx),
.uart1_tx(uart1_tx),

.gpio_o(gpio_o),
.gpio_oe(gpio_oe),
.gpio_i(gpio_i),

//test signal
.test_sig0(core_dbg_out),  //TODO
.test_sig1(uart0_debug),  //
.test_sig2(uart1_debug),  //

//inout pad
.PAD_IO_0(PAD_IO_0),
.PAD_IO_1(PAD_IO_1),
.PAD_IO_2(PAD_IO_2),
.PAD_IO_3(PAD_IO_3),
.PAD_IO_4(PAD_IO_4),
.PAD_IO_5(PAD_IO_5),
.PAD_IO_6(PAD_IO_6),
.PAD_IO_7(PAD_IO_7),

//config
.cfg_uart0_en(cfg_uart0_en),
.cfg_uart1_en(cfg_uart1_en),
.cfg_test_sig_sel(cfg_test_sig_sel)

              
);


x_fence  u_x_fence
(

//cfg
  .cfg_xfence_timer(cfg_xfence_timer),
  .cfg_xfence_uart0(cfg_xfence_uart0),
  .cfg_xfence_uart1(cfg_xfence_uart1),

//input from timer
  .wb_rdata_timer(wb_rdata_timer),
  .wb_ack_timer(wb_ack_timer),
  .wb_err_timer(wb_err_timer),
  .irq_timer(irq_timer),

//input from uart0
  .wb_rdata_uart0(wb_rdata_uart0),
  .wb_ack_uart0(wb_ack_uart0),
  .wb_err_uart0(wb_err_uart0),

//input from uart1
  .wb_rdata_uart1(wb_rdata_uart1),
  .wb_ack_uart1(wb_ack_uart1),
  .wb_err_uart1(wb_err_uart1),

//output for timer
  .wb_rdata_s2(wb_rdata_s2),
  .wb_ack_s2(wb_ack_s2),
  .wb_err_s2(wb_err_s2),
  .irq_timer_o(irq_timer_o),

//output for uart0
  .wb_rdata_s3(wb_rdata_s3),
  .wb_ack_s3(wb_ack_s3),
  .wb_err_s3(wb_err_s3),

//output for uart1
  .wb_rdata_s6(wb_rdata_s6),
  .wb_ack_s6(wb_ack_s6),
  .wb_err_s6(wb_err_s6)

);

//VCS coverage off

//firstly , create some covers to make sure no over constraint or other env issues
cover_ADD_instr: cover property (@(posedge clk) disable iff (~rst_n) 
                ((u_core.instr[6:0] == 7'b0110011 ) && (u_core.instr[14:12] == 3'b000) && u_core.state== 5'b00100));
cover_uart_send: cover property (@(posedge clk) disable iff (~rst_n) tx==1'b0 && u0_uart.tx_state== 4'b0001); 
cover_timer_IRQ: cover property (@(posedge clk) disable iff (~rst_n) u_timer.IRQ ); 


//====================
//ASSERTION memory related instrctions:SW
//====================
/*
property op_SW_prop3;     
  @(posedge clk) disable iff (~rst_n)
((u_core.instr[6:0] == 7'b0100011) && (u_core.instr[14:12] == 3'b010)  && (u_core.state== 5'b00100) && (u_core.regs[u_core.instr[24:20]]==5) && (u_core.regs[u_core.instr[19:15]]==32'h2000_0000) && (u_core.imm_S==32'h0000_0000))
    |-> ##[1:6] (u_sram_wrapper.memory[0][31:0] == 5) ;
endproperty
*/
bit [31:0] sym_data;
assume_stable_sym_data:  assume property( @(posedge clk)
    $stable(sym_data)
);
bit [31:0] sym_addr; //bus memory address
assume_stable_sym_addr:  assume property( @(posedge clk)
    $stable(sym_addr) && (sym_addr[MEM_ADDR_WIDTH-1+2:2]<2**MEM_ADDR_WIDTH)&&(sym_addr[31:29]==3'b001)&&(sym_addr[28:MEM_ADDR_WIDTH-1+2]==0)&&(sym_addr[1:0]==0)
);
property op_SW_prop3;     
  @(posedge clk) disable iff (~rst_n)
((u_core.instr[6:0] == 7'b0100011) && (u_core.instr[14:12] == 3'b010)  && (u_core.state== 5'b00100) && (u_core.regs[u_core.instr[24:20]]==sym_data) && ((u_core.regs[u_core.instr[19:15]]+u_core.imm_S)==sym_addr))
    |-> ##[1:3] (u_sram_wrapper.memory[sym_addr[MEM_ADDR_WIDTH-1+2:2]] == sym_data) ;
endproperty        
assert_SW3: assert property (op_SW_prop3 );


//assert_interrupt:assert property (@(posedge clk) disable iff (~rst_n) (u_timer.IRQ |-> ##[1:3] u_core.state==TRAP));
//CPU system level


//UART system level
`define UART_DIV 32'h4000_1000 
`define UART_SEND_DATA 32'h4000_1004 
`define UART_RECE_DATA 32'h4000_1008 
`define UART_STATUS 32'h4000_100c
`define UART_CTRL 32'h4000_1010

property op_SW_UART_DIV;     
  @(posedge clk) disable iff (~rst_n)
((u_core.instr[6:0] == 7'b0100011) && (u_core.instr[14:12] == 3'b010)  && (u_core.state== 5'b00100) && (u_core.regs[u_core.instr[24:20]]==sym_data) && ((u_core.regs[u_core.instr[19:15]]+u_core.imm_S)==`UART_DIV))
    |-> ##[1:3] (u0_uart.csr_uart_div == sym_data) ;        
endproperty
assert_SW_UART_DIV: assert property (op_SW_UART_DIV);

property op_SB_UART_SEND_DATA; //if write UART_SEND_DATA register, then uart tx fifo will get this data      
  bit [$clog2(UART_FIFO_DEPTH)-1:0] local_ptr;
  @(posedge clk) disable iff (~rst_n)
((u_core.instr[6:0] == 7'b0100011) && (u_core.instr[14:12] == 3'b000)  && (u_core.state== 5'b00100) && (u_core.regs[u_core.instr[24:20]]==sym_data) && ((u_core.regs[u_core.instr[19:15]]+u_core.imm_S)==`UART_SEND_DATA) &&(~u0_uart.tx_fifo_full),local_ptr=u0_uart.u_uart_tx_fifo.wr_ptr)
    |-> ##[1:3] (u0_uart.u_uart_tx_fifo.fifo_mem[local_ptr] == sym_data[7:0]) ;        
endproperty
assert_SW_UART_SEND_DATA: assert property (op_SB_UART_SEND_DATA);

property op_SB_UART_CTRL; //if write UART_CTRL register, u0_uart.csr_uart_ctrl will get it      
  @(posedge clk) disable iff (~rst_n)
((u_core.instr[6:0] == 7'b0100011) && (u_core.instr[14:12] == 3'b000)  && (u_core.state== 5'b00100) && (u_core.regs[u_core.instr[24:20]]==sym_data) && ((u_core.regs[u_core.instr[19:15]]+u_core.imm_S)==`UART_SEND_DATA))
    |-> ##[1:3] (u0_uart.rx_fifo_rd_data == sym_data[7:0]) ;        
endproperty
assert_SB_UART_CTRL: assert property (op_SB_UART_CTRL);

property op_LB_UART_RECE_DATA; //if read UART_RECE_DATA register, rd(register destination) will get it      
  @(posedge clk) disable iff (~rst_n)
((u_core.instr[6:0] == 7'b0000011) && (u_core.instr[14:12] == 3'b000)  && (u_core.state== 5'b00100) && ((u_core.regs[u_core.instr[19:15]]+u_core.imm_S)==`UART_RECE_DATA) ,rd_idx=u_core.instr[11:7])
    |-> ##[1:3] (u0_uart. == sym_data[7:0]) ;        
endproperty
assert_LB_UART_RECE_DATA: assert property (op_LB_UART_RECE_DATA);


assert_uart_safety:assert property (@(posedge clk) disable iff (~rst_n) ((u_core.instr[6:0] == 7'b0100011) |-> ##[1:3] ~u0_uart.tx_fifo_full));

//Timer system level
assert_interrupt:assert property (@(posedge clk) disable iff (~rst_n) (u0_timer.IRQ |-> ##[1:3] u_core.state==TRAP));
//GPIO system level


//VCS coverage on

endmodule
