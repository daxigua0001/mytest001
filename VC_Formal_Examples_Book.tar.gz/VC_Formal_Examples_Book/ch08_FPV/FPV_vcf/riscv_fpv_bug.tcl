set_fml_appmode FPV

set abstract 1
set design soc

if {0} {
set_blackbox -cells { u_sram_wrapper u0_uart u0_timer u1_timer u1_uart u_csr  u_gpio u_pinmux u_rom_wrapper u_wb_interconnect u_cpu.u_biu} 
}

# Compilation Step   #note -pvalue+soc.u_sram_wrapper.ADDR_WIDTH=2
if {$abstract} {
read_file -top $design -format sverilog -sva -vcs {-f riscv.f  -pvalue+soc.MEM_ADDR_WIDTH=2} 
#read_file -top $design -format sverilog -sva -vcs {-f riscv.f +define+FPV_BUG_FIX -pvalue+soc.MEM_ADDR_WIDTH=2} 
#read_file -top $design -format sverilog -sva -vcs {-f riscv.f +define+FPV_BUG_FIX+ASSERT_BUG_FIX  -pvalue+soc.MEM_ADDR_WIDTH=2} 
} else {
read_file -top $design -format sverilog -sva -vcs {-f riscv.f  }
}

# Clock Definitions 
create_clock clk -period 100

# Reset Definitions 
create_reset rst_n -sense low

if {$abstract} {
        fvassume regs_shrink_rs1 -expr {u_cpu.instr_rs1[4:0]<4}
        fvassume regs_shrink_rs2 -expr {u_cpu.instr_rs2[4:0]<4}
        fvassume regs_shrink_rd  -expr {u_cpu.instr_rd[4:0] <4}

#UART set CYCLES_PER_BIT=8, LOOPBACK mode
snip_driver  {u0_uart.csr_uart_div}
set_constant -value 8 u0_uart.csr_uart_div[31:0]

snip_driver u0_uart.loopback_en
set_constant -value 1 u0_uart.loopback_en        
}        

fvcover cov_uart0_bad -expr {{cfg_xfence_timer,cfg_xfence_uart0,cfg_xfence_uart1} ==3'd2 [*3]}
fvcover cov_uart1_bad -expr {{cfg_xfence_timer,cfg_xfence_uart0,cfg_xfence_uart1} ==3'd1 [*3]}
fvcover cov_timer_bad -expr {{cfg_xfence_timer,cfg_xfence_uart0,cfg_xfence_uart1} ==3'd4 [*3]}
fvcover cov_all_bad   -expr {{cfg_xfence_timer,cfg_xfence_uart0,cfg_xfence_uart1} ==3'd0 [*3]}

# Initialisation Commands 
sim_run -stable
sim_save_reset

report_blackbox

## Proof
check_fv -block 
 
## Reports
report_fv -list > results.txt
