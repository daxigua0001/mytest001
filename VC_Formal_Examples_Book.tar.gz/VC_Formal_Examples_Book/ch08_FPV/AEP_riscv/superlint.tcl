clear -all
check_superlint -init
#config_rtlds -rule -disable -domain {LINT DFT AUTO_FORMAL}
#config_rtlds -rule -enable -tag {INT_NR_OVFL}
config_rtlds -rule -enable -tag {FSM_IS_DDLK}


analyze -clear
analyze -sv09 -f riscv.f 
elaborate
check_superlint -extract

#elaborate -bbox_a 1024

# Setup clocks and reset
clock clk 
reset {~rst_n}

# Extract the checks 
check_superlint -extract

check_superlint -prove
