set_fml_appmode AEP

set design soc 

read_file -top $design -format sverilog -aep fsm_sss -vcs { -f riscv.f }
#read_file -format sverilog -top $design -cov fsm_state+fsm_trans -vcs {-f riscv.f -cm_fsmopt sequence}

create_clock clk -period 100 
create_reset rst_n -sense low

sim_run -stable 
sim_save_reset

check_fv
