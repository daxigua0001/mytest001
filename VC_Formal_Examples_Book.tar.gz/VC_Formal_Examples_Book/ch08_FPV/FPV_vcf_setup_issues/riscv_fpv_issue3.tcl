set_fml_appmode FPV

set design sram_wrapper

# Compilation Step 
read_file -top $design -format sverilog -sva -vcs {-f riscv.f +define+BUF_WR_DATA}

# Clock Definitions 
create_clock clk -period 100

# Reset Definitions 
create_reset rst_n -sense low

# Initialisation Commands 
sim_run -stable
sim_save_reset

# Proof
check_fv -block 

# Reports
report_fv -list > results.txt
