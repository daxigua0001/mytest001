set_fml_appmode FPV

set design soc

#set_blackbox -design sram_wrapper
#set_blackbox -cells <hierarchical instance_names>
set_blackbox -cells u_sram_wrapper

# Compilation Step 
read_file -top $design -format sverilog -sva -vcs {-f riscv.f}

# Clock Definitions 
create_clock clk -period 100

# Reset Definitions 
create_reset rst_n -sense low

#fvassume test_mode_inactive_depth1 -expr {test_mode_pin==1'b0} -depth 1 ; #solution for issue5

# Initialisation Commands 
sim_run -stable
sim_save_reset

report_blackbox

# Proof
check_fv -block 
 
# Reports
report_fv -list > results.txt
