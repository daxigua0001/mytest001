clear -all


#analyze +define+TECH__CDCBUF__DISABLE_BEHAVIORAL_VERILOG +define+ABV -sv12  -f $flist -bbox_m $BBOX_CELLS -bbox_m $BBOX_DESIGN spi_s__top.sv ../../../../common/gfx_new_kc_fifo.behavioral.v ../../../../common/gfx_new_kc_fifo_reg_out.behavioral.v cdc_stdlib.sv tcbn05bwph210l6p51cnodmrklvt_nopwr.v tcbn05bwph210l6p51cnodamdcstmlvt_nopwr.v prim.v
#elaborate -disable_auto_bbox -top $design
analyze -sv12 -f riscv.f 

# Elaborate design and properties
#elaborate -top soc -bbox_i  u_sram_wrapper.memory
elaborate -top soc -bbox_a 20480 -keep_array_for_module sram_wrapper ;#-no_bbox_i u_sram_wrapper.memory
# Set up Clocks and Resets
clock clk
reset ~rst_n

# Get design information to check general complexity
get_design_info
get_design_info -list bbox_inst

#liang added 
#cover -name test {addr0 == 8 ##10 addr0 == 3}
#cover -name instr {u_core.instr != 0}
#cover -name state_FETCH {u_core.state == 5'b00001}
#cover -name state_WAIT {u_core.state == 5'b00010}
#cover -name state_EXE {u_core.state == 5'b00100}
#cover -name state_WAIT_MEM {u_core.state == 5'b01000}
#cover -name state_DO_TRAP {u_core.state == 5'b10000}
#cover -name rd_data7F {u_rom_wrapper.rdata[6:0] == 7'h7F}
#cover -name rd_datab4 {u_rom_wrapper.rdata[6:0] == 7'hb4}
#cover -name rd_data70 {u_rom_wrapper.rdata[6:0] == 7'h70}
#cover -name wb_rd_data7F {u_wb_interconnect.wb_rdata_s0[6:0] == 7'h7F}
#cover -name wb_rd_datab4 {u_wb_interconnect.wb_rdata_s0[6:0] == 7'hb4}
#cover -name wb_rd_data70 {u_wb_interconnect.wb_rdata_s0[6:0] == 7'h70}
#cover -name top_rd_data7F {u_wb_interconnect.read_data[6:0] == 7'h7F}
#cover -name top_rd_datab4 {u_wb_interconnect.read_data[6:0] == 7'hb4}
#cover -name top_rd_data70 {u_wb_interconnect.read_data[6:0] == 7'h70}
#
#cover -name core_wb_rdata7F {u_core.wb_rdata[6:0] == 7'h7F}
#cover -name core_wb_rdatab4 {u_core.wb_rdata[6:0] == 7'hb4}
#cover -name core_wb_rdata70 {u_core.wb_rdata[6:0] == 7'h70}
#
#cover -name core_bus_rdata7F {u_core.bus_rdata[6:0] == 7'h7F}
#cover -name core_bus_rdatab4 {u_core.bus_rdata[6:0] == 7'hb4}
#cover -name core_bus_rdata70 {u_core.bus_rdata[6:0] == 7'h70}
#
#cover -name core_ins_rdata7F {u_core.instr[6:0] == 7'h7F}
#cover -name core_ins_rdatab4 {u_core.instr[6:0] == 7'hb4}
#cover -name core_ins_rdata70 {u_core.instr[6:0] == 7'h70}

# Prove properties
prove -all

# Report proof results
report
