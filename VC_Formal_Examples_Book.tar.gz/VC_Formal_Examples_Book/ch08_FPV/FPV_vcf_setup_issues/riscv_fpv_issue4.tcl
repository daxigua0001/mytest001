set_fml_appmode FPV

set design sram_wrapper 

# Compilation Step 
read_file -top $design -format sverilog -sva -vcs {-f riscv.f }

# Clock Definitions 
create_clock clk -period 100

# Reset Definitions 
create_reset rst_n -sense low

# Initialisation Commands 
sim_run -stable
sim_save_reset

fvassume wb_we_eq1 -expr {wb_we == 1} ; #conflict constraint 
fvassume wb_we_eq0 -expr {wb_we == 0} ; #conflict constraint

# Proof
check_fv -block 

# Reports
report_fv -list > results.txt
