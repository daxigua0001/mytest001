set_fml_appmode FPV

set design sram_wrapper

set_blackbox -cells u_sram_wrapper

# Compilation Step 
read_file -top $design -format sverilog -sva -vcs {-f riscv.f}

# Clock Definitions 
create_clock clk -period 100

# Reset Definitions 
create_reset rst_n -sense low

# Initialisation Commands 
sim_run -stable
sim_save_reset

report_blackbox

#fvassume assume_wb_sel_Lower2_never0 -expr { wb_sel&4'b0011 != 0} ;#setup issue6
fvassume assume_wb_sel_Lower2_never0 -expr { (wb_sel&4'b0011) != 0} ;#setup issue6,fix

fvcover cover_wb_sel_lower2_00 -expr {wb_sel[1:0] ==2'b00}
fvcover cover_wb_sel_lower2_01 -expr {wb_sel[1:0] ==2'b01}
fvcover cover_wb_sel_lower2_10 -expr {wb_sel[1:0] ==2'b10}
fvcover cover_wb_sel_lower2_11 -expr {wb_sel[1:0] ==2'b11}

# Proof
check_fv -block 
 
# Reports
report_fv -list > results.txt
