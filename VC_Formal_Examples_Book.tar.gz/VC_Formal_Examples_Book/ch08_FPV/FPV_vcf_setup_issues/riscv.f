rtl/cpu.sv
rtl/rom_wrapper.sv
rtl/sram_wrapper.sv
rtl/soc.sv
rtl/wb_interconnect.sv
rtl/biu.v
rtl/default_slave.v
rtl/pad_io.v
rtl/pinmux.v
rtl/csr.v

rtl/UART/uart.v
rtl/UART/uart_tx.v
rtl/UART/uart_rx.v
rtl/UART/fifo.v
rtl/UART/cg.v

rtl/TIMER/timer.v
rtl/TIMER/timer_assert.sv
rtl/TIMER/timer_assume.sv

rtl/gpio.v
rtl/x_fence.v
