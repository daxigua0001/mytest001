set_fml_appmode FPV

set design timer 

# Compilation Step 
read_file -top $design -format sverilog -sva -vcs {-f riscv.f}

# Clock Definitions 
create_clock clk -period 100

# Reset Definitions 
create_reset rst_n -sense low

# Initialisation Commands 
sim_run -stable
sim_save_reset

fvassert ast_t -expr { irq |-> !irq}

report_blackbox

# Proof
check_fv -block 
 
# Reports
report_fv -list > results.txt
