set_fml_appmode FPV

set design soc

# Enable Formal Signoff metrics
signoff_config -type all

# Compilation Step 
read_file -top $design -format sverilog -sva -vcs {-f riscv.f}

# Clock Definitions 
create_clock clk -period 100

# Reset Definitions 
create_reset rst_n -sense high;setup issue 2: wrong constraint
#create_reset rst_n -sense low ;setup issue 2 fix way 

# Initialisation Commands 
sim_run -stable
sim_save_reset

fvcover cover_state_depth5 -expr {##5 soc.u_core.state[4:0]!=0}

# Proof
check_fv -block 

# Reports
report_fv -list > results.txt
