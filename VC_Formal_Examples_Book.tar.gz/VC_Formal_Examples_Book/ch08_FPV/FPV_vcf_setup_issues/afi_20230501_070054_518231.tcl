source -echo riscv_fpv_issue3.tcl
0gui
