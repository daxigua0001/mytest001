
module top ();

parameter ADDR_WIDTH = 8;

reg clk=0;
reg rst_n;
always  #5 clk = ~clk;
initial begin
clk =0;
rst_n=1'b0;
#30;
rst_n=1'b1;
end


reg  	    wb_cyc_i;
reg  	    wb_stb_i; 
reg          wb_we_i;
reg  [ADDR_WIDTH-1:0]	wb_addr_i;
reg  [31:0]	wb_dat_i;
reg  [3:0]	wb_sel_i;

reg rx;


initial begin
#100; //skip reset stage
rx = 1'b1;
wb_operate(1,'h8c,'h01); //configure UART as loopback mode

wb_operate(1,'h80,'h55);
wb_operate(1,'h80,'haa);
wb_operate(1,'h80,'h00);
wb_operate(1,'h80,'hFF);
@(posedge clk)
wb_we_i<=1'b0;


rx=1'b0;
#30;
rx=1'b1;
#30;
rx=1'b0;
#30;
rx=1'b1;
#20;
rx=1'b0;
#80;
repeat(4) begin
rx=1'b1;
#80;
rx=1'b0;
#80;
end
rx=1'b1;


#24000 
$finish;
end

task  automatic wb_operate;
    input wb_we;
    input [7:0] wb_addr;
    input [7:0] wb_data;
    @(posedge clk) begin
     wb_we_i<=wb_we;
     wb_cyc_i<=1'b1;
     wb_stb_i<=1'b1;
     wb_addr_i<=wb_addr;
     if(wb_we) begin
     wb_dat_i<=wb_data;
     wb_sel_i<=4'b0001;
     end
     end
endtask

wire wb_stall_o,wb_ack_o;
wire [31:0] wb_dat_o;
wire [7:0] uart_debug;
uart u_uart(
.clk(clk),
.clk_cg_tx(clk_cg_tx),
.clk_cg_rx(clk_cg_rx),
.rst_n(rst_n),
.rx(rx),
.tx(tx),
.wb_cyc_i(wb_cyc_i),
.wb_stb_i(wb_stb_i), 
.wb_we_i(wb_we_i),
.wb_addr_i(wb_addr_i),
.wb_dat_i(wb_dat_i),
.wb_sel_i(wb_sel_i),
.wb_stall_o(wb_stall_o),
.wb_ack_o(wb_ack_o),
.wb_dat_o(wb_dat_o),
.uart_tx_busy(uart_tx_busy),
.uart_rx_busy(uart_rx_busy),
.uart_debug(uart_debug)
);

wire csr_uart_tx_cg_disable = 1'b0;
clock_gate clock_gate_uart_tx(
.clk(clk),
.enable_in(uart_tx_busy||csr_uart_tx_cg_disable),
.gclk(clk_cg_tx) );
wire csr_uart_rx_cg_disable = 1'b0;
clock_gate clock_gate_uart_rx(
.clk(clk),
.enable_in(uart_rx_busy||csr_uart_rx_cg_disable),
.gclk(clk_cg_rx) );

endmodule
