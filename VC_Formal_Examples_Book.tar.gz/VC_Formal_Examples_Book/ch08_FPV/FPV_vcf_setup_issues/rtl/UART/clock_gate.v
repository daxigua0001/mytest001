module clock_gate (
    gclk,                      // Gated clock
    clk,                       // Clock
    enable_in                  // Clock enable
);
output         gclk;           // Gated clock
input          clk;            // Clock
input          enable_in;      // Clock enable

//=============================================================================
// CLOCK GATE: LATCH + AND
//=============================================================================

// LATCH the enable signal
reg     enable_latch;
always @(clk or enable_in)
  if (~clk)
    enable_latch = enable_in;

// AND gate
assign  gclk = (clk & enable_latch);

endmodule

