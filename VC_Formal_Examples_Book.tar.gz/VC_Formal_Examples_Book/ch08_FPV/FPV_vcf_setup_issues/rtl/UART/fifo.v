
module fifo(
	clk,
	rst_n,
	fifo_wr,
	fifo_rd,
	fifo_wr_data,
	
	fifo_full,
	fifo_rd_data,
	fifo_empty

);
	
	parameter WIDTH = 8;
	parameter DEPTH = 2;
	parameter ADDR_WIDTH = $clog2(DEPTH);
	
	input						clk;
	input						rst_n;
	input						fifo_wr;
	input						fifo_rd;
	input	[WIDTH-1:0]			fifo_wr_data;
	
	output						fifo_full;
	output						fifo_empty;
	output reg	[WIDTH-1:0]			fifo_rd_data;
	
	reg [ADDR_WIDTH-1:0]		rd_ptr;
	reg [ADDR_WIDTH-1:0]		wr_ptr;
	reg [ADDR_WIDTH:0]			rd_ptr_e;
	reg [ADDR_WIDTH:0]			wr_ptr_e;
    reg [WIDTH-1:0]             fifo_mem[0:DEPTH-1];

	
	assign rd_ptr = rd_ptr_e[ADDR_WIDTH-1:0];
	assign wr_ptr = wr_ptr_e[ADDR_WIDTH-1:0];
	
	assign fifo_full = (rd_ptr_e[ADDR_WIDTH] != wr_ptr_e[ADDR_WIDTH] && rd_ptr == wr_ptr )?1'b1:1'b0;
	assign fifo_empty = (rd_ptr_e == wr_ptr_e)?1'b1:1'b0;
	
	always@(posedge clk or negedge rst_n)
	if(!rst_n) begin
		rd_ptr_e <= 0;
        fifo_rd_data<= fifo_mem[rd_ptr];
	end else if( fifo_rd && ~fifo_empty ) begin
		rd_ptr_e <= rd_ptr_e + 1'b1;
        fifo_rd_data<= fifo_mem[rd_ptr];
    end
	
	always@(posedge clk or negedge rst_n)
	if(!rst_n) begin
		wr_ptr_e <= 0;
	end else if( fifo_wr && ~fifo_full ) begin
		wr_ptr_e <= wr_ptr_e + 1'b1;
        fifo_mem[wr_ptr] <= fifo_wr_data;
    end
	
endmodule
