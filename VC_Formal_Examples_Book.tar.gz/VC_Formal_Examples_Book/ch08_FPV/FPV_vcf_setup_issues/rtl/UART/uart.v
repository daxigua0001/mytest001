//  Register Description
//  let base address = 0x00000000
// 
//  0x00000000 : 8-bit data register (DATA)                            [ Read & Write ]
//      To transmit a byte      : Write to this register
//      To get recieved value   : Read from this register.
//          if no value is recieved or value is already read then reg will contain -1.
//   
//  0x00000004 : 8-bit status        (STATUS)                            [ Read Only ]
//      bit[0] = receive_buf_valid :   recieve buffer has a valid value
//      bit[1] = tx_busy        :   Transmitter is busy transmitting a byte  
// 
//  0x00000008 : 32-bit Clock Divider Register (BAUD_DIV)                 [ Read & Write ]
//      Clock Divider register sets the speed of uart tx & rx.
//      if your clk freq is Fc and target baud frequency is Fb then formula for correct value 
//      of it is:     value = (Fc / Fb) - 2;
//  0x0000000C : 8-bit UART work mode control (UART_CTRL)                 [ Read & Write ]
//      control register of uart work mode: loopback enable.
//      bit[0] = loopback_en:   configure UART loopback work mode, connect tx to rx





`define CSR_DATA_ADDR 8'h80
`define CSR_DIV_ADDR 8'h84
`define CSR_STATUS_ADDR 8'h88
`define CSR_CTRL_ADDR 'h8c

module uart #(parameter ADDR_WIDTH=8)(
input clk,
input rst_n,
input rx,
output tx,
//wishbone interface
input		    wb_cyc_i,
input		    wb_stb_i, 
input           wb_we_i,
input	[ADDR_WIDTH-1:0]	wb_addr_i,
input	[31:0]	wb_dat_i,
input	[3:0]	wb_sel_i,
output	wire	wb_stall_o,
output	reg		wb_ack_o,
output	reg	[31:0] wb_dat_o,
output  uart_tx_busy, //for UART clock gating feature,transmit block busy
output  uart_rx_busy, //for UART clock gating feature,receive block busy
output  wire [7:0] uart_debug
);

//UART CSR registers
reg [7:0]  csr_status;
reg [7:0]  csr_data ;
reg [31:0] csr_div;
reg [7:0] csr_ctrl;

//UART clock gate logic
wire clk_cg_tx; //gated clock for transmit
wire clk_cg_rx; //gated clock for receive
wire csr_uart_tx_cg_free_run= 1'b1;
clock_gate clock_gate_uart_tx(
.clk(clk),
.enable_in(uart_tx_busy||csr_uart_tx_cg_free_run),
.gclk(clk_cg_tx) );
wire csr_uart_rx_cg_free_run = 1'b1;
clock_gate clock_gate_uart_rx(
.clk(clk),
.enable_in(uart_rx_busy||csr_uart_rx_cg_free_run),
.gclk(clk_cg_rx) );

wire tx_is_idle;
wire tx_fifo_full;
wire tx_wb_wr_fifo = wb_we_i & (wb_addr_i==`CSR_DATA_ADDR)& wb_cyc_i & wb_stb_i & (~tx_fifo_full);
assign wb_stall_o =1'b0; // not support stall to CPU
assign wb_ack_o= (~tx_fifo_full) & tx_wb_wr_fifo; //just not respond to CPU when fifo is full

wire [3:0] tx_state;
wire [3:0] rx_state;
assign uart_debug = {rx_state,tx_state};

wire [7:0] tx_fifo_rd_data;
reg fifo_read;
wire tx_fifo_empty;
always @(posedge clk or negedge rst_n)
        if(~rst_n)
        fifo_read<=1'b0;
        else if(fifo_read)
        fifo_read<=1'b0;        
        else if(~tx_fifo_empty & tx_is_idle)
        fifo_read<=1'b1;

fifo u_uart_tx_fifo(
    .clk(clk),
	.rst_n(rst_n),
	.fifo_wr(tx_wb_wr_fifo),
	.fifo_rd(fifo_read),
	.fifo_wr_data(wb_dat_i),
	.fifo_full(tx_fifo_full),
	.fifo_rd_data(tx_fifo_rd_data),
	.fifo_empty(tx_fifo_empty));



wire [7:0] send_reg= tx_fifo_rd_data; 

uart_tx u_uart_tx (
.clk(clk_cg_tx),
.rst_n(rst_n),
.baud_div_reg(csr_div),
.tx_data_ready(fifo_read),
.tx_data(send_reg),
.tx(tx),
.tx_is_idle(tx_is_idle),
.state(tx_state));

assign uart_tx_busy = fifo_read | ~tx_is_idle;

wire [7:0] rx_data;

uart_rx u_uart_rx (
.clk(clk),
.clk_cg(clk_cg_rx),
.rst_n(rst_n),
.baud_div_reg(csr_div),
.rx_data_valid(rx_data_valid),
.rx_data(rx_data),
.rx_busy(uart_rx_busy),
.state(rx_state),
.rx(csr_ctrl[0] ? tx : rx)); //implement loopback mode

wire rx_fifo_read = ~wb_we_i & (wb_addr_i==`CSR_DATA_ADDR)& wb_cyc_i & wb_stb_i ;
wire [7:0] rx_fifo_rd_data;


fifo u_uart_rx_fifo(
    .clk(clk),
	.rst_n(rst_n),
	.fifo_wr(rx_data_valid&~rx_fifo_full),
	.fifo_rd(rx_fifo_read),
	.fifo_wr_data(rx_data),
	.fifo_full(rx_fifo_full),
	.fifo_rd_data(rx_fifo_rd_data),
	.fifo_empty(rx_fifo_empty));





//Following part is for UART CSR registers' logic

// Read enables
wire csr_data_re = (wb_addr_i[7:4]=='h8) ? !wb_we_i & wb_stb_i  & wb_sel_i[0] : 1'b0;
// output data bus
reg [31:0] csr_mux_out;
always@*
case(wb_addr_i)
        `CSR_DATA_ADDR: csr_mux_out = rx_fifo_rd_data;
        `CSR_DIV_ADDR:  csr_mux_out = csr_div;
        `CSR_STATUS_ADDR:   csr_mux_out = csr_status;
        `CSR_CTRL_ADDR:  csr_mux_out = csr_ctrl;
endcase
always @(posedge clk or negedge rst_n)
   if(~rst_n)
     wb_dat_o<=32'h0000_0000; 
    else if(csr_data_re)  begin
     wb_dat_o<=csr_mux_out; 
    end

wire [3:0] csr_div_we=(wb_addr_i==`CSR_DIV_ADDR) ? {4{wb_we_i & wb_stb_i}} & wb_sel_i : 4'b0000;
always @(posedge clk or negedge rst_n)
   if(~rst_n)
     csr_div<=32'h0000_0008; //default set as 9600
    else   begin
     if(csr_div_we[0])
         csr_div[7:0]<=wb_dat_i[7:0];
     if(csr_div_we[1])
         csr_div[15:8]<=wb_dat_i[7:0];
     if(csr_div_we[2])
         csr_div[23:16]<=wb_dat_i[7:0];
     if(csr_div_we[3])
         csr_div[31:24]<=wb_dat_i[7:0];
    end

wire [3:0] csr_ctrl_we=(wb_addr_i==`CSR_CTRL_ADDR) ? {4{wb_we_i & wb_stb_i}} & wb_sel_i : 4'b0000;

always @(posedge clk or negedge rst_n)
   if(~rst_n)
     csr_ctrl[7:0]<=8'h00; //default set as normal work mode 
    else   begin
     if(csr_ctrl_we[0])
         csr_ctrl[7:0]<=wb_dat_i[7:0];
    end



//SV assertions

//define a certain random send_data
wire [7:0] sym_send_data;
assume_stable_send_data:  assume property( @(posedge clk)
    $stable(sym_send_data)
);
/*
assert_receive_eq_send: assert property ( 
    logic [7:0] send_data;
    @(posedge clk) disable iff(~rst_n) 
    tx_wb_wr_fifo, send_data = wb_dat_i[7:0]  |-> ##[52*11: 5*52*14] rx_data_valid && (rx_data == send_data)
);
*/
/* note book back up , use local variable
 property assert_receive_eq_send2; 
    bit [7:0] send_data;
    @(posedge clk) disable iff (~rst_n)
    (tx_wb_wr_fifo , send_data = wb_dat_i[7:0])  |-> ##[52*9: 5*52*14] rx_data_valid && (rx_data == send_data) ;
endproperty

//note book: 13hours depth to 1876
 property assert_receive_eq_send2; 
    bit [7:0] send_data;
    @(posedge clk) disable iff (~rst_n)
    (tx_wb_wr_fifo && (wb_dat_i[7:0]==sym_send_data))  |-> ##[52*9: 3*52*11] rx_data_valid && (rx_data == sym_send_data) ;
endproperty
*/
`define CYCLES_PER_BIT 8
property receive_eq_send_symbolic; 
    bit [7:0] send_data;
    @(posedge clk) disable iff (~rst_n)
    (tx_wb_wr_fifo && (wb_dat_i[7:0]==sym_send_data)) |-> ##[`CYCLES_PER_BIT*9: 3*`CYCLES_PER_BIT*11] rx_data_valid && (rx_data == sym_send_data) ;
endproperty
assert_receive_eq_send_symbolic: assert property(receive_eq_send_symbolic);

property receive_eq_send; 
    bit [7:0] send_data;
    @(posedge clk) disable iff (~rst_n)
    (tx_wb_wr_fifo ,      send_data = wb_dat_i[7:0])  |-> ##[`CYCLES_PER_BIT*9: 3*`CYCLES_PER_BIT*11] rx_data_valid && (rx_data == send_data) ;
endproperty
assert_receive_eq_send_local_var: assert property(receive_eq_send);

endmodule


