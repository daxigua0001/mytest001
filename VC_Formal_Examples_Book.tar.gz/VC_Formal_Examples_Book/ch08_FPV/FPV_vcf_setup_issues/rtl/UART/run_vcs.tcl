config timebase 1ns
scope top 
run 1ns
call \$fsdbDumpfile(\"top.fsdb\");
call \$fsdbDumpvars(0,top);
call \$fsdbDumpMDA;
call \$fsdbDumpSVA;
# Run to completion
run
quit
