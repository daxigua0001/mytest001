clear -all

#elaborate -disable_auto_bbox -top $design
analyze -sv12 -f uart.f +define+CYCLES_PER_BIT=8

# Elaborate design and properties
elaborate -top uart 

stopat -env {csr_div}
assume -name asm_csr_div {csr_div==8} 
stopat -env {csr_ctrl[0]}
assume -name asm_csr_ctrl {csr_ctrl[0]==1 } 

# Set up Clocks and Resets
clock clk
reset ~rst_n

# Get design information to check general complexity
get_design_info

#liang added 
#cover -name test {addr0 == 8 ##10 addr0 == 3}
#cover -name instr {u_core.instr != 0}
#cover -name state_FETCH {u_core.state == 5'b00001}
#cover -name state_WAIT {u_core.state == 5'b00010}
#cover -name state_EXE {u_core.state == 5'b00100}
#cover -name state_WAIT_MEM {u_core.state == 5'b01000}
#cover -name state_DO_TRAP {u_core.state == 5'b10000}
# Prove properties
prove -all

# Report proof results
report
