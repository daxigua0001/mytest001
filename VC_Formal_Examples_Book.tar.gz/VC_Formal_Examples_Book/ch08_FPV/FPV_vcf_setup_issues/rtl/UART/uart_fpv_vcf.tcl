set_fml_appmode FPV

set design uart 

# Compilation Step 
read_file -top $design -format sverilog -sva -vcs {-f uart.f +define+CYCLES_PER_BIT=8}

# Clock Definitions 
create_clock clk -period 100

# Reset Definitions 
create_reset rst_n -sense low 

snip_driver  {uart.csr_div}
set_constant -value 8 csr_div[31:0]

snip_driver csr_ctrl[0]
set_constant -value 1 csr_ctrl[0]

# Initialisation Commands 
sim_run -stable
sim_save_reset

## Proof
check_fv -block
