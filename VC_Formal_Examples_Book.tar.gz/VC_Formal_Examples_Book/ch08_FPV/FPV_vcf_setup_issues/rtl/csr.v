module csr #(
    parameter ADDR_WIDTH = 10
)(
    input clk,
    input rst_n,

    input  [ADDR_WIDTH-1:0] wb_addr,
    input  [31:0] wb_wdata,
    input  [3:0]  wb_sel,
    input         wb_we,
    input         wb_stb,
    input         wb_cyc,
    output[31:0]  wb_rdata,
    output reg    wb_ack,
    output        wb_err,


    output   reg     cfg_uart0_en,
    output   reg     cfg_uart1_en,
    output   reg  [1:0]   cfg_test_sig_sel
);

reg [31:0]   rdata;

	always @(posedge clk or negedge rst_n)  begin
      if(!rst_n) begin
        wb_ack <= 1'b0;
      end
      else begin
		wb_ack <= (wb_stb)&&(wb_cyc);
      end    
    end


    wire read_en  = wb_stb && wb_cyc && ~wb_we ;
    wire write_en = wb_we && wb_cyc && wb_stb;

    
    // Control and State registers for this timer
    

	always @(posedge clk or negedge rst_n)  begin
      if(!rst_n) begin
        cfg_uart0_en <= 1'b0;
        cfg_uart1_en <= 1'b0;
      end
      else if(write_en && (wb_addr == 'h0)) begin
        cfg_uart0_en <= wb_wdata[0];
        cfg_uart1_en <= wb_wdata[1];
      end
   end   


	always @(posedge clk or negedge rst_n)  begin
      if(!rst_n) begin
        cfg_test_sig_sel<= 2'b0;
      end
      else if(write_en && (wb_addr == 'h4)) begin
        cfg_test_sig_sel<= wb_wdata[1:0];
      end
   end   


	always @(posedge clk or negedge rst_n)  begin
      if(!rst_n) begin
        rdata<= 32'b0;
      end
      else if(read_en ) 
        case(wb_addr)
        10'h0:
          rdata<= {30'b0,cfg_uart1_en,cfg_uart0_en};
        10'h4:
          rdata<= {30'b0,cfg_test_sig_sel};
        default: rdata<= 32'b0;
        endcase
    end  


// Bus connections
assign wb_err = 1'b0;
assign wb_rdata = rdata;

endmodule
