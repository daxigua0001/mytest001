
module  arb
(
input              clk,
input              rst_n,
input  wire [1:0]  req,
output  reg [1:0]  gnt
);

localparam  IDLE = 3'b001;
localparam  M0   = 3'b010;
localparam  M1   = 3'b100;

reg [2:0]  state_cs;
reg [2:0]  state_ns;
reg [1:0]  gnt_before;

always @(posedge clk or negedge rst_n) begin
  if(!rst_n) begin
    state_cs <= IDLE;
  end
  else begin
    state_cs <= state_ns;
  end
end


always @(*)  begin
  case(state_cs)  
  IDLE: 
      if(req[0] && !req[1]) begin
        state_ns = M0;
      end
      else if(req[1] && !req[0]) begin
        state_ns = M1;
      end
      else if(req[0] && req[1]) begin
        if(gnt_before == 2'b01) 
          state_ns = M0;          //bug insert
          //state_ns = M1;
        else
          state_ns = M0;
      end
      else begin
        state_ns = IDLE;
      end
  M0: 
      if(req[0] == 1'b0) begin
        state_ns = IDLE;
      end
      else begin
        state_ns = M0;
      end
  M1: 
      if(req[1] == 1'b0) begin
        state_ns = IDLE;
      end
      else begin
        state_ns = M1;
      end
  default :
      state_ns = IDLE;
  endcase
end


always @(*)  begin
  case(state_cs)
  IDLE:
      gnt[1:0] = 2'b00;
  M0:
      gnt[1:0] = 2'b01;
  M1:
      gnt[1:0] = 2'b10;
  default:
      gnt[1:0] = 2'b00;
  endcase
end


always @(posedge clk or negedge rst_n)  begin
  if(~rst_n) begin
    gnt_before <= 2'b00;
  end
  else begin
    if(state_cs == M0)
      gnt_before = 2'b01;
    else if (state_cs == M1)
      gnt_before = 2'b10;
  end
end

//============Assertion================

parameter   NUM = 2;

property   gnt_prop1(req);     
  @(posedge clk) disable iff (~rst_n)
     ((req != {NUM{1'b0}}) && (state_cs==IDLE)) |=>  (gnt != {NUM{1'b0}})  ;
endproperty
assert_gnt_prop1 : assert property (gnt_prop1(req) );



//fail assertion
property   gnt_prop22(req);     
  @(posedge clk) disable iff (~rst_n)
     ((req != {NUM{1'b0}}) && (state_cs!=IDLE)) |=>  (gnt == $past(gnt))  ;
endproperty
assert_gnt_prop22 : assert property (gnt_prop22(req) );


//fail assertion
property   gnt_prop12(req);     
  @(posedge clk) disable iff (~rst_n)
     (req != {NUM{1'b0}}) |=> ##[0:1] (gnt != {NUM{1'b0}})  ;
endproperty
assert_gnt_prop12 : assert property (gnt_prop12(req) );


property   gnt_prop2(req);     
  @(posedge clk) disable iff (~rst_n)
     (req == {NUM{1'b0}}) |=>  (gnt == {NUM{1'b0}})  ;
endproperty
assert_gnt_prop2 : assert property (gnt_prop2(req) );


property   gnt_value;     
  @(posedge clk) disable iff (~rst_n)
     $countones(gnt) <= 1  ;
endproperty
assert_gnt_value : assert property (gnt_value );


cov_req_all:  cover property ( @(posedge clk) req == {NUM{1'b1}} );

//aux code
reg [1:0]   gnt_last_save;
always @(posedge clk or negedge rst_n)  begin
  if(~rst_n) begin
    gnt_last_save <= 2'b00;
  end
  else if(gnt[0]) 
    gnt_last_save <= 2'b01;
  else if(gnt[1]) 
    gnt_last_save <= 2'b10;
end

property   gnt_round_robin;     
  @(posedge clk) disable iff (~rst_n)
          ((req == {NUM{1'b1}}) && (state_cs==IDLE)) |=>  (gnt != gnt_last_save)  ;
endproperty
assert_gnt_round_robin: assert property (gnt_round_robin );


endmodule



