`define CSR_RELOAD_VALUE_ADDR 0 
`define CSR_CURRENT_VALUE_ADDR 1
`define CSR_TIMER_CTRL_ADDR 2
`define CSR_INTERRUPT_ADDR 3
module timer_assume
#(
    parameter ADDR_WIDTH = 10  //4KB by default
)
(
    input  reg                      clk,
    input  reg                      rst_n,
    input  reg [ADDR_WIDTH-1:0] wb_addr_i,
    input  reg               [31:0] wb_dat_i,
    input  reg                      wb_we_i,
    input  reg               [3:0]  wb_sel_i,
    input  reg                      wb_stb_i,
   input [31:0] csr_regs[4]
   
    
);

//disable programming reload value when enable counting
    wire write_en=|wb_sel_i && wb_stb_i && wb_we_i;
assume_counter_never_wr_reload_when_enable_timer: assume property ( @(posedge clk) disable iff (~rst_n)
         csr_regs[`CSR_TIMER_CTRL_ADDR][0] |->  !(write_en && (wb_addr_i[3:0]=={`CSR_RELOAD_VALUE_ADDR,2'b00}))
);
endmodule
bind timer timer_assume u_timer_assume(.*);


