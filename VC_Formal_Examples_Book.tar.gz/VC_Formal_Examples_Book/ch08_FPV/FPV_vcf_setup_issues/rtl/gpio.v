/*
GPIO CSR registers:
GPIO Data Direction Register: GPIO_OE_EN (RW),reset=0x0. A set bit indicates that that GPIO should be an output. 
GPIO Data Out Register:       GPIO_OUT_REG (RW) The data output register .  pin.  
GPIO Data In Register:        GPIO_IN_REG (RO) The data input register of length N 
 */
`define CSR_GPIO_OUT_REG_ADDR 0
`define CSR_GPIO_IN_REG_ADDR 4
`define CSR_GPIO_DIRECT_OUT_ADDR 'h8
module gpio #
(
    parameter NUM_GPIO = 8, // number of GPIO pins 

    parameter ADDR_WIDTH = 8
)
(
    input  wire                         clk,
    input  wire                         rst_n,

    //Host interface
    input		    wb_cyc_i,
    input		    wb_stb_i, 
    input           wb_we_i,
    input	[ADDR_WIDTH-1:0]	wb_addr_i,
    input	[31:0]	wb_dat_i,
    input	[3:0]	wb_sel_i,
    output	wire	wb_stall_o,
    output	reg		wb_ack_o,
    output	reg	[31:0] wb_dat_o,    

    input  wire [NUM_GPIO-1:0]          gpio_i,
    output wire [NUM_GPIO-1:0]          gpio_o,
    output wire [NUM_GPIO-1:0]          gpio_oe //GPIO pin ouput enable
);
reg [NUM_GPIO-1:0] csr_gpio_out_reg;
reg [NUM_GPIO-1:0] csr_gpio_in_reg;
reg [NUM_GPIO-1:0] csr_gpio_direct_out;
reg [31:0] csr_gpio_mux_out;

//as input pad is asynchronize to this gpio block, use 2-FlipFlop to register
reg [NUM_GPIO-1:0] gpio_i_q1;
reg [NUM_GPIO-1:0] gpio_i_q2;
always @(posedge clk or negedge rst_n)
    if(~rst_n) begin
        gpio_i_q1<={NUM_GPIO{1'b0}};
        gpio_i_q2<={NUM_GPIO{1'b0}};
    end else begin
        gpio_i_q1<= gpio_i;
        gpio_i_q2<=gpio_i_q1;
    end

assign gpio_o = csr_gpio_out_reg;
assign gpio_oe= csr_gpio_direct_out;




//Following part is for CSR registers' logic

// Read enables
wire csr_data_re = (wb_addr_i[7:4]=='h8) ? (!wb_we_i & wb_stb_i & wb_cyc_i & wb_sel_i[0]) : 1'b0;
// output data bus
always@*
case(wb_addr_i)
        `CSR_GPIO_OUT_REG_ADDR: csr_gpio_mux_out = csr_gpio_out_reg;
        `CSR_GPIO_IN_REG_ADDR:  csr_gpio_mux_out = gpio_i_q2;
        `CSR_GPIO_DIRECT_OUT_ADDR:   csr_gpio_mux_out = csr_gpio_direct_out;
        default: csr_gpio_mux_out = csr_gpio_out_reg;
endcase
always @(posedge clk or negedge rst_n)
   if(~rst_n)
     wb_dat_o<=32'h0000_0000; 
    else if(csr_data_re)  begin
     wb_dat_o<={24'h000000,csr_gpio_mux_out}; 
    end

wire csr_gpio_out_reg_we=(wb_addr_i==`CSR_GPIO_OUT_REG_ADDR) ? {wb_we_i & wb_stb_i} & wb_cyc_i & wb_sel_i[0] : 1'b0;
always @(posedge clk or negedge rst_n)
   if(~rst_n)
     csr_gpio_out_reg<='h00; 
    else   begin
     if(csr_gpio_out_reg_we)
         csr_gpio_out_reg[7:0]<=wb_dat_i[7:0];
    end

wire csr_gpio_direct_out_we=(wb_addr_i==`CSR_GPIO_DIRECT_OUT_ADDR) ? {wb_we_i & wb_stb_i} & wb_cyc_i & wb_sel_i[0] : 1'b0;
always @(posedge clk or negedge rst_n)
   if(~rst_n)
     csr_gpio_direct_out<='hFF; //default set output 
    else   begin
     if(csr_gpio_direct_out_we)
         csr_gpio_direct_out[7:0]<=wb_dat_i[7:0];
    end






endmodule



