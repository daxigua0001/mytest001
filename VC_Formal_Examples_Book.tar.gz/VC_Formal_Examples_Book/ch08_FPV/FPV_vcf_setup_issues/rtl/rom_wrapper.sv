module rom_wrapper #(
    parameter [31:0] BaseAddr = 32'h0
)(
    input clk,
    input rst_n,

//    wb_bus.slave bus_slave
    input  [31:0] wb_addr,
    input  [31:0] wb_wdata,
    input  [3:0]  wb_sel,
    input         wb_we,
    input         wb_stb,
    input         wb_cyc,
    output[31:0]  wb_rdata,
    output        wb_ack,
    output        wb_err
);

reg  [31:0] rdata;
reg  ack;
wire err;


function [31:0] endian_swap_word(input [31:0] word);
    endian_swap_word = {
        word[ 7: 0],
        word[15: 8],
        word[23:16],
        word[31:24]
    };
endfunction


//memory array 
reg [31:0] memory [0:2047];

initial 
begin
  $readmemh("flash.txt", memory);
end


wire [10:0] word_addr = wb_addr[12:2];    // Word-based address

always_ff @(posedge clk) begin
    if (~rst_n) begin
        rdata <= 32'h0;
    end
    else if (wb_stb) begin
        rdata <= endian_swap_word(memory[word_addr]);
    end
end

assign err = wb_we;     //ROM dont support write operation

always_ff @(posedge(clk)) begin
    if (~rst_n) begin
        ack <= 1'h0;
    end
    else begin
        ack <= wb_stb & ~err;
    end
end



assign wb_ack = ack & wb_stb & ~err;
assign wb_rdata = rdata;
assign wb_err = err;

endmodule
