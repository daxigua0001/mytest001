module pad_io   (
output  i,
input o,
input oe,

inout  pad
);

assign  pad = oe ? o : 1'bz;
assign  i = pad;

endmodule
