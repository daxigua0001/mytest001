
module wb_rom_wrapper #(
    parameter [31:0] BaseAddr = 32'h0
)(
    input logic clk_in,
    input logic reset_in,

    //wb slave interface
    input [31:0] wb_addr,
    input     [31:0] wb_wdata,
    input     [3:0] wb_sel,
    input     wb_cyc,
    input     wb_we,
    input     wb_stb,
    output     wb_ack,
    output      wb_err,
    output     [31:0] wb_rdata

);

function [31:0] endian_swap_word(input [31:0] word);
    endian_swap_word = {
        word[ 7: 0],
        word[15: 8],
        word[23:16],
        word[31:24]
    };
endfunction

// Error logic. Dont support writes or unaligned reads
wire wb_err = (wb_we || wb_addr[1:0] != 2'h0);

// rom
reg [31:0] memory [0:3071];   //TODO, depth

//TODO
`ifdef VERILATOR
initial $readmemh("flash.txt", memory);
`else
initial $readmemh("./../../memory/flash.txt", memory);
`endif

// Reading

wire [31:0] absolute_addr = (wb_addr - BaseAddr);
wire [11:0] word_addr = absolute_addr[13:2];    // Word-based address

always @(posedge clk_in or negedge reset_in) begin
    if (~reset_in) begin
        wb_rdata <= 32'h0;
    end
    else if (wb_stb) begin
        wb_rdata <= endian_swap_word(memory[word_addr]);
    end
end

// Ack
reg ack;

always_ff @(posedge(clk_in)) begin
    if (~reset_in) begin
        ack <= 1'h0;
    end
    else begin
        ack <= wb_stb & ~wb_err;
    end
end

assign wb_ack = ack & wb_stb & ~wb_err;

endmodule
