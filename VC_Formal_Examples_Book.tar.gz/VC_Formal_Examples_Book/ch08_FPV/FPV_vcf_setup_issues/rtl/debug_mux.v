module debug_mux #(parameter WIDTH=8)
    (
input clk,
input rst_n,
input [2:0] debug_sel,
input [WIDTH-1:0] debug_sig0,
input [WIDTH-1:0] debug_sig1,
input [WIDTH-1:0] debug_sig2,
input [WIDTH-1:0] debug_sig3,
input [WIDTH-1:0] debug_sig4,
input [WIDTH-1:0] debug_sig5,
input [WIDTH-1:0] debug_sig6,
input [WIDTH-1:0] debug_sig7,
output reg [WIDTH-1:0] debug_out
);
    reg  [WIDTH-1:0] debug_out_sig;
    always@* begin
        case(debug_sel)
            3'b001:  debug_out_sig = debug_sig1;
            3'b010:  debug_out_sig = debug_sig2;            
            3'b011:  debug_out_sig = debug_sig3;
            3'b100:  debug_out_sig = debug_sig4;    
            3'b101:  debug_out_sig = debug_sig5;
            3'b110:  debug_out_sig = debug_sig6;  
            3'b111:  debug_out_sig = debug_sig7;              
            default:  debug_out_sig = debug_sig0;   
        endcase
    end
    always @(posedge clk or negedge rst_n)
        if(~rst_n)
            debug_out <= {WIDTH{1'b0}};
        else
            debug_out <= debug_out_sig;

endmodule

