<?xml version="1.0" encoding="UTF-8"?>
<wavelist version="3">
  <insertion-point-position>68</insertion-point-position>
  <wave>
    <expr>clk</expr>
    <label/>
    <radix/>
  </wave>
  <wave>
    <expr>&lt;embedded&gt;::soc.assert_SW3</expr>
    <label/>
    <radix/>
  </wave>
  <wave>
    <expr>rst_n</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_core.imm_S</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_core.instr[24:12]</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_core.instr[6:0]</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_core.regs[0]</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_core.regs[10]</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_core.regs[11]</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_core.regs[12]</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_sram_wrapper.memory.read_data_0[3]</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_core.regs[13]</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_core.regs[14]</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_core.regs[15]</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_core.regs[16]</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_core.regs[17]</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_core.regs[18]</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_core.regs[19]</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_core.regs[1]</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_core.regs[20]</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_core.regs[21]</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_core.regs[22]</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_core.regs[23]</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_core.regs[24]</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_core.regs[25]</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_core.regs[26]</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_core.regs[27]</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_core.regs[28]</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_core.regs[29]</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_core.regs[2]</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_core.regs[30]</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_core.regs[31]</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_core.regs[3]</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_core.regs[4]</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_core.regs[5]</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_core.regs[6]</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_core.regs[7]</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_core.regs[8]</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_core.regs[9]</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_core.state</expr>
    <label/>
    <radix>u_core.state</radix>
  </wave>
  <wave collapsed="true">
    <expr>u_sram_wrapper.memory.read_data_0[3]</expr>
    <label/>
    <radix/>
  </wave>
  <wave>
    <expr>u_sram_wrapper.memory.read_data_0[3][31]</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_core.wb_addr</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_core.wb_wdata</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_core.wb_sel</expr>
    <label/>
    <radix/>
  </wave>
  <wave>
    <expr>u_core.wb_we</expr>
    <label/>
    <radix/>
  </wave>
  <wave>
    <expr>u_core.wb_stb</expr>
    <label/>
    <radix/>
  </wave>
  <wave>
    <expr>u_core.wb_cyc</expr>
    <label/>
    <radix/>
  </wave>
  <wave>
    <expr>u_wb_interconnect.wb_we_s1</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_sram_wrapper.wb_addr</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_sram_wrapper.wb_wdata</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_sram_wrapper.wb_sel</expr>
    <label/>
    <radix/>
  </wave>
  <wave>
    <expr>u_sram_wrapper.wb_we</expr>
    <label/>
    <radix/>
  </wave>
  <wave>
    <expr>u_sram_wrapper.wb_stb</expr>
    <label/>
    <radix/>
  </wave>
  <wave>
    <expr>u_sram_wrapper.wb_cyc</expr>
    <label/>
    <radix/>
  </wave>
  <wave>
    <expr>u_sram_wrapper.memory</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_sram_wrapper.state</expr>
    <label/>
    <radix>u_sram_wrapper.state</radix>
  </wave>
  <wave>
    <expr>u_sram_wrapper.wb_we</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_sram_wrapper.wb_wdata_buf</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_sram_wrapper.word_addr</expr>
    <label/>
    <radix/>
  </wave>
  <wave>
    <expr>u_sram_wrapper.memory</expr>
    <label/>
    <radix/>
  </wave>
  <wave>
    <expr>u_sram_wrapper.memory</expr>
    <label/>
    <radix/>
  </wave>
  <wave>
    <expr>u_sram_wrapper.memory</expr>
    <label/>
    <radix/>
  </wave>
  <wave>
    <expr>u_sram_wrapper.memory</expr>
    <label/>
    <radix/>
  </wave>
  <wave>
    <expr>u_sram_wrapper.memory</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_sram_wrapper.memory.read_data_0[3]</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_core.instr[6:0]</expr>
    <label/>
    <radix/>
  </wave>
  <wave collapsed="true">
    <expr>u_core.state</expr>
    <label/>
    <radix>u_core.state</radix>
  </wave>
</wavelist>
