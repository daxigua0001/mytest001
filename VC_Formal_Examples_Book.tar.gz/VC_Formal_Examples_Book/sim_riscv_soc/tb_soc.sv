`timescale 1ns/1ps
module tb_soc;

reg  clk, rst_n;
reg  test_mode_pin;

parameter PERIOD = 10;

reg pin_reg1,pin_reg3,out_en;
initial begin
    rst_n= 1'b0;
    clk = 1'b0;
    test_mode_pin= 1'b0;
    pin_reg1=1; pin_reg3=1;out_en=0;
    #5 clk = 1'b1;
    #5 rst_n= 1'b1;
    
#600 out_en=0; pin_reg1= 1'b0; pin_reg3= 1'b0;
#60 out_en=0; pin_reg1= 1'b1; pin_reg3= 1'b1;


    #100000;
    $finish;
end

always #PERIOD clk=~clk;


assign pin1 = out_en ? 'hz:pin_reg1;
assign pin3 = out_en ? 'hz:pin_reg3;

soc u_soc(
    .clk(clk),
    .rst_n(rst_n),

    .PAD_IO_0(pin0),
    .PAD_IO_1(pin1),
    .PAD_IO_2(pin2),
    .PAD_IO_3(pin3),
    .PAD_IO_4(pin4),
    .PAD_IO_5(pin5),
    .PAD_IO_6(pin6),
    .PAD_IO_7(pin7),
    .test_mode_pin(test_mode_pin)    

);


initial begin
      $fsdbDumpfile("tb.fsdb");
      $fsdbDumpvars;
      $fsdbDumpMDA;
      $fsdbDumpSVA;
end


endmodule
