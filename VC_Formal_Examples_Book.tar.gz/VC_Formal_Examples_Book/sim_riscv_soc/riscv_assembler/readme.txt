python script riscv_assembler_my.py is used to generate binary or hex code for RISCV-SoC simulation rom code from its main argument asmfile.
This script comes from github whose address is: https://github.com/wueric/riscv_assembler/tree/master/assembler.
I just make some minor adjustment base on the need.

usage: python riscv_assembler_my.py [-h] [-d] [-i] [-m] [-dump] asmfile
Convert RISC-V assembly to binary vectors

for example:

 python riscv_assembler_my.py  fibonacci.txt

 above command with generate hex code for RISCV-SoC test in ../sim_riscv_soc/tests/fibonacci

