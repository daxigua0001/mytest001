vcs -full64 -sv=2012 += -debug_acc+pp+fsdb -R +fsdb+sva_success  -timescale=1ns/1ps tb_soc.sv -f riscv.f -cm line+cond+fsm+tgl+branch -cm_name fibonacci +test_idx=0 +define+CC_BUG_FIX +define+FPV_BUG_FIX+define+FXP_BUG_FIX
vcs -full64 -sv=2012 += -debug_acc+pp+fsdb -R +fsdb+sva_success  -timescale=1ns/1ps tb_soc.sv -f riscv.f -cm line+cond+fsm+tgl+branch -cm_name all_instr +test_idx=1 +define+CC_BUG_FIX +define+FPV_BUG_FIX+define+FXP_BUG_FIX
vcs -full64 -sv=2012 -debug_acc+pp+fsdb -R +fsdb+sva_success -timescale=1ns/1ps tb_soc.sv -f riscv.f -cm line+cond+fsm+tgl+branch -cm_name csr +test_idx=10 +define+CC_BUG_FIX +define+FPV_BUG_FIX+define+FXP_BUG_FIX

vcs -full64 -sv=2012 += -debug_acc+pp+fsdb -R +fsdb+sva_success -timescale=1ns/1ps tb_soc.sv -f riscv.f -cm line+cond+fsm+tgl+branch -cm_name gpio +test_idx=11 +define+CC_BUG_FIX +define+FPV_BUG_FIX+define+FXP_BUG_FIX

vcs -full64 -sv=2012 += -debug_acc+pp+fsdb -R +fsdb+sva_success -timescale=1ns/1ps tb_soc.sv -f riscv.f -cm line+cond+fsm+tgl+branch -cm_name uart  +test_idx=12 +define+CC_BUG_FIX +define+FPV_BUG_FIX+define+FXP_BUG_FIX

vcs -full64 -sv=2012 += -debug_acc+pp+fsdb -R +fsdb+sva_success -timescale=1ns/1ps tb_soc.sv -f riscv.f -cm line+cond+fsm+tgl+branch -cm_name uart_en +test_idx=13 +define+CC_BUG_FIX +define+FPV_BUG_FIX+define+FXP_BUG_FIX

vcs -full64 -sv=2012 += -debug_acc+pp+fsdb -R +fsdb+sva_success -timescale=1ns/1ps tb_soc.sv -f riscv.f -cm line+cond+fsm+tgl+branch -cm_name timer +test_idx=14 +define+CC_BUG_FIX +define+FPV_BUG_FIX+define+FXP_BUG_FIX

vcs -full64 -sv=2012 += -debug_acc+pp+fsdb -R +fsdb+sva_success -timescale=1ns/1ps tb_soc.sv -f riscv.f -cm line+cond+fsm+tgl+branch -cm_name all_instr +test_idx=15 +define+CC_BUG_FIX +define+FPV_BUG_FIX+define+FXP_BUG_FIX




