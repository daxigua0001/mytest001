
set str1 "Hello Formal"
set str2 "Hello"
puts "\[string compare str1 str2\] result is: "
puts [string compare str1 str2]
puts "length of \"$str1\" is:"
puts [string length $str1]
puts "First occurrence of str2 in str1 is:"
puts [string first $str2 $str1]
puts "To uppercase for \"$str2\":"
puts [string toupper $str2]
if { [string match -nocase ${str2}* $str1] } {
  puts "match success!"
} else {
  puts "match fail!"
} 

puts [format "%f" 22.12]
puts [format "%5d %s" 6 chapters]
puts [format "%20s" "Tcl Language"]
puts [format "%15x" 40]

regexp {([A-Z,a-z]*)} "Tcl Tutorial" full_str sub_str
puts  $full_str
