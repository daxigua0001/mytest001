set list1 { I can do }
set list2 [list formal verification!]
set list_new [concat $list1 $list2]
puts "concat list1 list2 is:"
puts $list_new
puts [concat "length of list_new is " [llength $list_new]]
set list_new [linsert $list_new 2 surely]
puts "after linsert , list_new is:" 
puts $list_new
puts [join $list_new _ ]
