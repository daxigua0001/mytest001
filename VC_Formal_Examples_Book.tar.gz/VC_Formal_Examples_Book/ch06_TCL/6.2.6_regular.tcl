#compare -line options
regexp {Hello.*} "Hello \nFormal!" fullMatchvar
puts [concat "without -line match:" $fullMatchvar]
regexp -line {Hello.*} "Hello \nFormal!" fullMatchvar
puts [concat "with -line match:" $fullMatchvar]

#compare -all options
set str "0543 0x3987 31 0x1F 39"
#compare -line options
regexp {Hello.*} "Hello \nFormal!" fullMatchvar
puts [concat "without -line match:" $fullMatchvar]
regexp -line {Hello.*} "Hello \nFormal!" fullMatchvar
puts [concat "with -line match:" $fullMatchvar]

#compare -all options
set str "0543 0x3987 31 0x1F 39"
regexp   {0x[0-9a-fA-F]+} $str fullMatchvar
puts [concat "without -all match:" $fullMatchvar]
regexp -all  {0x[0-9a-fA-F]+} $str fullMatchvar
puts [concat "with -all match:" $fullMatchvar]

#regsub gets match sucess times and replaced string
set matches [ regsub -all  {0x[0-9a-fA-F]+} $str 888 varName ]
puts [concat "sucess match times:" $matches]
puts [concat "got replaced string:" $varName]
regexp   {0x[0-9a-fA-F]+} $str fullMatchvar
puts [concat "without -all match:" $fullMatchvar]
regexp -all  {0x[0-9a-fA-F]+} $str fullMatchvar
puts [concat "with -all match:" $fullMatchvar]

#regsub gets match sucess times and replaced string
set matches [ regsub -all  {0x[0-9a-fA-F]+} $str 888 varName ]
puts [concat "sucess match times:" $matches]
puts [concat "got replaced string:" $varName]
