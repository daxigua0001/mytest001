set a 1
set b 2
puts [concat "gloabal variable a=" $::a]
namespace eval math_NS {
  variable a 10
  variable b 20
  variable result
  proc add { a {b 200 } } {  
    set ::math_NS::result [expr $a+$b]
  }
  proc accum {numbers} {
    set sum 0
    foreach number $numbers {
      set sum  [expr $sum + $number]
	  }
    return $sum
  }
}
puts "Second argument uses default value 200,add result is: " 
puts [math_NS::add $a ]
puts "with global a b ,add result is: "
puts [math_NS::add $a $b]
puts "with namespace math_NS variable ,add result is: "
puts [math_NS::add $math_NS::a $math_NS::b] 
#proc's argument can be variable for accum
puts [concat "accum {1 2 3} is:" [math_NS::accum {1 2 3}]]
puts [concat "accum {1 2 3 4} is:" [math_NS::accum {1 2 3 4}]]
