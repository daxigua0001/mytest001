set a 50
if { $a <= 20 } {
        puts "a <=20"
} elseif { $a <= 30 } {
        puts "a <= 30"
} else {
        puts "a is $a"
}
puts [expr $a == 50 ? 1 : 0]
set result C
switch $result {
A {puts "A: very good";}
B {puts "B: good"}
C {puts "C: not good" }
default {puts "not a result"}}
set a 2
while { $a < 20 } {
   incr a
   if {$a ==5} { continue 
   } elseif {$a==8} {break}
   puts "value of a: $a"
}
for { set i 0} { $i<5 } {incr i} {puts "$i "}
set lista {1 2 3}
foreach var $lista { puts $var }
