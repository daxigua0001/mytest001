set fp [open "input.txt" w+]
puts $fp "1.pig\n2.dog"
close $fp
set fp [open "input.txt" r+] ;#can't w+
seek $fp 0 end  ;#must seek to end
puts $fp "3.hen\n"
close $fp
set fp [open "input.txt" r]
puts {use way1 read to read file}
set data [read -nonewline $fp] ;#way1 read
   puts $data
seek $fp 0  ;#seek to begin 
puts {use way2 gets to read file}
while { [gets $fp data] >= 0 } { ;#way2 gets
   puts $data
}
close $fp 

