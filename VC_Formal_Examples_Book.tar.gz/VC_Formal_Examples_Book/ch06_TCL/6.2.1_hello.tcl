puts "argc=$argc argv=$argv argv0=$argv0"  ;#number of arguments,list and script name
set your_name [lindex $argv 0]
puts "Hello $your_name!" ;# my first print in Tcl 
