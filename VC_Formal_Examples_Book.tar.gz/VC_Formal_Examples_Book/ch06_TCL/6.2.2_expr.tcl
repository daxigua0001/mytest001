set a [ expr 1+2*3 ]
set b [ expr ~(07 ^ 0x7 |0xF) ]
set out_string [expr $a>$b ? Yes:No]
puts "$a > $b ? $out_string"
