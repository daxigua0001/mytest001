set ic_languages(0) Tcl
set ic_languages(2) SystemVerilog
set ic_languages(4) Perl
puts $ic_languages(2)
puts [array size ic_languages]
