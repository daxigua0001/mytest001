/*
     fpv_vip_send_free_crd: SVA credit checker
     - Check that number of active send over an interface never exceeds the number of credit available
     - Input: 
        - Clock and reset
        - credit_consumes (send) 
        - credit_returns (free) 
      - Parameter:
        - max_credits: the credit available for the interface
        - ctrl_width : the width of the SVA counter that keep track of the credit
        - assume_src : implement the assertion for send as an assume property
        - assume_dst : implement the assertion for free as an assume property
*/

module fpv_vip_send_free_crd
#(
	max_credits  =8,
        ctrl_width   =$clog2(max_credits),
	assume_src   =0,
	assume_dst   =0,
        enable_cover = 0
)
(  
	input logic n_clock,
	input logic n_resetb,
	input logic credit_consumes,
	input logic credit_returns
);

logic [ctrl_width :0] credits = max_credits;

always @(posedge n_clock) begin
	if (n_resetb == 1'b1) begin
		credits <= (credit_consumes && !credit_returns) ? credits - 'b1 :
                           (!credit_consumes && credit_returns) ? credits + 'b1 :
			    credits;
        end
	else begin
		credits<=max_credits;
	end
end

generate 
	if (assume_src) begin : src_assume
		`SVA_ASSUME(src_no_send_wo_credit, credit_consumes |-> |credits);
        end
        else begin : src_assert
		`SVA_ASSERT(src_no_send_wo_credit, credit_consumes |-> |credits);
        end
	if (assume_dst) begin : dst_assume
		`SVA_ASSUME(dst_no_free_if_all_cr, credit_returns |-> credits < max_credits );
        end
        else begin : dst_assert
		`SVA_ASSERT(dst_no_free_if_all_cr, credit_returns |-> credits < max_credits );
        end
endgenerate

if (enable_cover) begin
   // Cover if credit_consumes (send) is received
   `SVA_COVER(credit_consume_send,(credit_consumes));
   
   // Cover if credit_returns (free) occurs at this interface
   `SVA_COVER(credit_return_free,(credit_returns));
   
   // Cover all credits used
   `SVA_COVER(all_credits_are_used_up,(credits=='b0));
   
   // Cover all credits returned
   `SVA_COVER(all_credits_return,((credits < max_credits) ##1 (credits == max_credits)));
   
   // Cover half credits used
   `SVA_COVER(half_credits_used_up,(credits == (max_credits >> 1)));
end


endmodule
