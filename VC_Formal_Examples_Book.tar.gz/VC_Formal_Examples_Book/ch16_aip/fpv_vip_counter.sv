
/*

fpv_vip_fifo: SVA counter check
     - Check overflow and underflow of a counter
     - Input: 
        - Clock and reset
        - dec: counter decrease value. if decreased by 1, the dec condition 
        - inc: counter increase value. if increased by 1, the inc condition
      - Parameter:
        - WIDTH: bit width of the counter
        - MAX_VAL : the max value of the counter. default: 2**WIDTH - 1
        - AST_TYPE: assert(0) or assume(1) (formal only)
        - enable_cover: include cover properties for corner cases (default 0. not include covers)
*/
//`include "sva_assert.svh"
module fpv_vip_counter #(
        parameter WIDTH     = 3,
        parameter MAX_VAL       = 2**WIDTH - 1,
        parameter AST_TYPE      = 0, //0: assert 1: assume 
        parameter enable_cover  = 0
) (
   // Clock to match formal text macro
   input n_clock,
   // Reset to match formal text macro
   input n_resetb,
   input[WIDTH-1:0] dec,
   input[WIDTH-1:0] inc
);

logic [WIDTH-1:0] cnt;
always @(posedge n_clock) begin
if (~n_resetb) 
       cnt <= '0;
else 
       cnt <= cnt + inc - dec;
end

if (AST_TYPE == 0) begin
  `SVA_ASSERT(cnt_underflow, cnt == '0 |-> dec == '0);
  `SVA_ASSERT(cnt_overflow,  cnt + inc -  dec <=  MAX_VAL);
  `SVA_ASSERT(cnt_max_dec,   dec <=  cnt);

end

if (AST_TYPE == 1) begin
  `SVA_ASSUME(cnt_underflow, cnt == '0 |-> dec == '0);
  `SVA_ASSUME(cnt_overflow,  cnt + inc -  dec <=  MAX_VAL);
  `SVA_ASSUME(cnt_max_dec,   dec <=  cnt);
end

if (enable_cover) begin
  `SVA_COVER(cnt_max_val,  cnt == MAX_VAL);
  `SVA_COVER(cnt_max2zero, cnt == MAX_VAL ##1 (cnt == '0) [->1] );
end

endmodule 

