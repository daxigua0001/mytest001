/*
fpv_vip_vld_rdy: SVA valid-ready interface checker
     - Check the protocol
     - Input: 
        - Clock and reset
        - vld
        - rdy
      - Parameter:
        - WIDTH : the width of data
        - AIP_MASTER   : used by formal only.   0: producer, 1: consumer  
        - enable_cover: 1: enable a few cover properties for corner cases. 0: no cover properties. 
*/
`include "sva_assert.svh"

module aip_valid_ready2 #(
  parameter DATA_WIDTH        = 4,
  parameter AIP_MASTER     = 0,  //0: produceer, 1: consumer 
  parameter enable_cover = 0   //0: no cover properties.  
) 
(
  input clk,
  input rst_n,
  input vld,
  input rdy,
  input [DATA_WIDTH-1:0]  data
);

 if (AIP_MASTER == 0) begin : prod
    // producer. 
   `SVA_ASSERT(VLD_RDY_vld, (vld && ~rdy) |-> ##1 vld);
   `SVA_ASSERT(VLD_RDY_data, (vld && ~rdy) |-> ##1 $stable(data)); 
   // if rdy is also an internal signal, you should convert this assume into assert
   `ifdef FORMAL
      // formal only assertion: every valid request has a rdy response
      `SVA_ASSUME(VLD_RDY_every_vld_has_rdy, ($rose(vld) || $past(vld && rdy) && vld) |-> strong(##[0:$] rdy));
   `endif
 end 
 if (AIP_MASTER == 1) begin : cons
    // consumer 
   `SVA_ASSUME(VLD_RDY_vld, vld && ~rdy |-> ##1 vld);
   `SVA_ASSUME(VLD_RDY_data, vld && ~rdy |-> ##1 $stable(data)); 
   `ifdef FORMAL
      // formal only assertion: every valid request has a rdy response
      `SVA_ASSERT(VLD_RDY_every_vld_has_rdy, ($rose(vld) || $past(vld && rdy) && vld) |-> strong(##[0:$] rdy));
   `endif
 end 

 if (enable_cover) begin : cov 
   `SVA_COVER(VLD_RDY_vld, vld && ~rdy ##1 vld);
   `SVA_COVER(VLD_RDY_data, vld && ~rdy  ##1 $stable(data)); 
   `SVA_COVER(VLD_RDY_stall_to_complete, vld  && !rdy ##1 (vld && rdy)[->1]);
 end 

endmodule
