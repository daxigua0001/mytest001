///////////////////////////////////////////////////////////////////////
// SVA Text Macros to simplify assertion writting
///////////////////////////////////////////////////////////////////////
`ifndef __SVA_ASSERT_SVH__
`define __SVA_ASSERT_SVH__


`define AST_ERR_MSG(msg) \
    $error("%s: %t:  %s", "ASSERT_ERROR", $time, msg)


///////////////////////////////////////////////////////////////////////
// Keep the text macro as simple as possible
// If you need to add anything, please talk to Shaun Feng first
///////////////////////////////////////////////////////////////////////

`ifndef ASSERT_OFF
 `define SVA_ASSERT(name, test_expr, clk=clk, rst_n=rst_n, msg="assertion failed") \
     AST_``name: assert property ( @(posedge clk) disable iff ((rst_n) !== 1'b1) \
		  test_expr \
		  ) \
       else `AST_ERR_MSG(msg)
`else
 `define SVA_ASSERT(name, test_expr, clk=clk, rst_n=rst_n, msg="assertion failed")
`endif // ASSERT_OFF 

`ifndef ASSERT_OFF
 `define SVA_ASSERT_IMM(name, test_expr, msg="assertion failed") \
     AST_IMM_``name: assert property ( \
		  test_expr \
		  ) \
       else `AST_ERR_MSG(msg)
`else
 `define SVA_ASSERT_IMM(name, test_expr, msg="assertion failed")
`endif // ASSERT_OFF 

`ifndef ASSERT_OFF
 `define SVA_ASSUME(name, test_expr, clk=clk, rst_n=rst_n, msg="assertion failed") \
     ASM_``name: assume property ( @(posedge clk) disable iff ((rst_n) !== 1'b1) \
		  test_expr \
                  ) \
       else `AST_ERR_MSG(msg)
`else
 `define SVA_ASSUME(name, test_expr, clk=clk, rst_n=rst_n, msg="assertion failed")
`endif // ASSERT_OFF 

`ifndef ASSERT_OFF
 `define SVA_COVER(name, test_expr, clk=clk, rst_n=rst_n, msg="assertion failed") \
     COV_``name: cover property ( @(posedge clk) disable iff ((rst_n) !== 1'b1) \
                  test_expr \
                  )
`else
 `define SVA_COVER(name, test_expr, clk=clk, rst_n=rst_n, msg="assertion failed") 
`endif // ASSERT_OFF 


`endif // __SVA_ASSERT_SVH__

///////////////////////////////////////////////////////////////////////


