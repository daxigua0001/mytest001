
module aip_valid_ready 
#(
parameter DATA_WIDTH=1,
parameter AIP_MASTER=0,
parameter disable_hold_vld_till_rdy= 0,
parameter disable_hold_data_till_rdy= 0,
parameter disable_eventually_rdy_seen= 0,
parameter disable_eventually_vld_seen= 0
)(
input clk,
input rst_n,
input vld,
input rdy,
input [DATA_WIDTH-1:0] data
);

 if (AIP_MASTER == 0) begin
    if(!disable_hold_vld_till_rdy) begin
    hold_vld_till_rdy: assert property (@(posedge clk) disable iff (~rst_n)
     vld |=> $past(rdy) || vld
    );
    end
    hold_data_till_rdy: assert property (@(posedge clk) disable iff (~rst_n)
     vld |=> $past(rdy) || $stable(data)
    );
end else begin
    ast_hold_vld_till_rdy: assume property (@(posedge clk) disable iff (~rst_n)
     vld |=> $past(rdy) || vld
    );
    ast_hold_data_till_rdy: assume property (@(posedge clk) disable iff (~rst_n)
     vld |=> $past(rdy) || $stable(data)
    );
end
    

endmodule
