set_fml_appmode FPV

set design top

read_file -top $design -format sverilog -sva -vcs { top.sv aip_valid_ready.sv aip_valid_ready2.sv  }

# Clock Definitions 
create_clock top.clk -period 100

# Reset Definitions 
create_reset top.rst_n -sense low

set_change_at -clock clk -posedge -default

sim_run -stable
sim_force top.vld -apply 0
sim_force top.rdy -apply 0
sim_save_reset

fvcover err -expr { $past(vld & ~rdy) & ($stable(data)) }

check_fv -block 
