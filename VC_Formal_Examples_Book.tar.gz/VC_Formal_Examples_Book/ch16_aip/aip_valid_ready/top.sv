module top();

bit clk,rst_n;
bit vld,rdy;
bit [7:0] data;

aip_valid_ready #(.DATA_WIDTH(8),
.AIP_MASTER(0)
      ) aip_valid_ready(
    .*
    );

 aip_valid_ready2 #(.DATA_WIDTH(8),
.AIP_MASTER(1)
      ) aip_valid_ready2(
    .*
    );

endmodule

