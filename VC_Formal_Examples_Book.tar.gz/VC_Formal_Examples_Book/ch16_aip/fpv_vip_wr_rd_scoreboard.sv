// ****************************************************
// The simplest write and read once memory model constraints.
// ****************************************************
`include "sva_assert.svh"

module fpv_vip_wr_rd_scoreboard #(
	parameter	WORDS		= 128,
        parameter       AST_TYPE        = 0 //0: assert 1: assume 
)(
	input				n_clock, 
	input				n_resetb, 

	input	        		wren, 
	input				rden, 		
	input [$clog2(WORDS)-1:0]       wraddr,				 
	input [$clog2(WORDS)-1:0]       rdaddr				 

);


localparam	LOG2WORDS	= $clog2(WORDS);

logic [WORDS-1:0]	valid;

always_ff @(posedge n_clock)
  if (~n_resetb)
	valid       	<= '0;
  else if (wren && ~rden)
	valid[wraddr]	<= 1'b1;
  else if (rden && ~wren)
        valid[rdaddr]   <= 1'b0;
  else if (rden && wren && wraddr != rdaddr) begin
        valid[rdaddr]   <= 1'b0;
	valid[wraddr]	<= 1'b1;
  end
        

if (AST_TYPE == 0) begin
  `SVA_ASSERT(WR_RD_no_conflict, wren && rden |-> rdaddr != wraddr);
  `SVA_ASSERT(WR_RD_no_RD_b4_WR, rden |-> valid[rdaddr] == 1'b1);
  `SVA_ASSERT(WR_RD_no_WR_overwrite, wren |-> valid[wraddr] == 1'b0);
end 

if (AST_TYPE == 1) begin
  `SVA_ASSUME(WR_RD_no_conflict, wren && rden |-> rdaddr != wraddr);
  `SVA_ASSUME(WR_RD_no_RD_b4_WR, rden |-> valid[rdaddr] == 1'b1);
  `SVA_ASSUME(WR_RD_no_WR_overwrite, wren |-> valid[wraddr] == 1'b0);
end 

endmodule
