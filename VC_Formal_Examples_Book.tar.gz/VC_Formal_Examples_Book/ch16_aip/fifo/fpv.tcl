set_fml_appmode FPV

set design fifo 

read_file -top $design -format sverilog -sva -vcs {top.sv aip_fifo.sv fifo.v  }

# Clock Definitions 
create_clock clk -period 100

# Reset Definitions 
create_reset rst_n -sense low

set_change_at -clock clk -posedge -default

sim_run -stable
#sim_force top.rdy -apply 0
sim_save_reset

#fvcover err -expr { $past(vld & ~rdy) & ($stable(data)) }

check_fv -block 
