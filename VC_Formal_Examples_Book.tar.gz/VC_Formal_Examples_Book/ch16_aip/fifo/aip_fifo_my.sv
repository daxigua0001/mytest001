module aip_fifo
#(
        parameter       WIDTH           = 16,
        parameter       DEPTH           = 4,
        parameter       AIP_MODE        = 0, //0: assert 1: assume 
        parameter       enable_cover    = 0
)
(
        input               clk,
        input               rst_n,

        input [WIDTH-1:0]   wr_data,
        input               wr_en,           // doesn't block write when full. driver to check full before wr_en
        input               rd_en,
        input               empty,
        input               full,
        input [WIDTH-1:0]   rd_data
);

localparam      ADDR_WID   = $clog2(DEPTH);

 
// FIFO behavior model
logic [ADDR_WID:0]          fifo_cnt;
logic [ADDR_WID:0]          wr_ptr, rd_ptr;
logic [DEPTH-1:0][WIDTH-1:0]  ram;
logic [WIDTH-1:0]             model_rd_data;
logic full, full_nxt, empty;

always_ff @(posedge clk)
if (~rst_n)
         fifo_cnt    <= 0;
else begin
   if (wr_en && !rd_en ) begin
         fifo_cnt    <= fifo_cnt + 1;
   end
   if (!wr_en && rd_en ) begin
         fifo_cnt    <= fifo_cnt - 1;
   end
end
/*
always_ff @(posedge clk)
if (~rst_n) begin
        wr_ptr    <= 0;
        rd_ptr    <= 0;
   end
else begin
   if (wr_en) begin
         ram[wr_ptr] <= wr_data;
         wr_ptr      <= (wr_ptr == DEPTH-1)? 0: wr_ptr + 1;
   end
   if (rd_en) begin
         rd_ptr      <= (rd_ptr == DEPTH-1)? 0: rd_ptr + 1;
   end
end
assign model_rd_data=ram[rd_ptr];
 */

assert_full: assert property(@(posedge clk) full==(fifo_cnt == DEPTH));
assert_empty: assert property(@(posedge clk) empty==(fifo_cnt == 0));
//assign full_nxt=(fifo_cnt == (DEPTH-1));
//assign empty=(fifo_cnt == 0);


   assume_no_rd_ovf: assume property(@(posedge clk) empty |-> !rd_en);
   assume_no_wr_ovf: assume property(@(posedge clk) full |->  !(wr_en));

   assume_eve_rd: assume property(@(posedge clk) !empty |-> s_eventually(rd_en));


//assertion about fifo : in_order/no_crupption/no_duplication/no_miss_data   

bit [WIDTH-1:0] sym_data1,sym_data2;
   assume_stable_wdata1: assume property(@(posedge clk)  ##1 $stable(sym_data1));
   assume_stable_wdata2: assume property(@(posedge clk)  ##1 $stable(sym_data2));

bit  seen_wdata1,seen_wdata2, seen_rdata1, seen_rdata2;

bit  rd_en_r;
always_ff @(posedge clk)
if (~rst_n) 
   rd_en_r<= 0;
else 
   rd_en_r<= rd_en;

always_ff @(posedge clk)
if (~rst_n) begin
        seen_wdata1<= 0;
        seen_wdata2<= 0;
        seen_rdata1<= 0;
        seen_rdata2<= 0;
   end
else begin
        seen_wdata1<= seen_wdata1 | (wr_en&&(wr_data==sym_data1));
        seen_wdata2<= seen_wdata2 | (wr_en&&(wr_data==sym_data2));
        seen_rdata1<= seen_rdata1 | (rd_en_r&&(rd_data==sym_data1));
        seen_rdata2<= seen_rdata2 | (rd_en_r&&(rd_data==sym_data2));
end


   assert_if_wdata1_first_rdata1_first: assert property(@(posedge clk)  
                   seen_wdata1&~seen_wdata2  |-> s_eventually (seen_rdata1&~seen_rdata2) );

   assert_wdata1_final_rdata1: assert property(@(posedge clk) seen_wdata1 |-> s_eventually (seen_rdata1));



if (enable_cover) begin
   cover_full_rd: cover property(@(posedge clk)  full ##1 rd_en);
   cover_full2empty: cover property(@(posedge clk)  full ##1 empty[->1]);
end

endmodule
