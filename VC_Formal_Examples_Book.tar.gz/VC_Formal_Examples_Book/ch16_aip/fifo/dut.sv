module dut(input clk,
	input rst_n
);
reg [7:0] data;
reg  fifo_rd;
reg  fifo_wr;

wire fifo_full,fifo_empty;

	always@(posedge clk or negedge rst_n)
	if(!rst_n) begin
		fifo_wr <= 0;
	end else if( ~fifo_full) begin
		fifo_wr <= 1'b1;
    end

	always@(posedge clk or negedge rst_n)
	if(!rst_n) begin
		fifo_rd <= 0;
	end else if( ~fifo_empty&~fifo_wr) begin
		fifo_rd <= 1'b1;
    end    

    fifo #(.WIDTH(8)) fifo(
	.clk(clk),
	.rst_n(rst_n),
	.fifo_wr(fifo_wr),
	.fifo_rd(fifo_rd),
	.fifo_wr_data(fifo_wr_data),
	.fifo_full(fifo_full),
	.fifo_rd_data(fifo_rd_data),
	.fifo_empty(fifo_empty)                    
    );

endmodule
bind dut.fifo aip_fifo u_aip_fifo(
.clk(clk),
.rst_n(rst_n),
.wr_en(fifo_wr),
.wr_data(fifo_wr_data),
.rd_en(fifo_rd),
.rd_data(fifo_rd_data),
.empty(fifo_empty),
.full(fifo_full)                
 );


