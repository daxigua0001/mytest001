module aip_fifo 
#(
parameter BYPASS=0,
parameter DEPTH=4,
parameter WIDTH=1,
parameter dis_random_stable_level = 0,
parameter dis_fifo_data_integrity_check = 0,
parameter dis_fifo_overflow_check = 0,
parameter dis_fifo_underflow_check = 0
)(
input clk,
input rst_n,
input wr_en,
input [WIDTH-1:0]wr_data,
input rd_en,
input [WIDTH-1:0] rd_data,
input empty,
input full
);

logic [$clog2(DEPTH):0] level, count;
logic [$clog2(DEPTH):0] level_sym;
logic flag;
logic [WIDTH-1:0] data;

always_ff @(posedge clk or negedge rst_n) begin
 level <= ~rst_n ? '0 : (level + wr_en - rd_en);
 flag <= ~rst_n ? '0 : (wr_en & ~flag & (level==level_sym) & (BYPASS ? (level_sym!='0) : 1'b1)) ? 'd1 : (rd_en & flag & (count == '0)) ? 'd0 : flag;
 data <= ~rst_n ? '0 : (wr_en & ~flag & (level==level_sym) & (BYPASS ? (level_sym!='0) : 1'b1)) ? wr_data : data; 
 count <= ~rst_n ? '0 : (wr_en & ~flag & (level==level_sym) & (BYPASS ? (level_sym!='0) : 1'b1)) ? level_sym-rd_en : !count ? '0 : count-rd_en;
end

generate

if(!dis_random_stable_level) begin
random_stable_level: assume property (@(posedge clk) 
  $stable(level_sym) 
);

random_stable_level_valid_range: assume property (@(posedge clk) 
  (level_sym >= '0) && (level_sym < DEPTH)
);
end

if(!dis_fifo_data_integrity_check) begin
if(BYPASS) begin
fifo_data_integrity_bypass_check: assert property (@(posedge clk) disable iff (~rst_n)
 rd_en & (level == 'd0) |-> (wr_data==rd_data)
);
end

fifo_data_integrity_check: assert property (@(posedge clk) disable iff (~rst_n)
 flag & rd_en & (count == 'd0) |-> ##1 (data==rd_data)
);
end

if(!dis_fifo_overflow_check) begin
fifo_overflow_check: assume property (@(posedge clk) disable iff (~rst_n)
  wr_en |-> (level < DEPTH) | ((level == DEPTH) & BYPASS & rd_en)
);
end

if(!dis_fifo_underflow_check) begin
fifo_underflow_check: assume property (@(posedge clk) disable iff (~rst_n)
  rd_en |-> (level > '0) | ((level == '0) & BYPASS & wr_en)
);
end

endgenerate

endmodule
