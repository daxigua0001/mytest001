
/*
fpv_vip_fifo: SVA FIFO checker
     - Check corner cases of a FIFO
     - Input: 
        - Clock and reset
        - push: fifo push
        - pop: fifo pop
        - din: data input
      - Parameter:
        - WIDTH: input data width
        - DEPTH : FIFO depth
        - AST_TYPE: assert or assume (formal only)
        - enable_cover: enable cover properties for corner cases (default:0)

*/

//`include "sva_assert.svh"
module fpv_vip_fifo
#(
        parameter       WIDTH           = 16,
        parameter       DEPTH           = 7,
        parameter       AST_TYPE        = 0, //0: assert 1: assume 2:cover // not used for now.
        parameter       enable_cover    = 0
)
(
        input               n_clock,
        input               n_resetb,

        input [WIDTH-1:0]   din,
        input               push,           // doesn't block write when full. driver to check full before push
        input               pop
);

localparam      A_WID   = $clog2(DEPTH);


logic [A_WID:0]               fifo_cnt;
logic [A_WID:0]               wr_ptr, rd_ptr;
logic [DEPTH-1:0][WIDTH-1:0]  ram;
logic [WIDTH-1:0]             dout;
logic full, full_nxt, empty;

always_ff @(posedge n_clock)
if (~n_resetb)
         fifo_cnt    <= 0;
else begin
   if (push && !pop ) begin
         fifo_cnt    <= fifo_cnt + 1;
   end
   if (!push && pop ) begin
         fifo_cnt    <= fifo_cnt - 1;
   end
end

always_ff @(posedge n_clock)
if (~n_resetb) begin
        wr_ptr    <= 0;
        rd_ptr    <= 0;
   end
else begin
   if (push) begin
         ram[wr_ptr] <= din;
         wr_ptr      <= (wr_ptr == DEPTH-1)? 0: wr_ptr + 1;
   end
   if (pop) begin
         rd_ptr      <= (rd_ptr == DEPTH-1)? 0: rd_ptr + 1;
   end
end
assign dout=ram[rd_ptr];
 
assign full=(fifo_cnt == DEPTH);
assign full_nxt=(fifo_cnt == (DEPTH-1));
assign empty=(fifo_cnt == 0);


`SVA_ASSERT(FIFO_FULL_NO_PUSH, (full |-> !push || pop));
`SVA_ASSERT(FIFO_EMPTY_NO_POP, (empty |-> !pop));

if (enable_cover) begin
  `SVA_COVER (FIFO_FULL_POP, full ##1 pop);
  `SVA_COVER (FIFO_FULL2EMPTY, full ##1 empty[->1]);
end

endmodule
