module dut_vld_rdy_master
#(
parameter DATA_WIDTH=2                                 //Width of data
)(
input clk,
input rst_n,
output reg valid,
input      ready,
output reg [DATA_WIDTH-1:0] data
);

reg [4:0] cnt;
always@(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        valid <= 1'b0;
        data <= {DATA_WIDTH{1'b0}};
    end
    else if(cnt==5'd20) begin
        valid <= 1'b1;
        data  <= 0;
    end
    //bug
    else if(cnt==5'd21) begin
        valid <= 1'b0;
        data  <= 1;
    end
    
    else if(ready)begin
        valid <= 1'b0;
    end
end    

always@(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
      cnt <= 0;
    end
    else begin
      cnt <= cnt + 1'b1; 
    end
end

endmodule
