set_fml_appmode FPV

set design dut_vld_rdy_slave 

signoff_config -type all

# Compilation Step 
read_file -top $design -format sverilog -sva -vcs {dut_vld_rdy_slave.sv aip_vld_rdy.sv tb.sv +define+AIP_COVER_ON}

# Clock Definitions 
create_clock clk -period 100

# Reset Definitions 
create_reset rst_n -sense low 

# Initialisation Commands 
sim_run -stable

sim_save_reset
## Proof
check_fv -block 

## Reports
report_fv -list > results.txt
