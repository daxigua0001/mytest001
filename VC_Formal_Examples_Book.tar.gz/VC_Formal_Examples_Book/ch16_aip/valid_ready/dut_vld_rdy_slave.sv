module dut_vld_rdy_slave 
#(
parameter DATA_WIDTH=2                                 //Width of data
)(
input clk,
input rst_n,
input valid,
output reg ready,
input [DATA_WIDTH-1:0] data
);


reg [DATA_WIDTH-1:0] data_r;
reg  valid_r1;
reg  valid_r2;

always @(posedge clk or negedge rst_n)
    if(!rst_n) ready <= 1'b0;
    else if(valid_r2) ready <= 1'b1;
    else ready <= 1'b0;


always @(posedge clk or negedge rst_n)
    if(!rst_n) data_r <= 1'b0;
    else if(valid) data_r <= data;

always @(posedge clk or negedge rst_n)
    if(!rst_n) begin
      valid_r1 <= 1'b0; 
      valid_r2 <= 1'b0;
    end
    else begin
      valid_r1 <= valid; 
      valid_r2 <= valid_r1;    
    end

endmodule



