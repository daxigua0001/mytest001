bind  dut_vld_rdy_slave  aip_vld_rdy   
#(.DATA_WIDTH (2),
.MAX_DELAY(2),
.AIP_MASTER(1)
 )
u_aip_vld_rdy
(
.clk(clk),
.rst_n(rst_n),
.valid(valid),
.ready(ready),
.data(data)

);

/*
bind  dut_vld_rdy_master  aip_vld_rdy   
#(.DATA_WIDTH (2),
.MAX_DELAY(3),
.AIP_MASTER(0)
 )
u_aip_vld_rdy
(
.clk(clk),
.rst_n(rst_n),
.valid(valid),
.ready(ready),
.data(data)

);
*/

