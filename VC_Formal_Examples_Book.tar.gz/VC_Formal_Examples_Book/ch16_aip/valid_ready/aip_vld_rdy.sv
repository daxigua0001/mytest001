module aip_vld_rdy 
#(
parameter DATA_WIDTH=1,                                 //Width of data
parameter MAX_DELAY=0,        //ready must be seen within MAX_DELAY after valid; must be 0 for infinite;
parameter AIP_MASTER=1,                          //1 = valid is the output, 0=ready is the output of this AIP
parameter EVENTUALLY_READY= 1,             //=1 Disable the property
parameter AIP_COVER  
)(
input clk,
input rst_n,
input valid,
input ready,
input [DATA_WIDTH-1:0] data
);


generate
if(AIP_MASTER) begin
  //Valid should be held if no ready
  assume_aip_valid_keep: assume property (@(posedge clk) disable iff (!rst_n)
   valid |-> ##1 $past(ready) | valid
  );

  
  //data should be held if no ready
  assume_aip_data_keep: assume property (@(posedge clk) disable iff (!rst_n)
   valid |-> ##1 $past(ready) | $stable(data)
  );
  
  
  //If there is a vaid, ready must be seen within MAX_DELAY cycles
  if(EVENTUALLY_READY && MAX_DELAY) begin
    assert_aip_max_delay_ready: assert property (@(posedge clk) disable iff (!rst_n)
     valid |-> (##[0:MAX_DELAY] ready)
    );
  end
end else begin   //aip is slave
  //Valid should be held if no ready
  assert_aip_valid_keep: assert property (@(posedge clk) disable iff (!rst_n)
   valid |-> ##1 $past(ready) | valid );
  
  //Valid data should be held if no ready
  assert_aip_data_keep: assert property (@(posedge clk) disable iff (!rst_n)
   valid |-> ##1 $past(ready) | $stable(data)
  );
  
  //If there is a vaid, ready must be seen within MAX_DELAY cycles
  if(EVENTUALLY_READY && MAX_DELAY) begin
    assert_aip_max_delay_ready: assert property (@(posedge clk) disable iff (!rst_n)
     valid |-> (##[0:MAX_DELAY] ready)
    );
  end
end
endgenerate


//cover properties

`ifdef AIP_COVER
cover_aip_valid_ready_: cover property (@(posedge clk) disable iff (!rst_n) valid & ready );
cover_aip_valid_no_ready: cover property (@(posedge clk) disable iff (!rst_n) valid & ~ready );
cover_aip_no_valid_ready: cover property (@(posedge clk) disable iff (!rst_n) ~valid & ready );
`endif


endmodule
