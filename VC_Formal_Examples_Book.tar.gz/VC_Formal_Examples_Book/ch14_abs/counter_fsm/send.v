module send(
input clk,
input rst_n,
input event_b,
input start_wait,
output send
                );
parameter IDLE=0;
parameter WAIT=1;
parameter RECEIVE_B=2;
parameter SEND=3;



always @(posedge clk or negedge rst_n)
if(~rst_n)
  state <= IDLE;
else
  state <= state_next;

always @(posedge clk or negedge rst_n)
if(~rst_n)
  counter <= 'h0000;
else
  counter <= counter_next;

always@*
begin
  case(state):
  IDLE: 
  if(start_wait) begin
    state_next = WAIT;
    tx_pre=1'b0;
    counter_next='b0;
  end else begin
    state_next = IDLE;
  end
  WAIT: 
  if(counter < 1000) begin
    state_next = WAIT;
    counter_next=counter+1;
  end else begin
    state_next = RECEIVE_B;
    counter_next==0;
  ned
  RECEIVE_B:
  if(counter==2048) begin
    send_state_next = SEND;
    counter_next='d0;
  end else begin
    send_state_next = RECEIVE_B;
    counter_next=counter+event_b;
  end

    assert_send_state_rst: assert property
      (@(posedge clk) disable iff (rst)
         $fell(rst) |-> (send_state == IDLE));

   assert_send_state: assert property
      (@(posedge clk) disable iff (rst)
         (send_state == WAIT ##1 send_state != WAIT) |-> (send_state == RECEIVE_B));



end





endmodule
