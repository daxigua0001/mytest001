module counter(input clk, rst_n,
               input [1:0] mode,
               output reg pulse);


reg [31:0] counter;
//local parameter integer PARAM_MAX[3:0] = {1000,2000,3000,4000};
parameter integer unsigned PARAM_MAX[0:3]  =  { 10000,20000,30000,40000 };

reg [31:0] max_cnt;
always@*
if(mode==2'b00)
max_cnt='d100000;
else if(mode==2'b01)
max_cnt = 'd200000;
else if(mode==2'b10)
max_cnt = 'd300000;
else 
max_cnt = 'd400000;


always @(posedge clk or negedge rst_n)
        if(~rst_n)
        counter <='h0;
        else if(counter==max_cnt)
        counter <= 0;
        else
        counter <= counter + 1;


always @(posedge clk or negedge rst_n)
        if(~rst_n)
        pulse <='h0;
        else if(counter==max_cnt)
        pulse <= 1'b1;
        else
        pulse <= 1'b0;        

assert_pulse:assert property (@(posedge clk) (mode==3 && counter == 'd400000) |=> pulse);
        
endmodule
