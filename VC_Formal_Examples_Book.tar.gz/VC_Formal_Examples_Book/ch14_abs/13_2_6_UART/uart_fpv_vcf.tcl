set_fml_appmode FPV

set design uart

# Compilation Step 
read_file -top $design -format sverilog -sva -vcs {-f uart.f +define+FPV_BUG_FIX +define+CYCLES_PER_BIT=8 -pvalue+uart.COUNT_WIDTH=4 -pvalue+uart.UART_FIFO_DEPTH=2}

snip_driver  {uart.csr_uart_div}
set_constant -value 8 csr_uart_div[31:0]

snip_driver csr_uart_ctrl[0]
set_constant -value 1 csr_uart_ctrl[0]

# Clock Definitions 
create_clock clk -period 100

# Reset Definitions 
create_reset rst_n -sense low 

# Initialisation Commands 
sim_run -stable
sim_save_reset

#add this to make signal toggle at posedge, never at negedge
set_change_at -clock clk -posedge -default

## Proof
check_fv -block
