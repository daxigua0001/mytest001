module uart_tx
#( parameter COUNT_WIDTH = 32)
(
input clk,
input rst_n,
input [31:0] baud_div_reg,
input tx_data_ready,
input [7:0] tx_data,
output reg tx,
output tx_is_idle,
output reg [3:0] state
);

localparam  [3:0]
            IDLE  = 4'b0000,
            START = 4'b0001,
            DATA0 = 4'b0010,
            DATA1 = 4'b0011,
            DATA2 = 4'b0100,
            DATA3 = 4'b0101,
            DATA4 = 4'b0110,
            DATA5 = 4'b0111,
            DATA6 = 4'b1000,
            DATA7 = 4'b1001,
            STOP  = 4'b1010;

	
wire  [COUNT_WIDTH:0] baud_div_reg_m1= baud_div_reg[COUNT_WIDTH:0] -1'b1;

reg [3:0] state_next;
always @(posedge clk or negedge rst_n)
if(~rst_n)
  state <= IDLE;
else
  state <= state_next;

reg tx_pre;
reg [7:0] tx_shift_data_pre,tx_shift_data;
reg [COUNT_WIDTH-1:0] counter,counter_pre;

always@*
case(state)
  IDLE: 
  if(tx_data_ready) begin
    state_next = START;
    //tx_pre=1'b0; note book: bug, initial value should be 1
    tx_pre=1'b1;
    counter_pre='b0;
  end else begin
    state_next = IDLE;
    tx_pre=1'b1;
    //tx_pre=1'b0; note book: bug, lack of this branch , latch introduced
  end
  START: 
  if(counter==baud_div_reg_m1) begin
    state_next = DATA0;
    tx_pre=tx_data[0];
    counter_pre='d0;
    tx_shift_data_pre=tx_shift_data;
  end else begin
    state_next = START;
    counter_pre=counter+1;
    tx_pre=1'b0;
  end
  DATA0: 
  if(counter==baud_div_reg_m1) begin
    state_next = DATA1;
    tx_shift_data_pre=tx_shift_data>>1;
    tx_pre=tx_shift_data_pre[0];
    counter_pre='d0;
  end else begin
    state_next = state;
    counter_pre=counter+1;
    tx_shift_data_pre=tx_shift_data;
    tx_pre=tx_shift_data_pre[0];
  end
  DATA1: 
  if(counter==baud_div_reg_m1) begin
    state_next = DATA2;
    tx_shift_data_pre=tx_shift_data>>1;
    tx_pre=tx_shift_data_pre[0];
    counter_pre='d0;
  end else begin
    state_next = state;
    counter_pre=counter+1;
    tx_shift_data_pre=tx_shift_data;
    tx_pre=tx_shift_data_pre[0];
  end
  DATA2: 
  if(counter==baud_div_reg_m1) begin
    state_next = DATA3;
    tx_shift_data_pre=tx_shift_data>>1;
    tx_pre=tx_shift_data_pre[0];
    counter_pre='d0;
  end else begin
    state_next = state;
    counter_pre=counter+1;
    tx_shift_data_pre=tx_shift_data;
    tx_pre=tx_shift_data_pre[0];
  end
  DATA3: 
  if(counter==baud_div_reg_m1) begin
    state_next = DATA4;
    tx_shift_data_pre=tx_shift_data>>1;
    tx_pre=tx_shift_data_pre[0];
    counter_pre='d0;
  end else begin
    state_next = state;
    counter_pre=counter+1;
    tx_shift_data_pre=tx_shift_data;
    tx_pre=tx_shift_data_pre[0];
  end
  DATA4: 
  if(counter==baud_div_reg_m1) begin
    state_next = DATA5;
    tx_shift_data_pre=tx_shift_data>>1;
    tx_pre=tx_shift_data_pre[0];
    counter_pre='d0;
  end else begin
    state_next = state;
    counter_pre=counter+1;
    tx_shift_data_pre=tx_shift_data;
    tx_pre=tx_shift_data_pre[0];
  end
  DATA5: 
  if(counter==baud_div_reg_m1) begin
    state_next = DATA6;
    tx_shift_data_pre=tx_shift_data>>1;
    tx_pre=tx_shift_data_pre[0];
    counter_pre='d0;
  end else begin
    state_next = state;
    counter_pre=counter+1;
    tx_shift_data_pre=tx_shift_data;
    tx_pre=tx_shift_data_pre[0];
  end
  DATA6: 
  if(counter==baud_div_reg_m1) begin
    state_next = DATA7;
    tx_shift_data_pre=tx_shift_data>>1;
    tx_pre=tx_shift_data_pre[0];
    counter_pre='d0;
  end else begin
    state_next = state;
    counter_pre=counter+1;
    tx_shift_data_pre=tx_shift_data;
    tx_pre=tx_shift_data_pre[0];
  end  
  DATA7: 
  if(counter==baud_div_reg_m1) begin
    state_next = STOP;
    tx_pre=1'b1;
    counter_pre='d0;
  end else begin
    state_next = DATA7;
    counter_pre=counter+1;
    tx_pre=tx_shift_data_pre[0];
  end
  STOP: begin
  tx_pre=1'b1;
  if(counter==baud_div_reg_m1) begin
    state_next = IDLE;
    counter_pre='d0;
  end else begin
    state_next = STOP;
    counter_pre=counter+1;
  end
  end
  default: begin
    tx_pre=1'b1;
    state_next = IDLE;
  end
  endcase

always @(posedge clk or negedge rst_n)
if(~rst_n)
  counter <= 'h0;
else
  counter <= counter_pre;  

always @(posedge clk or negedge rst_n)
if(~rst_n) begin
//  tx <= 'b0; note book , bug
  tx <= 1'b1;
end else begin
  tx <= tx_pre;
end
always @(posedge clk or negedge rst_n)
if(~rst_n) begin
  tx_shift_data<='h0;
end else if(state==START && counter==baud_div_reg_m1) begin
  tx_shift_data<=tx_data;
end else begin
  tx_shift_data<=tx_shift_data_pre;
end


assign tx_is_idle = (state == IDLE);

endmodule


