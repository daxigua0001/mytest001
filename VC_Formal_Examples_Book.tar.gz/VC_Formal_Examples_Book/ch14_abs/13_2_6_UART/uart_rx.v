// UART receiver module
// Uses 8 bits, one stop bit, one start bit, no parity bit
module uart_rx
#( parameter COUNT_WIDTH=32 )                
(
    input  clk,
    input  clk_cg,
    input  rst_n,
    input  rx,             // UART RX port 
    input [31:0] baud_div_reg, //How many clock cycles a single bit transfer takes

    output reg [7:0] rx_data,
    output rx_busy,
    output reg [3:0] state,
    output reg rx_data_valid
);

localparam  [3:0]
            IDLE  = 4'b0000,
            START = 4'b0001,
            DATA0 = 4'b0010,
            DATA1 = 4'b0011,
            DATA2 = 4'b0100,
            DATA3 = 4'b0101,
            DATA4 = 4'b0110,
            DATA5 = 4'b0111,
            DATA6 = 4'b1000,
            DATA7 = 4'b1001,
            STOP  = 4'b1010,
            SUCCESS  = 4'b1011 ;

reg [COUNT_WIDTH-1:0] counter;
wire [COUNT_WIDTH:0] cycles_per_bit_m1_tmp = baud_div_reg - 1'b1;
wire [COUNT_WIDTH-1:0] cycles_per_bit_m1 = cycles_per_bit_m1_tmp[COUNT_WIDTH-1:0];
reg rx_q;
always @(posedge clk or negedge rst_n) begin
    if (~rst_n) 
        rx_q <= 0;
    else
        rx_q <= rx;
end

reg rx_busy_q;
always @(posedge clk or negedge rst_n) begin
    if (~rst_n) 
        rx_busy_q <= 1'b0;
    else if(rx_q == 1'b1 && rx==1'b0 || rx==1'b0)
        rx_busy_q<= 1'b1;
    else if(state == IDLE)
        rx_busy_q<=1'b0;
end

assign rx_busy = rx_busy_q || ~rx; //negedge of rx detect must use full clk


always @(posedge clk_cg or negedge rst_n) begin
    if (~rst_n) begin
        state <= IDLE;
        rx_data <= 8'h0;
        rx_data_valid <= 1'b0;
        counter <= 0;
    end
    else begin
        case (state)  
            START: begin
                // Wait half the cycles of a single bit to check the start bit. Then count full number of cycles per bit to sample at the center
                if (counter < {1'b0,baud_div_reg[31:1]}) begin
                    counter <= counter + 1;
                end
                else begin
                    // Sample start bit again at center
                    if (rx == 1'b0) begin
                       state <= DATA0;
                       counter <= 0; 
                    end
                    else begin
                        // Start bit corrupted, back to IDLE 
                        state <= IDLE;
                    end
                end
            end
            DATA0: begin
                if (counter < cycles_per_bit_m1) begin
                    counter <= counter + 1;
                end
                else begin
                    counter <= 0;
                    state <= DATA1;
                    rx_data <= {rx,rx_data[7:1]};// Read current bit
                end
            end
            DATA1: begin
                if (counter < cycles_per_bit_m1) begin
                    counter <= counter + 1;
                end
                else begin
                    counter <= 0;
                    state <= DATA2;
                    rx_data <= {rx,rx_data[7:1]};// Read current bit
                end
            end            
            DATA2: begin
                if (counter < cycles_per_bit_m1) begin
                    counter <= counter + 1;
                end
                else begin
                    counter <= 0;
                    state <= DATA3;
                    rx_data <= {rx,rx_data[7:1]};// Read current bit
                end
            end
             DATA3: begin
                if (counter < cycles_per_bit_m1) begin
                    counter <= counter + 1;
                end
                else begin
                    counter <= 0;
                    state <= DATA4;
                    rx_data <= {rx,rx_data[7:1]};// Read current bit
                end
            end
            DATA4: begin
                if (counter < cycles_per_bit_m1) begin
                    counter <= counter + 1;
                end
                else begin
                    counter <= 0;
                    state <= DATA5;
                    rx_data <= {rx,rx_data[7:1]};// Read current bit
                end
            end
            DATA5: begin
                if (counter < cycles_per_bit_m1) begin
                    counter <= counter + 1;
                end
                else begin
                    counter <= 0;
                    state <= DATA6;
                    rx_data <= {rx,rx_data[7:1]};// Read the current bit
                end
            end
            DATA6: begin
                if (counter < cycles_per_bit_m1) begin
                    counter <= counter + 1;
                end
                else begin
                    counter <= 0;
                    state <= DATA7;
                    rx_data <= {rx,rx_data[7:1]};// Read the current bit
                end
            end
            DATA7: begin
                // Wait a full bit cycle to read the center of the next bit
                if (counter < cycles_per_bit_m1) begin
                    counter <= counter + 1;
                end
                else begin
                    counter <= 0;
                    rx_data <= {rx,rx_data[7:1]};
                    //rx_data <= {rx_data[6:0],rx}; note book, bug
                    state <= STOP;
                end
            end            
            STOP: begin
                // Wait until middle of stop bit
                if (counter < cycles_per_bit_m1) begin
                    counter <= counter + 1;
                end
                else begin
                    state <= SUCCESS;
                    rx_data_valid <= 1'b1;
                end
            end
            SUCCESS: begin
                rx_data_valid <= 1'b0; //rx_data_valid is one pulse signal 
                state <= IDLE;
            end
            /* IDLE */
            default: begin
                if (rx_q == 1'b1 && rx==1'b0) begin // sample the input rx, looking for a 1->0 transition for receive start
                    state <= START;
                    counter <= 0;
                    rx_data <= 8'h0;
                end
            end
        endcase
    end
end


endmodule
