//  Register Description
//  let base address = 0x00000000
// 
//  0x00000000 : 32-bit Clock Divider Register (BAUD_DIV)                 [ Read & Write ]
//      Clock Divider register sets the speed of uart tx & rx.
//      if your clk freq is Fc and target baud frequency is Fb then formula for correct value 
//      of it is:     value = (Fc / Fb) - 2;
//  0x00000000 : 8-bit data register (DATA)                            [ Read & Write ]
//      To transmit a byte      : Write to this register
//      To get recieved value   : Read from this register.
//          if no value is recieved or value is already read then reg will contain -1.
//   
//  0x00000004 : 8-bit status        (STATUS)                            [ Read Only ]
//      bit[0] = receive_buf_valid :   recieve buffer has a valid value
//      bit[1] = tx_busy        :   Transmitter is busy transmitting a byte  
// 
//  0x00000008 : 32-bit Clock Divider Register (BAUD_DIV)                 [ Read & Write ]
//      Clock Divider register sets the speed of uart tx & rx.
//      if your clk freq is Fc and target baud frequency is Fb then formula for correct value 
//      of it is:     value = (Fc / Fb) - 2;
//  0x0000000C : 8-bit UART work mode control (UART_CTRL)                 [ Read & Write ]
//      control register of uart work mode: loopback enable.
//      bit[0] = loopback_en:   configure UART loopback work mode, connect tx to rx




`define CSR_UART_DIV_ADDR 5'h00
`define CSR_UART_SEND_DATA_ADDR 5'h04
`define CSR_UART_RECE_DATA_ADDR 5'h08
`define CSR_UART_STATUS_ADDR 5'h0C
`define CSR_UART_CTRL_ADDR 5'h10

module uart #(
                parameter ADDR_WIDTH=10,
                parameter COUNT_WIDTH=32,
                parameter UART_FIFO_DEPTH = 2       
             )
(
input clk,
input rst_n,
input rx,
output tx,
//wishbone interface
input		    wb_cyc_i,
input		    wb_stb_i, 
input           wb_we_i,
input	[ADDR_WIDTH-1:0]	wb_addr_i,
input	[31:0]	wb_dat_i,
input	[3:0]	wb_sel_i,
output	wire	wb_err_o,
output	reg		wb_ack_o,
output	wire [31:0] wb_dat_o,
output  uart_tx_busy, //for UART clock gating feature,transmit block busy
output  uart_rx_busy, //for UART clock gating feature,receive block busy
output  wire [7:0] uart_debug
);


//UART CSR registers
reg [31:0] csr_uart_div;
reg [7:0]  csr_uart_status;
reg [7:0]  csr_uart_ctrl;

//UART clock gate logic
wire clk_cg_tx; //gated clock for transmit
wire clk_cg_rx; //gated clock for receive


wire csr_uart_tx_cg_free_run= 1'b1;
clock_gate clock_gate_uart_tx(
.clk(clk),
.enable_in(uart_tx_busy||csr_uart_tx_cg_free_run),
.gclk(clk_cg_tx) );


wire csr_uart_rx_cg_free_run = 1'b1;
clock_gate clock_gate_uart_rx(
.clk(clk),
.enable_in(uart_rx_busy||csr_uart_rx_cg_free_run),
.gclk(clk_cg_rx) );

wire tx_is_idle;
wire tx_fifo_full;
`ifndef FPV_BUG_FIX
wire tx_wb_wr_fifo = wb_we_i & (wb_addr_i==`CSR_UART_SEND_DATA_ADDR)& wb_cyc_i & wb_stb_i & (~tx_fifo_full);
`else
wire tx_wb_wr_fifo = wb_we_i & (wb_addr_i==`CSR_UART_SEND_DATA_ADDR)& wb_cyc_i & wb_stb_i & wb_ack_o & (~tx_fifo_full);
`endif
assign  wb_err_o =1'b0;  


always @(posedge clk or negedge rst_n)
  if(~rst_n)  begin
    wb_ack_o <= 1'b0; 
  end
`ifndef   FPV_BUG_FIX  

`else
  else if(wb_ack_o) begin
    wb_ack_o <= 1'b0;
  end
`endif  
  else if(wb_cyc_i & wb_stb_i ) begin
    if(wb_we_i) begin
      wb_ack_o <= 1'b1;
    end
    else begin    //read
     wb_ack_o <= 1'b1;
    end
  end
  else begin
    wb_ack_o <= 1'b0;
  end


wire [3:0] tx_state;
wire [3:0] rx_state;
assign uart_debug = {rx_state,tx_state};

wire [7:0] tx_fifo_rd_data;
reg tx_fifo_rd;
wire tx_fifo_empty;
always @(posedge clk or negedge rst_n)
        if(~rst_n)
        tx_fifo_rd<=1'b0;
        else if(tx_fifo_rd)
        tx_fifo_rd<=1'b0;        
        else if(~tx_fifo_empty & tx_is_idle)
        tx_fifo_rd<=1'b1;

fifo #(.DEPTH(UART_FIFO_DEPTH)) u_uart_tx_fifo
(
    .clk(clk),
	.rst_n(rst_n),
	.fifo_wr(tx_wb_wr_fifo),
	.fifo_rd(tx_fifo_rd),
	.fifo_wr_data(wb_dat_i),
	.fifo_full(tx_fifo_full),
	.fifo_rd_data(tx_fifo_rd_data),
	.fifo_empty(tx_fifo_empty));


wire [7:0] send_reg= tx_fifo_rd_data; 

uart_tx #(.COUNT_WIDTH(COUNT_WIDTH)) u_uart_tx 
(
.clk(clk_cg_tx),
.rst_n(rst_n),
.baud_div_reg(csr_uart_div),
.tx_data_ready(tx_fifo_rd),
.tx_data(send_reg),
.tx(tx),
.tx_is_idle(tx_is_idle),
.state(tx_state));

assign uart_tx_busy = tx_fifo_rd | ~tx_is_idle;

wire [7:0] rx_data;

uart_rx #(.COUNT_WIDTH(COUNT_WIDTH)) u_uart_rx 
(
.clk(clk),
.clk_cg(clk_cg_rx),
.rst_n(rst_n),
.baud_div_reg(csr_uart_div),
.rx_data_valid(rx_data_valid),
.rx_data(rx_data),
.rx_busy(uart_rx_busy),
.state(rx_state),
.rx(csr_uart_ctrl[0] ? tx : rx)); //implement loopback mode

wire rx_fifo_read = ~wb_we_i & (wb_addr_i==`CSR_UART_RECE_DATA_ADDR)& wb_cyc_i & wb_stb_i & ~wb_ack_o;
wire [7:0] rx_fifo_rd_data;


fifo #(.DEPTH(UART_FIFO_DEPTH)) u_uart_rx_fifo
(
    .clk(clk),
	.rst_n(rst_n),
	.fifo_wr(rx_data_valid&~rx_fifo_full),
	.fifo_rd(rx_fifo_read),
	.fifo_wr_data(rx_data),
	.fifo_full(rx_fifo_full),
	.fifo_rd_data(rx_fifo_rd_data),
	.fifo_empty(rx_fifo_empty));


//Following part is for UART CSR registers' logic

// Read enables
//wire csr_re = (!wb_we_i & wb_stb_i  & wb_sel_i[0]) ;
assign csr_uart_status={6'h0,rx_fifo_empty,tx_fifo_full};
// output data bus
reg [31:0] csr_uart_mux_out;
always@*
case(wb_addr_i[4:0])
        `CSR_UART_DIV_ADDR:       csr_uart_mux_out = csr_uart_div;
        `CSR_UART_RECE_DATA_ADDR: csr_uart_mux_out = rx_fifo_rd_data;
        `CSR_UART_STATUS_ADDR:    csr_uart_mux_out = csr_uart_status;
        `CSR_UART_CTRL_ADDR:      csr_uart_mux_out = csr_uart_ctrl;
        default            :      csr_uart_mux_out = 0;
endcase


//always @(posedge clk or negedge rst_n)
//   if(~rst_n)
//     wb_dat_o<=32'h0000_0000; 
//    else if(csr_re)  begin
//     wb_dat_o<=csr_uart_mux_out; 
//    end

assign  wb_dat_o = csr_uart_mux_out; 


wire [3:0] csr_uart_div_we=(wb_addr_i==`CSR_UART_DIV_ADDR) ? {4{wb_we_i & wb_stb_i}} & wb_sel_i : 4'b0000;
always @(posedge clk or negedge rst_n)
   if(~rst_n)
     csr_uart_div<=32'h0000_0008; 
    else   begin
     if(csr_uart_div_we[0])
         csr_uart_div[7:0]<=wb_dat_i[7:0];
     if(csr_uart_div_we[1])
         //csr_uart_div[15:8]<=wb_dat_i[7:0];
         csr_uart_div[15:8]<=wb_dat_i[15:8];
     if(csr_uart_div_we[2])
         csr_uart_div[23:16]<=wb_dat_i[23:16];
     if(csr_uart_div_we[3])
         csr_uart_div[31:24]<=wb_dat_i[31:24];
    end

wire [3:0] csr_uart_ctrl_we=(wb_addr_i==`CSR_UART_CTRL_ADDR) ? {4{wb_we_i & wb_stb_i}} & wb_sel_i : 4'b0000;

always @(posedge clk or negedge rst_n)
   if(~rst_n)
     csr_uart_ctrl[7:0]<=8'h00; //default set as normal work mode 
    else   begin
     if(csr_uart_ctrl_we[0])
         csr_uart_ctrl[7:0]<=wb_dat_i[7:0];
    end



//SV assertions

`define CYCLES_PER_BIT 8

//define a certain random send_data
wire [7:0] sym_send_data;
assume_stable_send_data:  assume property( @(posedge clk)
    $stable(sym_send_data));
property rece_eq_send_sym; 
    bit [7:0] send_data;
    @(posedge clk) disable iff (~rst_n)
    (tx_wb_wr_fifo && (wb_dat_i[7:0]==sym_send_data)) |-> ##[`CYCLES_PER_BIT*9: 3*`CYCLES_PER_BIT*11] rx_data_valid && (rx_data == sym_send_data) ;
endproperty
ast_rece_eq_send_sym: assert property(rece_eq_send_sym);

property rece_eq_send_localvar; 
    bit [7:0] sent_data;
    @(posedge clk) disable iff (~rst_n)
    (tx_wb_wr_fifo ,      sent_data = wb_dat_i[7:0])  |-> ##[`CYCLES_PER_BIT*9: 3*`CYCLES_PER_BIT*11] rx_data_valid && (rx_data == sent_data) ;
endproperty
ast_rece_eq_send_localvar: assert property(rece_eq_send_localvar);

reg [7:0] sent_data[0:3];
reg [1:0] rd_ptr,wr_ptr;
always@(posedge clk or negedge rst_n)
	if(!rst_n) begin
		rd_ptr<= 0;
	end else if( rx_data_valid ) begin
		rd_ptr<= rd_ptr+ 1'b1;
    end
always@(posedge clk or negedge rst_n)
	if(!rst_n) begin
		wr_ptr<= 0;
	end else if(tx_wb_wr_fifo) begin
		wr_ptr <= wr_ptr+ 1'b1;
        sent_data[wr_ptr] <= wb_dat_i[7:0];
    end
property rece_eq_send_helper; 
    @(posedge clk) disable iff (~rst_n)
    tx_wb_wr_fifo  |-> ##[`CYCLES_PER_BIT*9: 3*`CYCLES_PER_BIT*11] rx_data_valid && (rx_data == sent_data[rd_ptr]) ;
endproperty
ast_rece_eq_send_helper: assert property(rece_eq_send_helper);


endmodule


