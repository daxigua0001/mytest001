# ----------------------------------------
#  Copyright (c) 2017 Cadence Design Systems, Inc. All Rights
#  Reserved.  Unpublished -- rights reserved under the copyright 
#  laws of the United States.
# ----------------------------------------
clear -all

# Analyze design under verification files

analyze -sv12 \
  ./mem2p.v \
  ./top.sv 

  
# Elaborate design and properties
elaborate -top top -parameter DATA_WIDTH 32 -parameter ADDR_WIDTH 6

# Set up Clocks and Resets
clock clk
reset ~rstb
reset -non_resettable_regs 0
# Get design information to check general complexity
get_design_info 
#cover -name test {addr0 == 8 ##10 addr0 == 3}
#constraints
assume -name "never_rd_wr_same_addr" { ! (rd_en && wr_en && (rd_addr==wr_addr)) }
assume -name "no_read_write_during_reset" {~rstb |-> (wr_en==0 && rd_en==0)}


# Prove properties
prove -all

# Report proof results
report

