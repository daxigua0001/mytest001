set_fml_appmode FPV

set design top 

# Compilation Step 
read_file -top $design -format sverilog -sva -vcs {-pvalue+top.ADDR_WIDTH=2 -pvalue+top.DATA_WIDTH=8 mem2p.v top.sv}

# Clock Definitions 
create_clock clk -period 100

# Reset Definitions 
create_reset rstb -sense low 

fvassume never_rd_wr_same_addr -expr { ! (rd_en && wr_en && (rd_addr==wr_addr)) }
#fvassume no_read_write_during_reset -expr {~rstb |-> (wr_en==0 && rd_en==0)}

sim_run -stable
sim_set_state -uninitialized -apply 0
sim_save_reset

check_fv -block 

