
module top(
input clk,
input rstb,
input wr_en,
input [5:0] wr_addr,
input [31:0] wr_data,
input rd_en,
input [5:0] rd_addr,
output wire [31:0] rd_data
);



mem2p mem_32x32(
.QB(rd_data), 
.CLKA(clk), 
.CLKB(clk), 
.MEA(wr_en), 
.MEB(rd_en), 
.RSTA(rstb), 
.RSTB(rstb), 
.WEA(wr_en), 
.ADRA(wr_addr), 
.ADRB(rd_addr), 
.DA(wr_data)                
);

//property to verify memory
logic wr_en_q0,wr_en_q1,wr_en_q1_flag;
logic [5:0] wr_addr_q0, wr_addr_q1 ;
logic [31:0] wr_data_q0,wr_data_q1;

logic rd_en_q0,rd_en_q1;
logic [5:0] rd_addr_q0,rd_addr_q1;
always @( posedge clk) begin
wr_en_q0 <= wr_en;
wr_en_q1 <= wr_en_q0;
if(wr_en) begin
        wr_en_q0 <= 1'b1;
        wr_addr_q0 <= wr_addr;
        wr_data_q0 <= wr_data;
end
if(wr_en_q0) begin
        wr_en_q1_flag <= 1'b1;
        wr_addr_q1 <= wr_addr_q0;
        wr_data_q1 <= wr_data_q0;
end
end

always @ (posedge clk) begin
  rd_en_q0<=rd_en;
  rd_en_q1<=rd_en_q0;
  rd_addr_q0<=rd_addr;
  rd_addr_q1<=rd_addr_q0;  
end

property rd_should_match_write_for_same_addr;
@(posedge clk) disable iff (rstb == 0) (rd_en_q1&&(rd_addr_q1==wr_addr_q1) |-> rd_data==wr_data_q1 );
endproperty

check_rd_match_wr: assert property(rd_should_match_write_for_same_addr);



//save last write
logic wr_en_last;
logic [5:0] wr_addr_last  ;
logic [31:0] wr_data_last;
always @( posedge clk) begin
if(wr_en_q0&&wr_en_q1_flag) begin //only when new write come and previous has a valid write 
        wr_en_last <= 1'b1;
        wr_addr_last <= wr_addr_q1;
        wr_data_last <= wr_data_q1;
end
end


property rd_data_not_same_if_write_different_addr;
@(posedge clk) disable iff (rstb == 0) ( rd_en_q1&&$past(rd_en_q1)&&(rd_addr_q1!=$past(rd_addr_q1))&&
                                        wr_en_last&&(wr_addr_last==$past(rd_addr_q1)) && wr_en_q1_flag&&(wr_addr_q1==rd_addr_q1) &&
                                         (wr_data_last != wr_data_q1)) |-> rd_data!=$past(rd_data) ;
endproperty

check_rd2addr_different: assert property(rd_data_not_same_if_write_different_addr);


endmodule
