set_fml_appmode FPV

#0: not abstract 1: cutpoint 2.user way 3:set_abstractions command 4.set_abstractions with linearize
set abstract_way 3

read_file -top counter -format sverilog -sva -vcs {counter.sv}

switch $abstract_way {
   0 {    }
   1 { snip_driver counter }
   2 {
        snip_driver counter
        fvassume assume_counter1 -expr " counter!='d20000 |=> counter > \$past(counter)"
        fvassume assume_counter2 -expr " counter=='d20000 |=> counter==0"
     }
   3 {  set_abstractions -construct count=32 -using keyvals   ;#abstract counters whose width >=32 }
   4 {  set_abstractions -construct count=32 -using keyvals+linearize ;#linearize make counter's constraint tight 
     }   
   default { puts "Invalid option" }
}

# Clock Definitions 
create_clock clk -period 100

# Reset Definitions 
create_reset rst_n -sense low

#make signals change at posedge clk
set_change_at -clock clk -posedge -default

# Initialisation Commands 
sim_run -stable
sim_save_reset

fvcover cov_stable_counter -expr { ##1 $stable(counter) }
fvcover cov_counter_skip   -expr { counter==3 ##[1:5] counter==30  }

## Proof
check_fv 
 
## Reports
report_fv -list
