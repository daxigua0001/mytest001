
module counter(input clk,rst_n,din,start,output logic [1:0] action);
        reg [7:0] cnt;
        always @(posedge clk or negedge rst_n)
                        if(!rst_n)
                        cnt <= 8'h00;
                        else
                        cnt<= cnt +1'b1;

        always @(posedge clk or negedge rst_n)
                        if(!rst_n)
                        action <= 2'b00;
                        else
                        begin
                        if(cnt == 8'h00)
                        action <= 2'b00;
                        else if(cnt == 8'h60)
                        action <= 2'b01;
                        else if(cnt == 8'hf0)
                        action <= 2'b01;
                        else if(cnt == 8'hf1)
                        action <= 2'b11; 
                        end

assert_action:assert property (@(posedge clk) (cnt == 8'hf1 |=> action==2'b11));
                        
endmodule
