module counter(input clk, rst_n,
               output reg send_typeA,
               output reg send_typeB);
parameter integer unsigned MAX_COUNT=20000;
reg [31:0] counter;
always @(posedge clk or negedge rst_n)
   if(~rst_n)
        counter <='h0;
   else if(counter==MAX_COUNT)
        counter <= 0;
   else
        counter <= counter + 1;

always @(posedge clk or negedge rst_n)
   if(~rst_n)
        send_typeA<='h0;
   else if(counter==MAX_COUNT/2)
        send_typeA <= 1'b1;
   else if(send_typeA)
        send_typeA <= 1'b0;         
always @(posedge clk or negedge rst_n)
   if(~rst_n)
        send_typeB<='h0;
   else if(counter==MAX_COUNT)
        send_typeB <= 1'b1;        
   else if(send_typeB)
        send_typeB <= 1'b0; 
assert_AB_never_same_time:assert property (@(posedge clk) (~(send_typeA&send_typeB)));
assert_send_typeA_is_pulse:assert property (@(posedge clk) (send_typeA |=> ~send_typeA));
assert_send_typeB:assert property (@(posedge clk) (counter==MAX_COUNT |=> send_typeB));
endmodule
