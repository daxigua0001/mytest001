set_fml_appmode FPV

read_file -top counter -format sverilog -sva -vcs {counter.sv}

# Clock Definitions 
create_clock clk -period 100

# Reset Definitions 
create_reset rst_n -sense low

# Initialisation Commands 
sim_run -stable
sim_force -apply 32'hFFFFFFFD counter[31:0]
sim_run 3
sim_save_reset

fvcover counter_max -expr {counter ==32'hFFFF_FFFF}

## Proof
check_fv 
 
## Reports
report_fv -list > results.txt
