clear -all

analyze -sv12 counter.sv

# Elaborate design and properties
elaborate -top counter

# Set up Clocks and Resets
clock clk
reset ~rst_n

abstract -init_value counter
assume -bound 1 {counter == 32'hFFFF_FFFD}
# Get design information to check general complexity
get_design_info

# Prove properties
prove -all

# Report proof results
report
