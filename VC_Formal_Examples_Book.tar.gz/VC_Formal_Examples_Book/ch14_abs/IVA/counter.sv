
module counter(input clk, rst_n,output reg [31:0] counter);

always @(posedge clk or negedge rst_n)
    if(~rst_n)
        counter <=32'h0;
    else if(counter!=32'hFFFFFFFF)
        counter <= counter + 32'h1;

assert_satuartion:assert property (@(posedge clk) counter == 32'hFFFF_FFFF |=> counter == $past(counter));
        
endmodule
