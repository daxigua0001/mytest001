set_fml_appmode FPV

signoff_config -type all

set abstract 0
set design soc 

if {0} {
set_blackbox -cells { u_sram_wrapper u0_uart u0_timer u1_timer u1_uart u_csr  u_gpio u_pinmux u_rom_wrapper u_wb_interconnect u_cpu.u_biu} 
}

# Compilation Step   #note -pvalue+soc.u_sram_wrapper.ADDR_WIDTH=2
if {$abstract} {
read_file -top $design -format sverilog -cov all -sva -vcs {-f riscv_fpv.f +define+FPV_BUG_FIX+ASSERT_BUG_FIX+SEC_BUG_FIX -pvalue+soc.MEM_ADDR_WIDTH=2} 
} else {
read_file -top $design -format sverilog -sva -vcs {-f riscv.f +define+FPV_BUG_FIX }
}

if {$abstract} {
        fvassume regs_shrink_rs1 -expr {u_cpu.instr_rs1[4:0]<4}
        fvassume regs_shrink_rs2 -expr {u_cpu.instr_rs2[4:0]<4}
        fvassume regs_shrink_rd  -expr {u_cpu.instr_rd[4:0] <4}

#snip_driver  {u_cpu.regs[31]}
#fvassume -expr {u_cpu.regs[31][31:0]==0}

fvcover name_regs -expr {u_cpu.regs[0]==1}
fvcover name_regs2 -expr {u_cpu.regs[1]==1}
fvcover name_regs3 -expr {u_cpu.regs[0]==0}
fvcover name_regs4 -expr {u_cpu.regs[3][31:0]==0}

#UART set CYCLES_PER_BIT=8, LOOPBACK mode
#snip_driver  {u0_uart.csr_uart_div}
#set_constant -value 8 u0_uart.csr_uart_div[31:0]
#snip_driver u0_uart.csr_uart_ctrl[0]
#set_constant -value 1 u0_uart.csr_uart_ctrl[0]        
fvassume asm_stable_uart_ctrl  -expr {##14 $stable(u0_uart.csr_uart_ctrl)}
}        
snip_driver { cfg_xfence_timer cfg_xfence_uart0 cfg_xfence_uart1 }
fvassume asm_stable_cfg_xfence -expr { ##1 $stable(cfg_xfence_timer) && $stable(cfg_xfence_uart0) && $stable(cfg_xfence_uart1)}
fvcover cov2 -expr {{cfg_xfence_timer,cfg_xfence_uart0,cfg_xfence_uart1} ==3'd2}
fvcover cov3 -expr {{cfg_xfence_timer,cfg_xfence_uart0,cfg_xfence_uart1} ==3'd3}
fvcover cov4 -expr {{cfg_xfence_timer,cfg_xfence_uart0,cfg_xfence_uart1} ==3'd4}

# Clock Definitions 
create_clock clk -period 100

# Reset Definitions 
create_reset rst_n -sense low

# Initialisation Commands 
sim_run -stable
sim_save_reset

report_blackbox

## Proof
check_fv -block 
 
## Reports
report_fv -list > results.txt
