

`define CSR_RELOAD_VALUE_ADDR 0 
`define CSR_CURRENT_VALUE_ADDR 1
`define CSR_TIMER_CTRL_ADDR 2
`define CSR_INTERRUPT_ADDR 3 
module timer_assert
#(
    parameter ADDR_WIDTH = 10  
)
(
   input                                  clk,
   input                                  rst_n,
   input [31:0] csr_regs_reload,
   input [1:0] csr_regs_ctrl,
   input [1:0] csr_regs_intr_en,
   input [31:0] counter,
   input IRQ,
   input wr_reload,
   input  reg [ADDR_WIDTH-1:0] wb_addr_i,
   input  reg               [31:0] wb_dat_i,
   input  reg                      wb_we_i,
   input  reg               [3:0]  wb_sel_i,
   input  reg                      wb_stb_i   
   );



cover_IRQ_active: cover property ( @(posedge clk) disable iff (~rst_n) 
    counter == 32'h1 ##1 IRQ==1 
);


assert_counter_never_out_range: assert property ( @(posedge clk) disable iff (~rst_n)
    !(counter<0 || counter>csr_regs_reload)
);
assert_counter_eq0_if_IRQ_active: assert property ( @(posedge clk) disable iff (~rst_n)
    IRQ |-> counter==32'h0000_0000
);


assert_counter_stable_if_disble_timer: assert property ( @(posedge clk) disable iff (~rst_n)
    ~(csr_regs_ctrl[0] | wr_reload) |=> $stable(counter)
);

bit [31:0] counter_irq_distance;
bit had_IRQ;
always @(posedge clk)
if(IRQ)
    counter_irq_distance<='h0;
else
    counter_irq_distance<=counter_irq_distance+'h1;
always @(posedge clk or negedge rst_n)
if(~rst_n)
    had_IRQ<=1'b0;
else if(IRQ)
    had_IRQ<=1'b1;




    
/*        
assert_IRQ_distance_should_be_ge_reload_val:assert property ( @(posedge clk) disable iff (~rst_n)
    had_IRQ&IRQ |-> counter_irq_distance >= csr_regs_reload 
);
assume_IRQ_distance_lt_100_reload_val:assume property ( @(posedge PCLK) disable iff (~PRESETn)
    counter_irq_distance <100
);
cover_IRQ_distance_eq88:cover property ( @(posedge PCLK) disable iff (~PRESETn)
    had_IRQ&IRQ&(counter_irq_distance ==88)
);
*/

assert_no_irq : assert property ( @(posedge clk) disable iff (~rst_n)
    ~timer.enable_timer |=> ~timer.IRQ
);
assert_0_to_reload : assert property ( @(posedge clk) disable iff (~rst_n)
    ((timer.counter==0) && timer.enable_timer) |=> timer.counter == timer.csr_regs_reload 
);
assert_wr_CSR_TIMER_CTRL : assert property ( @(posedge clk) disable iff (~rst_n)
    wb_sel_i==4'hF && wb_stb_i && wb_we_i&&(wb_addr_i[3:0]=={`CSR_TIMER_CTRL_ADDR,2'b00})&&wb_dat_i[0] |-> ##[1:3] timer.csr_regs_ctrl[0]==1 
);


endmodule
bind timer timer_assert u_timer_assert(.*);



