
module soc();


endmodule
