module pad(
 inout pad,
 input pad_oe,
 input pad_in,
 output pad_out
);

assign pad = pad_oe ?  pad_in : 1'bz;
assign pad_out = pad;


endmodule
                
