
module pinmux #(
    parameter  GPIO_WIDTH = 8
               )
(
input  clk,
input  rst_n,

input  test_mode,

output uart0_rx,
input  uart0_tx,

output uart1_rx,
input  uart1_tx,

input  [GPIO_WIDTH-1:0]   gpio_o,
input  [GPIO_WIDTH-1:0]   gpio_oe,
output [GPIO_WIDTH-1:0]   gpio_i,

//test signal
input  [GPIO_WIDTH-1:0]   test_sig0,
input  [GPIO_WIDTH-1:0]   test_sig1,
input  [GPIO_WIDTH-1:0]   test_sig2,

//config
input         cfg_uart0_en,
input         cfg_uart1_en,
input  [1:0]  cfg_test_sig_sel,


//inout pad
inout  PAD_IO_0,
inout  PAD_IO_1,
inout  PAD_IO_2,
inout  PAD_IO_3,
inout  PAD_IO_4,
inout  PAD_IO_5,
inout  PAD_IO_6,
inout  PAD_IO_7
);


reg  [GPIO_WIDTH-1:0]   test_pin_mux;
reg  [GPIO_WIDTH-1:0]   test_pin_mux_en;
reg  [GPIO_WIDTH-1:0]   func_pin_mux;
reg  [GPIO_WIDTH-1:0]   func_pin_mux_en;

reg  [7:0]              test_sig;
reg  [1:0]              cfg_test_sig_sel_r;

wire  pad_0_i;
wire  pad_1_i;
wire  pad_2_i;
wire  pad_3_i;
wire  pad_4_i;
wire  pad_5_i;
wire  pad_6_i;
wire  pad_7_i;

//==========test_sig select===================
always @(posedge clk or negedge rst_n)  begin
  if(~rst_n)  begin
    test_sig <= 8'b0;
  end
  else begin
    if(cfg_test_sig_sel_r == 2'h0) begin
      test_sig <= test_sig0; 
    end
    else if(cfg_test_sig_sel_r == 2'h1) begin
      test_sig <= test_sig1; 
    end
    else if(cfg_test_sig_sel_r == 2'h2) begin
      test_sig <= test_sig2; 
    end    
  end
end


always @(posedge clk or negedge rst_n)  begin
  if(~rst_n)  begin
    cfg_test_sig_sel_r <= 2'b0;
  end
  else begin
    cfg_test_sig_sel_r <= cfg_test_sig_sel;
  end
end  

//==========pad 0=================
always @(*) begin
  if( !test_mode )
  begin
    test_pin_mux[0] = func_pin_mux[0];
    test_pin_mux_en[0] = func_pin_mux_en[0];
  end
  else begin   //test mode
    test_pin_mux[0] = test_sig[0];
    test_pin_mux_en[0] = 1'b1;
  end
end


always @(*) begin
  if(!cfg_uart0_en)  begin
    func_pin_mux[0] = gpio_o[0];
    func_pin_mux_en[0] = gpio_oe[0];
  end
  else begin
    func_pin_mux[0] = uart0_tx;
    func_pin_mux_en[0] = 1'b1;       
  end
end

`ifdef  CC_BUG_FIX
assign  gpio_i[0] = ((!test_mode) && !cfg_uart0_en ) ?  pad_0_i : 1'b0;
`else
assign  gpio_i[0] = ((!test_mode) && cfg_uart0_en ) ?  pad_0_i : 1'b0;     //bug, cfg_uart0_en
`endif


pad_io   u0_pad_io(
.i(pad_0_i),
.o(test_pin_mux[0]),
.oe(test_pin_mux_en[0]),
.pad(PAD_IO_0)
);


//==========pad 1=================
always @(*) begin
  if( !test_mode )
  begin
    test_pin_mux[1] = func_pin_mux[1];
    test_pin_mux_en[1] = func_pin_mux_en[1];
  end
  else begin   //test mode
    test_pin_mux[1] = test_sig[1];
    test_pin_mux_en[1] = 1'b1;
  end
end


always @(*) begin
  if(!cfg_uart0_en)  begin
    func_pin_mux[1] = gpio_o[1];
    func_pin_mux_en[1] = gpio_oe[1];
  end
  else begin
    func_pin_mux[1] = 1'b0;       
    func_pin_mux_en[1] = 1'b0;       
  end
end


assign  gpio_i[1] = ((!test_mode) && !cfg_uart0_en ) ?  pad_1_i : 1'b0;
assign  uart0_rx = ((!test_mode) && cfg_uart0_en ) ?  pad_1_i : 1'b0;


pad_io   u1_pad_io(
.i(pad_1_i),
.o(test_pin_mux[1]),
.oe(test_pin_mux_en[1]),
.pad(PAD_IO_1)
);


//==========pad 2=================
always @(*) begin
  if( !test_mode )
  begin
    test_pin_mux[2] = func_pin_mux[2];
    test_pin_mux_en[2] = func_pin_mux_en[2];
  end
  else begin   //test mode
    test_pin_mux[2] = test_sig[2];
    test_pin_mux_en[2] = 1'b1;
  end
end


always @(*) begin
  if(!cfg_uart1_en)  begin
    func_pin_mux[2] = gpio_o[2];
    func_pin_mux_en[2] = gpio_oe[2];
  end
  else begin
    func_pin_mux[2] = uart1_tx;
    func_pin_mux_en[2] = 1'b1;       
  end
end

assign  gpio_i[2] = ((!test_mode) && !cfg_uart1_en ) ?  pad_2_i : 1'b0;


pad_io   u2_pad_io(
.i(pad_2_i),
.o(test_pin_mux[2]),
.oe(test_pin_mux_en[2]),
.pad(PAD_IO_2)
);


//==========pad 3=================
always @(*) begin
  if( !test_mode )
  begin
    test_pin_mux[3] = func_pin_mux[3];
    test_pin_mux_en[3] = func_pin_mux_en[3];
  end
  else begin   //test mode
    test_pin_mux[3] = test_sig[3];
    test_pin_mux_en[3] = 1'b1;
  end
end


always @(*) begin
  if(!cfg_uart1_en)  begin
    func_pin_mux[3] = gpio_o[3];
    func_pin_mux_en[3] = gpio_oe[3];
  end
  else begin
    func_pin_mux[3] = 1'b0;       
    func_pin_mux_en[3] = 1'b0;       
  end
end

assign  gpio_i[3] = ((!test_mode) && !cfg_uart1_en ) ?  pad_3_i : 1'b0;
assign  uart1_rx = ((!test_mode) && cfg_uart1_en ) ?  pad_3_i : 1'b0;


pad_io   u3_pad_io(
.i(pad_3_i),
.o(test_pin_mux[3]),
.oe(test_pin_mux_en[3]),
.pad(PAD_IO_3)
);



//==========pad 4 to 7=================
genvar i;

generate 
  for(i=4;i<8;i=i+1)  begin: pin_mux
      always @(*) begin
        if( !test_mode )
        begin
          test_pin_mux[i] = func_pin_mux[i];
          test_pin_mux_en[i] = func_pin_mux_en[i];
        end
        else begin   //test mode
          test_pin_mux[i] = test_sig[i];
          test_pin_mux_en[i] = 1'b1;
        end
      end
      
      
      always @(*) begin
          func_pin_mux[i] = gpio_o[i];
          func_pin_mux_en[i] = gpio_oe[i];
      end
  end
endgenerate



pad_io   u4_pad_io(
.i(pad_4_i),
.o(test_pin_mux[4]),
.oe(test_pin_mux_en[4]),
.pad(PAD_IO_4)
);


pad_io   u5_pad_io(
.i(pad_5_i),
.o(test_pin_mux[5]),
.oe(test_pin_mux_en[5]),
.pad(PAD_IO_5)
);


pad_io   u6_pad_io(
.i(pad_6_i),
.o(test_pin_mux[6]),
.oe(test_pin_mux_en[6]),
.pad(PAD_IO_6)
);


pad_io   u7_pad_io(
.i(pad_7_i),
.o(test_pin_mux[7]),
.oe(test_pin_mux_en[7]),
.pad(PAD_IO_7)
);



assign  gpio_i[4] = ((!test_mode)) ?  pad_4_i : 1'b0;
assign  gpio_i[5] = ((!test_mode)) ?  pad_5_i : 1'b0;
assign  gpio_i[6] = ((!test_mode)) ?  pad_6_i : 1'b0;
assign  gpio_i[7] = ((!test_mode)) ?  pad_7_i : 1'b0;

endmodule

