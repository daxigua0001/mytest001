`define CSR_RELOAD_VALUE_ADDR 0 
`define CSR_CURRENT_VALUE_ADDR 1
`define CSR_TIMER_CTRL_ADDR 2
`define CSR_INTERRUPT_ADDR 3 

module timer
#(
    parameter ADDR_WIDTH = 10  //4KB by default
)
(
    input                        clk,
    input                        rst_n,
    //wishbone interface
    input		    wb_cyc_i,
    input		    wb_stb_i, 
    input           wb_we_i,
    input	[ADDR_WIDTH-1:0]	wb_addr_i,
    input	[31:0]	wb_dat_i,
    input	[3:0]	wb_sel_i,
    output	wire	wb_stall_o,
    output	reg		wb_ack_o,
    output	reg	[31:0] wb_dat_o,    
    output  reg                     IRQ// interrupt
);

    // always ready to capture the data into the timer, assume never transfare failure
	always @(posedge clk) 
		wb_ack_o <= (wb_stb_i)&&(wb_cyc_i);
    
    wire read_en=wb_stb_i && wb_cyc_i && ~wb_we_i  &&(wb_addr_i[ADDR_WIDTH-1:4]==0) ;
    wire write_en=wb_we_i && wb_cyc_i && wb_stb_i;

    
    // Control and State registers for this timer
    
    reg  [31:0]  csr_regs [0:3];

  always @(posedge clk or negedge rst_n)
  begin
    if (~rst_n)
      csr_regs[`CSR_RELOAD_VALUE_ADDR] <= 32'h0000_0000;
    else if (write_en && (wb_addr_i[3:0]=={`CSR_RELOAD_VALUE_ADDR,2'b00}))
      csr_regs[`CSR_RELOAD_VALUE_ADDR] <= wb_dat_i;
  end
  always @(posedge clk or negedge rst_n)
  begin
    if (~rst_n)
      csr_regs[`CSR_CURRENT_VALUE_ADDR] <= 32'h0000_0000;
    else if (write_en && (wb_addr_i[3:0]=={`CSR_CURRENT_VALUE_ADDR,2'b00}))
      csr_regs[`CSR_CURRENT_VALUE_ADDR] <= wb_dat_i;
  end  
  always @(posedge clk or negedge rst_n)
  begin
    if (~rst_n)
      csr_regs[`CSR_TIMER_CTRL_ADDR] <= 32'h0000_0000;
    else if (write_en && (wb_addr_i[3:0]=={`CSR_TIMER_CTRL_ADDR,2'b00}))
      csr_regs[`CSR_TIMER_CTRL_ADDR][0] <= wb_dat_i[0];
  end  
  always @(posedge clk or negedge rst_n)
  begin
    if (~rst_n)
      csr_regs[`CSR_INTERRUPT_ADDR] <= 32'h0000_0000;
    else if (write_en && (wb_addr_i[3:0]=={`CSR_INTERRUPT_ADDR,2'b00}))
      csr_regs[`CSR_INTERRUPT_ADDR] <= wb_dat_i;
  end  

 always @(posedge clk or negedge rst_n)
  begin
    if (~rst_n)
      wb_dat_o <= 32'h0000_0000;
    else if (read_en )
      case(wb_addr_i[3:0])
          {`CSR_RELOAD_VALUE_ADDR,2'b00}:
        wb_dat_o<= csr_regs[`CSR_RELOAD_VALUE_ADDR];
          {`CSR_CURRENT_VALUE_ADDR,2'b00}:
        wb_dat_o<= csr_regs[`CSR_CURRENT_VALUE_ADDR];
          {`CSR_TIMER_CTRL_ADDR,2'b00}:
        wb_dat_o<= csr_regs[`CSR_TIMER_CTRL_ADDR];//bit 0 is valid for timer enable
          {`CSR_INTERRUPT_ADDR,2'b00}:
        wb_dat_o<= csr_regs[`CSR_INTERRUPT_ADDR]; //bit 0 is valid for interrupt enable
      endcase
  end



  //timer counter 
  reg [31:0] counter;

  wire enable_timer= csr_regs[`CSR_TIMER_CTRL_ADDR][0];
  wire wr_reload = write_en&(wb_addr_i[3:0]=={`CSR_RELOAD_VALUE_ADDR,2'b00});
  wire counter_eq0=  enable_timer&&(counter==32'h0000_0000);
  always @(posedge clk or negedge rst_n)
  begin
    if (~rst_n)
      counter <= 32'h0000_0000;
    else if (wr_reload)
      counter <= wb_dat_i;      
    else if (counter_eq0)
      counter <= csr_regs[`CSR_RELOAD_VALUE_ADDR];
    else if (enable_timer)
      counter <= counter -32'h0000_0001;
  end

  // Trigger an interrupt when decrement to 0 and interrupt enabled
  wire timer_interrupt_set= (enable_timer & csr_regs[`CSR_INTERRUPT_ADDR][0] & (counter==32'h00000001));

  always @(posedge clk or negedge rst_n)
  begin
    if (~rst_n)
      IRQ <= 1'b0;
    else if (IRQ)
      IRQ <= 1'b0;
    else if (timer_interrupt_set)
      IRQ <= 1'b1;
  end  


endmodule
