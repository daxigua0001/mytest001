../../rtl_riscv_soc/cpu.sv
../../rtl_riscv_soc/rom_wrapper.sv
../../rtl_riscv_soc/sram_wrapper.sv
./soc.sv
../../rtl_riscv_soc/wb_interconnect.sv
../../rtl_riscv_soc/biu.v
../../rtl_riscv_soc/default_slave.v
../../rtl_riscv_soc/pad_io.v
../../rtl_riscv_soc/pinmux.v
../../rtl_riscv_soc/csr.v
../../rtl_riscv_soc/x_fence.v

../../rtl_riscv_soc/UART/uart.v
../../rtl_riscv_soc/UART/uart_tx.v
../../rtl_riscv_soc/UART/uart_rx.v
../../rtl_riscv_soc/UART/fifo.v
../../rtl_riscv_soc/UART/cg.v

../../rtl_riscv_soc/TIMER/timer.v
./timer_assert.sv
./timer_assume.sv


../../rtl_riscv_soc/gpio.v



