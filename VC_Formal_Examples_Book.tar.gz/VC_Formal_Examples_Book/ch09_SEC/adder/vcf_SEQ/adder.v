/*an adder for two 32 bits input */

module adder 
(
    input  wire                 clk,
    input  wire                 rst_n,

    input      [31:0] a,
    input      [31:0] b,
    output reg [31:0] c    
);

    always @(posedge clk or negedge rst_n)
        if(~rst_n) begin
            c<='h0;
        end else begin
            c<=a+b;
        end
endmodule




