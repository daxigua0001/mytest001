############## Setup variables ##################################
set_fml_appmode SEQ
set design "adder" ;
seq_config -map_uninit -map_counters -map_x bestmatch

############## Read and elaborate design ########################
analyze -format sverilog -vcs " adder.v " -library spec 
analyze -format sverilog -vcs " adder_retiming.v" -library impl
elaborate_seq -spectop $design -impltop $design -sva

############## Mapping##########################################
map_by_name -impl_latency 1 -clock spec.clk

############## Add clock/reset and generate reset state##########
create_clock spec.clk -period 100 -initial 1
create_reset spec.rst_n -sense low 
sim_run -stable
sim_save_reset

############## Add assume/assert/cover if necessary##############
fvcover ab_max  -expr { spec.a==32'hFFFF_FFFF && spec.b==32'hFFFF_FFFF }

############## Check and run ####################################
check_fv_setup -block
check_fv -block

############## Report result ####################################
report_fv -verbose
report_proofs
