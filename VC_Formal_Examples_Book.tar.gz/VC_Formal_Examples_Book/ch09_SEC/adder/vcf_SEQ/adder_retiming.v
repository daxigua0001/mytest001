/*an adder for two 32 bits input */

module adder 
(
    input  wire                 clk,
    input  wire                 rst_n,

    input      [31:0] a,
    input      [31:0] b,
    output reg [31:0] c
);
 reg [16:0] c_low_pre;
    always @(posedge clk or negedge rst_n)
        if(~rst_n) begin
            c_low_pre<='h0;
        end else begin
            c_low_pre<=a[15:0]+b[15:0];
        end
 reg [15:0] a_high,b_high,c_low,c_high;
    always @(posedge clk or negedge rst_n)
        if(~rst_n) begin
            a_high<='h0;
            b_high<='h0;
            c_low<='h0;
        end else begin
            a_high<=a[31:16];
            b_high<=b[31:16];
            c_low<=c_low_pre[15:0];
        end

    wire c_low_carry= c_low_pre[16];
    always @(posedge clk or negedge rst_n)
        if(~rst_n) begin
            c_high<='h0;
        end else begin
            c_high<=a_high+b_high+c_low_carry;
        end        

always@*
c= {c_high,c_low};

endmodule




