This directory show an 2-pipe staged multi-bits xor operation retiming example. Use VCF SEQ tool to verify the change.
To run:
	vcf -f xor_seq.tcl -gui & 
To clean up:
	rm -rf simv.daidir simv csrc *.fsdb verdiLog novas* ucli.key vcst_* vcf.log* elab_summary* *_learn_dir vcst* vdCovLog FPV_COV_FCORE_w_fcore.el *.log results.txt no_trace* *.rpt
