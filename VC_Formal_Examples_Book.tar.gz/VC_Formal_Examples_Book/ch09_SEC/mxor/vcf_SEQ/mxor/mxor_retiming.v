/*a two pipe stage multi-bits xor operation unit*/

module mxor 
(
    input  clk,
    input  rst_n,
    input  pipe_en,
    input  [399:0]	a,
    output reg a_xor,
    output reg a_xor_valid
);
    
    reg pipe_en_q,pipe_en_out;
    always @(posedge clk or negedge rst_n)
        if(~rst_n) begin
            pipe_en_q<='h0;
            pipe_en_out<='h0;
        end else begin
            pipe_en_q<=pipe_en;
            a_xor_valid <=pipe_en_q;
        end

   reg [19:0] tmp_xor;
   integer i;
       always @(posedge clk or negedge rst_n)
        if(~rst_n) begin
            tmp_xor<='h0;
        end else begin
            for(i=0; i< 20; i=i+1) begin
              if(pipe_en)
              tmp_xor[i]<=^a[i*20+:20];
            end
        end

    always @(posedge clk or negedge rst_n)
        if(~rst_n) begin
            a_xor<='h0;
        end else if(pipe_en_q)begin
            a_xor<=^tmp_xor;
        end


endmodule




