/*a two pipe stage multi-bits xor operation unit*/

module mxor
(
    input  clk,
    input  rst_n,
    input  [399:0]	a,
    output reg a_xor
);

    reg a_low_xor_q;
    always @(posedge clk or negedge rst_n)
        if(~rst_n) begin
            a_low_xor_q<='h0;
        end else begin
            a_low_xor_q<=^a[299:0];
        end

    reg [99:0] a_high_q;
    always @(posedge clk or negedge rst_n)
        if(~rst_n) begin
            a_high_q<='h0;
        end else begin
            a_high_q<=a[399:300];
        end
    
    always @(posedge clk or negedge rst_n)
        if(~rst_n) begin
            a_xor<='h0;
        end else begin
            a_xor<=^{a_high_q,a_low_xor_q};
        end
endmodule




