module mxor_cons_issue2(
   input              clk,
   input              rst_n, 
   input              pipe_en
   );

assume_pipe_en: assume property (@(posedge clk) pipeen);

//fix: 
//assume_pipe_en: assume property (@(posedge clk) pipe_en);


endmodule

bind seq_top.impl mxor_cons_issue2 cons(.*);   
