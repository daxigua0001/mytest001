############## Setup variables ##################################
set_fml_appmode SEQ
set design "mxor" ;
seq_config -map_uninit -map_counters -map_x bestmatch

############## Read and elaborate design ########################
analyze -format sverilog -vcs " mxor.v " -library spec 
analyze -format sverilog -vcs " mxor_retiming.v   \
                                mxor_cons.sv" -library impl
elaborate_seq -spectop $design -impltop $design -sva

############## Add clock/reset and generate reset state##########
create_clock spec.clk -period 100 -initial 1
create_reset spec.rst_n -sense low 
sim_run -stable
sim_set_state -uninitialized -apply 0
sim_save_reset

############## Mapping##########################################
map_by_name

############## Add assume/assert/cover if necessary##############
fvcover a_max_min  -expr " spec.a=={400{1'b1}} ##1 spec.a=={400{1'b0}} "

############## Check and run ####################################
check_fv_setup -block
check_fv -block

############## Report result ####################################
report_fv -verbose
report_proofs
