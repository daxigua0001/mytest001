module mxor_cons(
   input              clk,
   input              rst_n, 
   input              pipe_en
   );

assume_pipe_en: assume property (@(posedge clk) pipe_en);


endmodule

bind seq_top.impl mxor_cons cons(.*);   

