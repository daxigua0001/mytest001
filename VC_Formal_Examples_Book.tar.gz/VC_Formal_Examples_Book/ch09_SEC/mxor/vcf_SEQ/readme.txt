This directory show example of book 1.3.1 and 1.5 about a design of xor 400 bits input with 2-staged pipe.
directory:
mxor        shows the right code
mxor_issue1 shows 
mxor_issue2 shows pipe_en constraint issue due to wrong signal name pipeen in mxor_cons_issue2.sv 

