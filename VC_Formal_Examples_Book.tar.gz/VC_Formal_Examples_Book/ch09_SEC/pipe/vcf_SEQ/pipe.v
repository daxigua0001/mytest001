module pipe( 
input               clk, rst_n,
input         [7:0] data,
input               data_vld,
output reg    [7:0] data_o,
output reg          data_o_vld);
 
reg data_vld_q0;
always @(posedge clk or negedge rst_n)
if(~rst_n)
    data_vld_q0<=1'b0;
else
    data_vld_q0<=data_vld;
always @(posedge clk or negedge rst_n)
if(~rst_n)
    data_o_vld <=1'b0;
else
    data_o_vld <=data_vld_q0;
 
 
reg [7:0] data_q0;
always @(posedge clk or negedge rst_n)
if(~rst_n)
     data_q0 <= 8'h00;
else if(data_vld)
    data_q0 <= data;
always @(posedge clk or negedge rst_n)
if(~rst_n)
  data_q0<=8'h00;
else if(data_vld_q0)
   data_o<=data_q0;
 
endmodule
