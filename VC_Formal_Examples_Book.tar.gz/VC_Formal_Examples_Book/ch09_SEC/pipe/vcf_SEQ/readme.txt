This directory show an 2 staged pipe example. Use VCF SEQ tool to verify the change of removing registers' reset.
Method is to verify the changed version by comparing itself to itself
Step1: run pipe_no_rst.v version with RTL bug:
	vcf -f pipe_seq.tcl -gui & 
Step2: run pipe_no_rst_fix.v version which fixed RTL issue:
	vcf -f pipe_seq_fix.tcl -gui & 

After above 2 steps, user can try to run pipe_seq.tcl with "#seq_config -map_uninit -map_x zero" or "#sim_force { spec.data_vld_q0 impl.data_vld_q0 } -apply 1'b0" in pipe_seq.tcl uncommented and see what happens. Checkers should pass because these setting will map X between spec and impl to the same value which would hide the bug. So don't use them when verify such "remove reset pin for registers" feature change.

To clean up, use can use "make clean" or followng shell command:
	rm -rf simv.daidir simv csrc *.fsdb verdiLog novas* ucli.key vcst_* vcf.log* elab_summary* *_learn_dir vcst* vdCovLog FPV_COV_FCORE_w_fcore.el *.log results.txt no_trace* *.rpt
