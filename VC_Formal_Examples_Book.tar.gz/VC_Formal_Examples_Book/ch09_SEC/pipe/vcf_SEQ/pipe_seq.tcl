############## Setup variables ##################################
set_fml_appmode SEQ
set design "pipe" ;
seq_config -map_uninit -map_counters -map_x bestmatch

############## Read and elaborate design ########################
analyze -format sverilog -vcs "pipe_no_rst.v" 
elaborate_seq -spectop $design -same_design

############## Mapping##########################################
map_by_name -input

############## Add clock/reset and generate reset state##########
create_clock spec.clk -period 100 -initial 1
create_reset spec.rst_n -sense low 
sim_run -stable
#sim_force { spec.data_vld_q0 impl.data_vld_q0 } -apply 1'b0
sim_save_reset

############## Add assume/assert/cover if necessary##############
fvcover cov_vld_o -expr {spec.data_o_vld==1'b1}
fvassert ast_data_o_vld -expr {spec.data_o_vld==impl.data_o_vld}
fvassert ast_data_o -expr {spec.data_o_vld |-> spec.data_o==impl.data_o}

############## Check and run ####################################
check_fv -block

############## Report result ####################################
report_fv -verbose
report_proofs
