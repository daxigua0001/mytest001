set_fml_appmode SEQ

set design uart

set_blackbox -designs {*mem*}

seq_config -map_uninit -map_counters -map_x bestmatch

analyze -format sverilog -vcs " -sverilog -assert svaext +define+FPV_BUG_FIX+FXP_BUG_FIX+CC_BUG_FIX  -f riscv.f "
elaborate_seq -same_design -spectop $design -impltop $design 

map_by_name -exclude  { tx_free_run rx_free_run }

snip_driver -env spec.tx_free_run
snip_driver -env impl.tx_free_run
snip_driver -env spec.rx_free_run
snip_driver -env impl.rx_free_run

fvassume tx_free_run_const1 -expr {spec.tx_free_run==1} 
fvassume tx_free_run_const0 -expr {impl.tx_free_run==0} 
fvassume rx_free_run_const1 -expr {spec.rx_free_run==1} 
fvassume rx_free_run_const0 -expr {impl.rx_free_run==0}

fvcover  tx_wb_wr_fifo -expr { spec.tx_wb_wr_fifo }
fvcover  uart_tx_busy -expr { spec.uart_tx_busy [->2] ##[30:300] ~spec.uart_tx_busy [->2] ##30 ~spec.rx_fifo_empty }
fvcover cov_tx_free_run_constraint -expr {(spec.tx_free_run ==1 && impl.tx_free_run ==0) [*3] }
fvcover cov_rx_free_run_constraint -expr {(spec.rx_free_run ==1 && impl.rx_free_run ==0) [*3] }

create_clock {spec.clk} -period 100 -initial 0
create_reset spec.rst_n -sense low 

sim_run -stable
sim_set_state -uninitialized -apply 0
sim_save_reset

set_change_at -clock spec.clk -posedge -default

check_fv

