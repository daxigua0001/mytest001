set_fml_appmode SEQ

set design uart

set_blackbox -designs {*mem*}

seq_config -map_uninit -map_counters -map_x bestmatch

analyze -format sverilog -vcs " -sverilog -assert svaext +define+FPV_BUG_FIX+FXP_BUG_FIX+CC_BUG_FIX -f riscv.f "
elaborate_seq -same_design -spectop $design -impltop $design -vcs "+lint=TFIPC-L -suppress=SM_IGN_FINAL,SVAC-IAAB,SVAC-IATFNS,UII-L,SV-LCM-PPWI -error=XMRE-L -error=XMRE-L,SM_BNP "

map_by_name -exclude  { csr_uart_tx_cg_free_run csr_uart_rx_cg_free_run }

snip_driver -env -seqmap spec.csr_uart_tx_cg_free_run
#snip_driver -env spec.csr_uart_tx_cg_free_run
#snip_driver -env impl.csr_uart_tx_cg_free_run

snip_driver -env spec.csr_uart_rx_cg_free_run
snip_driver -env impl.csr_uart_rx_cg_free_run

create_clock {spec.clk} -period 100 -initial 0
create_reset spec.rst_n -sense low 

sim_run -stable
sim_set_state -uninitialized -apply 0
sim_save_reset

fvassume csr_uart_tx_cg_free_run_const1 -expr {spec.csr_uart_tx_cg_free_run==1} 
fvassume csr_uart_tx_cg_free_run_const0 -expr {impl.csr_uart_tx_cg_free_run==0} 
fvassume csr_uart_rx_cg_free_run_const1 -expr {spec.csr_uart_rx_cg_free_run==1} 
fvassume csr_uart_rx_cg_free_run_const0 -expr {impl.csr_uart_rx_cg_free_run==0}

fvcover  tx_wb_wr_fifo -expr { spec.tx_wb_wr_fifo }
fvcover  tx_busy -expr { spec.tx_busy [->2] ##[30:300] ~spec.tx_busy [->2] ##30 ~spec.rx_fifo_empty }
fvcover cov_csr_uart_tx_cg_free_run_constraint -expr {(spec.csr_uart_tx_cg_free_run ==1 && impl.csr_uart_tx_cg_free_run ==0) [*3] }
fvcover cov_csr_uart_rx_cg_free_run_constraint -expr {(spec.csr_uart_rx_cg_free_run ==1 && impl.csr_uart_rx_cg_free_run ==0) [*3] }

set_change_at -clock spec.clk -posedge -default

check_fv

