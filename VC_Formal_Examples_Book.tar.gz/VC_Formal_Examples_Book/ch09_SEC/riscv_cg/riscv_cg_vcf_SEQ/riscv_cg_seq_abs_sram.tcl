set_fml_appmode SEQ

set design soc 

set_blackbox -designs {sram_wrapper}
set_blackbox -designs {cpu}

set_seq_abstractions -construct {add=8}

analyze -format sverilog -vcs " -sverilog -assert svaext +define+FPV_BUG_FIX+FXP_BUG_FIX+CC_BUG_FIX+SEC_BUG_FIX -f riscv.f "
elaborate_seq -same_design -spectop $design -impltop $design -vcs "+lint=TFIPC-L -suppress=SM_IGN_FINAL,SVAC-IAAB,SVAC-IATFNS,UII-L,SV-LCM-PPWI -error=XMRE-L -error=XMRE-L,SM_BNP "

map_by_name 

##timer0####
snip_driver -env spec.u0_timer.timer_clk_free_run
snip_driver -env impl.u0_timer.timer_clk_free_run
fvassume timer_free1 -expr {spec.u0_timer.timer_clk_free_run==1} 
fvassume timer_free0 -expr {impl.u0_timer.timer_clk_free_run==0} 
fvcover  timer_busy  -expr {$rose(spec.u0_timer.timer_busy)[->2]}

##uart0####
snip_driver -env spec.u0_uart.tx_free_run
snip_driver -env impl.u0_uart.tx_free_run
fvassume u0_tx_free_run1 -expr {spec.u0_uart.tx_free_run==1} 
fvassume u0_tx_free_run0 -expr {impl.u0_uart.tx_free_run==0} 
fvcover u0_tx_busy -expr {$rose(spec.u0_uart.tx_busy)[->2]}
snip_driver -env spec.u0_uart.rx_free_run
snip_driver -env impl.u0_uart.rx_free_run
fvassume u0_rx_free_run1 -expr {spec.u0_uart.rx_free_run==1} 
fvassume u0_rx_free_run0 -expr {impl.u0_uart.rx_free_run==0}
fvcover u0_rx_busy -expr {$rose(spec.u0_uart.rx_busy)[->2]}

##uart1####
snip_driver -env spec.u1_uart.tx_free_run
snip_driver -env impl.u1_uart.tx_free_run
fvassume u1_tx_free_run1 -expr {spec.u1_uart.tx_free_run==1} 
fvassume u1_tx_free_run0 -expr {impl.u1_uart.tx_free_run==0} 
fvcover u1_tx_busy -expr {$rose(spec.u1_uart.tx_busy)[->2]}
snip_driver -env spec.u1_uart.rx_free_run
snip_driver -env impl.u1_uart.rx_free_run
fvassume u1_rx_free_run1 -expr {spec.u1_uart.rx_free_run==1} 
fvassume u1_rx_free_run0 -expr {impl.u1_uart.rx_free_run==0}
fvcover u1_rx_busy -expr {$rose(spec.u1_uart.rx_busy)[->2]}

create_clock {spec.clk} -period 100 -initial 0
create_reset spec.rst_n -sense low

sim_run -stable
sim_set_state -uninitialized -apply 0
sim_save_reset

set_change_at -clock spec.clk -posedge -default

check_fv

report_fv
report_proofs

