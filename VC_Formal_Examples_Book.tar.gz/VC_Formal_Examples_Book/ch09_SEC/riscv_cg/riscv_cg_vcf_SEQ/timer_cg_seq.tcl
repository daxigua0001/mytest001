###This script is used to show only enable impl side timer clock gate enable and let other clocks free run ######
set_fml_appmode SEQ

set design timer

set_fml_var fml_max_mem 64GB

seq_config -map_uninit -map_counters -map_x bestmatch

analyze -format sverilog -vcs " -sverilog -assert svaext +define+FPV_BUG_FIX+FXP_BUG_FIX+CC_BUG_FIX+SEC_BUG_FIX -f riscv.f "
elaborate_seq -same_design -spectop $design -impltop $design -vcs "+lint=TFIPC-L -suppress=SM_IGN_FINAL,SVAC-IAAB,SVAC-IATFNS,UII-L,SV-LCM-PPWI -error=XMRE-L -error=XMRE-L,SM_BNP "

map_by_name 

##timer0####
snip_driver -env spec.timer_clk_free_run
snip_driver -env impl.timer_clk_free_run
fvassume timer_free_run_const1 -expr {spec.timer_clk_free_run==1} 
fvassume timer_free_run_const0 -expr {impl.timer_clk_free_run==0} 
fvcover cov_u0_timer_busy -expr { $rose(spec.timer_busy) [->2] }
fvcover cov_IRQ -expr { spec.IRQ==1 ##3 spec.enable_timer }

create_clock {spec.clk} -period 100 -initial 0
create_reset spec.rst_n -sense low 

sim_run -stable
sim_set_state -uninitialized -apply 0
sim_save_reset

set_change_at -clock spec.clk -posedge -default

check_fv

