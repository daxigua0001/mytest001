set_fml_appmode SEQ

set design soc 

set_fml_var fml_max_mem 64GB

set_blackbox -design {sram_wrapper}
#set_blackbox -design {cpu}

#set_seq_abstractions -construct {add=8}

seq_config -map_uninit -map_counters -map_x bestmatch

analyze -format sverilog -vcs " -sverilog -assert svaext +define+FPV_BUG_FIX+FXP_BUG_FIX+CC_BUG_FIX -f riscv.f "
elaborate_seq -same_design -spectop $design -impltop $design -vcs "+lint=TFIPC-L -suppress=SM_IGN_FINAL,SVAC-IAAB,SVAC-IATFNS,UII-L,SV-LCM-PPWI -error=XMRE-L -error=XMRE-L,SM_BNP "

map_by_name 

##timer0####
snip_driver -env spec.u0_timer.timer_clk_free_run
snip_driver -env impl.u0_timer.timer_clk_free_run
fvassume u0_uart.timer_free_run_const1 -expr {spec.u0_timer.timer_clk_free_run==1} 
fvassume u0_uart.timer_free_run_const0 -expr {impl.u0_timer.timer_clk_free_run==1} 
fvcover cov_u0_timer_busy -expr { $rose(spec.u0_timer.timer_busy) [->2] }
fvcover  cov_IRQ -expr { spec.u0_timer.IRQ==1 ##3 spec.u0_timer.enable_timer }

##uart0####
snip_driver -env spec.u0_uart.tx_free_run
snip_driver -env impl.u0_uart.tx_free_run
fvassume u0_uart.tx_free_run_const1 -expr {spec.u0_uart.tx_free_run==1} 
fvassume u0_uart.tx_free_run_const0 -expr {impl.u0_uart.tx_free_run==0} 
fvcover cov_u0_uart_tx_busy -expr { $rose(spec.u0_uart.uart_tx_busy) [->2] }

snip_driver -env spec.u0_uart.rx_free_run
snip_driver -env impl.u0_uart.rx_free_run
fvassume u0_uart.rx_free_run_const1 -expr {spec.u0_uart.rx_free_run==1} 
fvassume u0_uart.rx_free_run_const0 -expr {impl.u0_uart.rx_free_run==1}
fvcover cov_u0_uart_rx_busy -expr { $rose(spec.u0_uart.uart_rx_busy) [->2] }

##uart1####
snip_driver -env spec.u1_uart.tx_free_run
snip_driver -env impl.u1_uart.tx_free_run
fvassume u1_uart.tx_free_run_const1 -expr {spec.u1_uart.tx_free_run==1} 
fvassume u1_uart.tx_free_run_const0 -expr {impl.u1_uart.tx_free_run==1} 
fvcover cov_u1_uart_tx_busy -expr { $rose(spec.u1_uart.uart_tx_busy) [->2] }

snip_driver -env spec.u1_uart.rx_free_run
snip_driver -env impl.u1_uart.rx_free_run
fvassume u1_uart.rx_free_run_const1 -expr {spec.u1_uart.rx_free_run==1} 
fvassume u1_uart.rx_free_run_const0 -expr {impl.u1_uart.rx_free_run==1}
fvcover cov_u1_uart_rx_busy -expr { $rose(spec.u1_uart.uart_rx_busy) [->2] }

create_clock {spec.clk} -period 100 -initial 0
create_reset spec.rst_n -sense low 

sim_run -stable
sim_set_state -uninitialized -apply 0
sim_save_reset

set_change_at -clock spec.clk -posedge -default

check_fv

