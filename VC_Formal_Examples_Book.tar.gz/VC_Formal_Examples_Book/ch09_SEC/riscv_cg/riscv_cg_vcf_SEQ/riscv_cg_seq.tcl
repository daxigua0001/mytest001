set_fml_appmode SEQ

# Source custom VCF Procs
source ../../../vcf_procs_TCL/vcf_procs.tcl -echo -verbose

#set_blackbox -design {sram_wrapper}
#set_blackbox -design {cpu}

#set_seq_abstractions -construct {add=8}

seq_config -map_uninit -map_counters -map_x bestmatch

analyze -vcs " -sverilog +define+FPV_BUG_FIX+FXP_BUG_FIX+CC_BUG_FIX+SEC_BUG_FIX  -f riscv.f "
elaborate_seq -same_design -spectop soc -impltop soc

map_by_name 

##timer0####
snip_driver -env spec.u0_timer.timer_clk_free_run
snip_driver -env impl.u0_timer.timer_clk_free_run
fvassume timer_free1 -expr {spec.u0_timer.timer_clk_free_run==1} 
fvassume timer_free0 -expr {impl.u0_timer.timer_clk_free_run==0} 
fvcover  timer_busy  -expr {$rose(spec.u0_timer.timer_busy)[->2]}

##uart0####
snip_driver -env spec.u0_uart.tx_free_run
snip_driver -env impl.u0_uart.tx_free_run
fvassume u0_tx_free_run1 -expr {spec.u0_uart.tx_free_run==1} 
fvassume u0_tx_free_run0 -expr {impl.u0_uart.tx_free_run==0} 
fvcover u0_tx_busy -expr {$rose(spec.u0_uart.tx_busy)[->2]}

snip_driver -env spec.u0_uart.rx_free_run
snip_driver -env impl.u0_uart.rx_free_run
fvassume u0_rx_free_run1 -expr {spec.u0_uart.rx_free_run==1} 
fvassume u0_rx_free_run0 -expr {impl.u0_uart.rx_free_run==0}
fvcover u0_rx_busy -expr {$rose(spec.u0_uart.rx_busy)[->2]}

##uart1####
snip_driver -env spec.u1_uart.tx_free_run
snip_driver -env impl.u1_uart.tx_free_run
fvassume u1_tx_free_run1 -expr {spec.u1_uart.tx_free_run==1} 
fvassume u1_tx_free_run0 -expr {impl.u1_uart.tx_free_run==0} 
fvcover u1_tx_busy -expr {$rose(spec.u1_uart.tx_busy)[->2]}

snip_driver -env spec.u1_uart.rx_free_run
snip_driver -env impl.u1_uart.rx_free_run
fvassume u1_rx_free_run1 -expr {spec.u1_uart.rx_free_run==1} 
fvassume u1_rx_free_run0 -expr {impl.u1_uart.rx_free_run==0}
fvcover u1_rx_busy -expr {$rose(spec.u1_uart.rx_busy)[->2]}

create_clock {spec.clk} -period 100 -initial 0
create_reset spec.rst_n -sense low

sim_run -stable
sim_set_state -uninitialized -apply 0
sim_save_reset

set_change_at -clock spec.clk -posedge -default

check_fv

report_fv
report_proofs

# Custom Proc to extract fanout of a specific gated clock
get_clock_domain_regs "spec.u0_timer.clk_cg"
get_clock_domain_regs "spec.u0_uart.clk_cg_tx"
get_clock_domain_regs "spec.u0_uart.clk_cg_rx"

