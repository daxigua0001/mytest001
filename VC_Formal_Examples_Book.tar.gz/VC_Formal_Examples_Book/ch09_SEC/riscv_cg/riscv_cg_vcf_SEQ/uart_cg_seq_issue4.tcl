set_fml_appmode SEQ

set design uart

set_blackbox -designs {*mem*}

seq_config -map_uninit -map_counters -map_x bestmatch

analyze -format sverilog -vcs " -sverilog -assert svaext +define+FPV_BUG_FIX+FXP_BUG_FIX+CC_BUG_FIX  -f riscv.f "
elaborate_seq -same_design -spectop $design -impltop $design -vcs "+lint=TFIPC-L -suppress=SM_IGN_FINAL,SVAC-IAAB,SVAC-IATFNS,UII-L,SV-LCM-PPWI -error=XMRE-L -error=XMRE-L,SM_BNP "

map_by_name -exclude  { tx_free_run rx_free_run }

snip_driver -env -seqmap spec.tx_free_run
set_constant -value 1  spec.tx_free_run
set_constant -value 0  impl.tx_free_run

snip_driver -env -seqmap spec.rx_free_run
set_constant -value 1  spec.rx_free_run
set_constant -value 0  impl.rx_free_run

fvcover  tx_wb_wr_fifo -expr { spec.tx_wb_wr_fifo }
fvcover  tx_busy -expr { spec.tx_busy [->2] ##[30:300] ~spec.tx_busy [->2] ##30 ~spec.rx_fifo_empty }
#fixme, please uncomment following two fvcover and re-run
fvcover  cov_tx_free_run_diff -expr {(spec.tx_free_run ==1 && impl.tx_free_run ==0) [*3] }
fvcover  cov_rx_free_run_diff -expr {(spec.rx_free_run ==1 && impl.rx_free_run ==0) [*3] }

create_clock {spec.clk} -period 100 -initial 0
create_reset spec.rst_n -sense low 

sim_run -stable
sim_set_state -uninitialized -apply 0
sim_save_reset

set_change_at -clock spec.clk -posedge -default

check_fv

