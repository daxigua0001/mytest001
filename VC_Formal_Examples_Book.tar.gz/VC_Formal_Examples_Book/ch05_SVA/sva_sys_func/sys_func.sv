module sys_func();

logic clk = 0;
always #1 clk = ~clk;

logic reset_n;
logic a,b;



test_rose: assert property (@(posedge clk) $rose(a)); 
test_fell: assert property (@(posedge clk) $fell(a)); 
test_isunknown: assert property (@(posedge clk) $isunknown(a)); 
test_past: assert property (@(posedge clk) b |-> ##1 $past(a)); 

test_onehot: assert property (@(posedge clk) $onehot(a)); 
test_onehot0: assert property (@(posedge clk) $onehot0(a)); 

test_stable: assert property (@(posedge clk) $stable(a)); 
test_changed: assert property (@(posedge clk) $changed(a)); 
test_countones: assert property (@(posedge clk) $countones(a)); 

initial begin
  a <= 0; 
  b <= 0; 
  reset_n <= 0;
  @ (posedge clk);
  reset_n <= 1;
  @ (posedge clk);
  a <= 1'bx;
  @ (posedge clk);
  a <= 1;
  repeat(1) @ (posedge clk);
  a <= 1'bz;
  b <= 1;
  @ (posedge clk);
  a <= 1'b1;
  repeat(1) @ (posedge clk);
  a <= 1'b0;
  b <= 0;
  @ (posedge clk);
  a <= 1;
  repeat(2) @ (posedge clk);
  a <= 1'bz;
  @ (posedge clk);
  a <= 1'b0;
  @ (posedge clk);
  a <= 1'bx;
  b <= 1;
  @ (posedge clk);
  a <= 1'b0;
  b <= 0;

  repeat(2) @ (posedge clk);
  a <= 1;
  @ (posedge clk);
  a <= 0;
  repeat(3) @ (posedge clk);
  a <= 1;
  b <= 1;
  @ (posedge clk);
  a <= 0;
  b <= 0;


  #30 $finish;
end


initial begin
      $fsdbDumpfile("tb.fsdb");
      $fsdbDumpvars;
      $fsdbDumpMDA;
      $fsdbDumpSVA;
end


endmodule
