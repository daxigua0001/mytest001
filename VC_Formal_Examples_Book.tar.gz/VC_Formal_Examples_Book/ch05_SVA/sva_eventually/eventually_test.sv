module eventually_test();

logic clk = 0;
always #1 clk = ~clk;

logic reset_n;
logic sop,eop;


 //Property 
 //s_eventually only supported after sv2009
enentually_test: assert property (@(posedge clk) disable iff(!reset_n) 
                                sop |-> s_eventually( eop ));

test:   assert property (@(posedge clk) disable iff(!reset_n)   
                                sop |-> ##[1:$] ( eop ));

//test2:   assert property (@(posedge clk) disable iff(!reset_n)   
//                                sop |-> ##[1:2] ( eop ));
//
//
//strong_test: assert property (@(posedge clk) disable iff(!reset_n) 
//                              //sop |-> strong(##[0:$] eop) 
//                               sop |-> ##[1:$] eop );  
//
//weak_test: assert property (@(posedge clk) disable iff(!reset_n) 
//                              sop |-> weak( ##[1:$] eop ) );
//default_test: assert property (@(posedge clk) disable iff(!reset_n) 
//                              sop |->  ##[1:$] eop );
 


initial begin
  sop <= 0; 
  eop <= 0; 
  reset_n <= 0;
  @ (posedge clk);
  reset_n <= 1;
  @ (posedge clk);
  sop <= 1;
  @ (posedge clk);
  sop <= 0;
  repeat(2) @ (posedge clk);
  sop <= 0;


  #2 $finish;
end


initial begin
      $fsdbDumpfile("tb.fsdb");
      $fsdbDumpvars;
      $fsdbDumpMDA;
      $fsdbDumpSVA;
end


endmodule
