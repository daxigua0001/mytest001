`timescale 1ns/1ns
module seq_operator();

logic clk = 1;
always #1 clk = ~clk;

logic reset_n;
logic a,b;

sequence s1;
    a == 1;
endsequence 

sequence s2;
    b == 1;
endsequence

sequence s3;
    a ##1 b;
endsequence

sequence s4;
    a ##[1:3] b;
endsequence

//test_and: assert property (@(posedge clk) s1 and s2); 
//
//test_or: assert property (@(posedge clk) s1 or s2  ); 
//
//test_intersect: assert property (@(posedge clk) s1 intersect s2 ); 
//
//test_within: assert property (@(posedge clk) s1 within s2 ); 
//
//test_first_match: assert property (@(posedge clk) s1 |-> first_match (s2[*1:8]));
//


test_and: assert property (@(posedge clk) s3 and s2); 
test_and2: assert property (@(posedge clk) s3 and s4); 

test_or: assert property (@(posedge clk) s3 or s4  ); 

test_intersect: assert property (@(posedge clk) s3 intersect s2 ); 

test_within: assert property (@(posedge clk) s3 within s4 ); 



sequence seq_a2;
    a [*2] ;
endsequence

sequence seq_a12;
    a [*1:2] ;
endsequence

sequence seq_b2;
    b [*2] ;
endsequence

sequence seq_b3;
    b [*3] ;
endsequence

sequence seq_b4;
    b [*4] ;
endsequence

sequence seq_b34;
    b [*3:4] ;
endsequence

sequence seq_b_after_a;
    a ##1 b;
endsequence

sequence seq_a_after_b2;
    (b[*2] ##1 a);
endsequence

//test_within2: assert property (@(posedge clk) (seq_a12) within (seq_b34) ); 
//test_within3: assert property (@(posedge clk)  seq_b_after_a within  seq_a_after_b2); 
//test_within4: assert property (@(posedge clk)  a within  b[*2]); 

test_intersect22: assert property (@(posedge clk)  seq_a2 intersect  seq_b2); 
test_intersect23: assert property (@(posedge clk)  seq_a2 intersect  seq_b3);

test_and22: assert property (@(posedge clk)  seq_a2 and  seq_b2); 
test_and23: assert property (@(posedge clk)  seq_a2 and  seq_b3); 

test_within22: assert property (@(posedge clk)  seq_a2 within  seq_b2); 
test_within23: assert property (@(posedge clk)  seq_a2 within  seq_b3);

test_or22: assert property (@(posedge clk)  seq_a2 or  seq_b2); 
test_or23: assert property (@(posedge clk)  seq_a2 or  seq_b3);
test_or32: assert property (@(posedge clk)  seq_b3 or  seq_a2);


test_seq_a2: assert property (@(posedge clk)  seq_a2 ); 
test_seq_b2: assert property (@(posedge clk)  seq_b2 ); 
test_seq_b3: assert property (@(posedge clk)  seq_b3 ); 



test_first_match: assert property (@(posedge clk) s3 |-> first_match (s2[*1:8]));



initial begin
  a <= 0; 
  b <= 0; 
  @ (posedge clk);
  a <= 1;
  b <= 1;  
  @ (posedge clk);
  a <= 1;
  b <= 1;  
  @ (posedge clk);
  a <= 0;
  b <= 1;   
  @ (posedge clk);
  a <= 0;
  b <= 0;   

  repeat(3) @ (posedge clk);
  a <= 0;
  b <= 1;
  @ (posedge clk);
  a <= 1;
  b <= 1; 
  repeat(2) @ (posedge clk);
  a <= 1;
  b <= 1;
  @ (posedge clk);
  a <= 0;
  @ (posedge clk);
  b <= 0;

  repeat(2) @ (posedge clk);
  a <= 1;
  b <= 0;
  @ (posedge clk);
  a <= 0;
  b <= 1;
  @ (posedge clk);
  a <= 0;
  b <= 1;

  repeat(1) @ (posedge clk);
  a <= 1;
  @ (posedge clk);
  a <= 0;
  repeat(1) @ (posedge clk);
  a <= 1;
  b <= 1;  
  repeat(1) @ (posedge clk);
  a <= 1;
  b <= 1;
  @ (posedge clk);
  a <= 0;
  b <= 1;
  @ (posedge clk);
  a <= 0;
  b <= 0;

  #30 $finish;
end


initial begin
      $fsdbDumpfile("tb.fsdb");
      $fsdbDumpvars;
      $fsdbDumpMDA;
      $fsdbDumpSVA;
end


endmodule
