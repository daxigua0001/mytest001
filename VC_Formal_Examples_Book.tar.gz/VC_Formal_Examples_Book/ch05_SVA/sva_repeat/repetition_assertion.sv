module repetition_assertion();

logic clk = 0;
always #1 clk = ~clk;

logic a,b,c;


sequence consec_seq;
  a ##1 b [*2] ##1 c;
endsequence

sequence consec_range_seq;
  a ##1 b [*1:5] ##1 c;
endsequence

sequence non_consec_seq;
  a ##1 b [=2] ##1 c;
endsequence

sequence non_consec_range_seq;
  a ##1 b [=1:2] ##1 c;
endsequence


sequence goto_seq;
  a ##1 b [->2] ##1 c;
endsequence

sequence goto_range_seq;
  a ##1 b [->1:2] ##1 c;
endsequence



// Property 
property consec_prop;
  @ (posedge clk) 
      a |-> (a ##1 b [*2] ##1 c);
endproperty


property consec_range_prop;
  @ (posedge clk) 
      a |-> (a ##1 b [*1:5] ##1 c);
endproperty


property non_consec_prop;
  @ (posedge clk) 
      a |-> (a ##1 b [=2] ##1 c);
endproperty

property non_consec_range_prop;
  @ (posedge clk) 
      a |-> (a ##1 b [=1:2] ##1 c);
endproperty

property goto_prop;
  @ (posedge clk) 
      a |-> (a ##1 b [->2] ##1 c);
endproperty

property goto_range_prop;
  @ (posedge clk) 
      a |-> (a ##1 b [->1:2] ##1 c);
endproperty


// Assertion 
consec_assert     : assert property (consec_prop);
consec_range_assert : assert property (consec_range_prop);
non_consec_assert   : assert property (non_consec_prop);
non_consec_range_assert   : assert property (non_consec_range_prop);
goto_assert       : assert property (goto_prop);
goto_range_assert : assert property (goto_range_prop);

//property ante_seq;
//  @ (posedge clk) 
//     a |-> s_eventually c;
//endproperty
//ante_seq_assert : assert property (ante_seq);
//ante_seq_assert2:assert property (@(posedge clk) a |-> s_eventually b);


initial begin
  a <= 0; b <= 0;c <= 0;
  @ (posedge clk);
  a <= 1;
  @ (posedge clk);
  b <= 1;
  a  <= 0;
  repeat(2) @ (posedge clk);
  b <= 0;
  c <= 1;
  @ (posedge clk);
  a <= 0; b <= 0;c <= 0;
  @ (posedge clk);
  a <= 1;
  @ (posedge clk);
  b <= 1;
  a <= 0;
  repeat(2) @ (posedge clk);
  b <= 0;
  @ (posedge clk);
  c <= 1;
  @ (posedge clk);
  c <= 0;


  @ (posedge clk);
  a <= 1;
  @ (posedge clk);
  b <= 0;
  a <= 0;
  @ (posedge clk);
  b <= 1;
  a  <= 0;
  @ (posedge clk);
  b <= 0;
  a <= 0;
  @ (posedge clk);
  b <= 0;
  c <= 1;
  @ (posedge clk);
  c <= 0;


  @ (posedge clk);
  a <= 1;
  @ (posedge clk);
  b <= 0;
  a <= 0;
  @ (posedge clk);
  b <= 1;
  a  <= 0;
  @ (posedge clk);
  b <= 0;
  c <= 1;
  @ (posedge clk);
  c <= 0;


  #30 $finish;
end


initial begin
      $fsdbDumpfile("tb.fsdb");
      $fsdbDumpvars;
      $fsdbDumpMDA;
      $fsdbDumpSVA;
end


endmodule
