module local_var();

logic clk = 0;
always #1 clk = ~clk;

logic [3:0] din, dout;
logic       in_valid, out_valid;

sequence local_var_seq;
   logic [3:0] local_data;
   (type_in=='d3, local_data = din) ##1 
      (out_valid &&(local_data == dout));
endsequence

property local_var_prop;
  @ (posedge clk) 
      in_valid |-> local_var_seq;
endproperty


local_var_assert : assert property (local_var_prop);

logic [1:0] type_out,type_in;
always @ (posedge clk)
begin
  if(in_valid) begin
    type_out <= type_in;
    dout <= (din == 0) ? ~din : din;
  end
  out_valid  <= in_valid;
end


initial begin
  in_valid <= 0;
  out_valid <= 0;
  din <= 0;
  dout <= 0;
  type_out<=0;
  type_in<= 0;
  repeat (5) @ (posedge clk);
  for (int i =0 ; i < 8; i ++) begin
    @ (posedge clk);
    in_valid <= 1;
    din <= i;
    type_in<= (i%2==0) ? 3:2;
    @ (posedge clk);
    in_valid <= 0;
    din <= 0;
    type_in<= 2;
  end
  #30 $finish;
end


initial begin
      $fsdbDumpfile("tb.fsdb");
      $fsdbDumpvars;
      $fsdbDumpMDA;
      $fsdbDumpSVA;
end

endmodule
