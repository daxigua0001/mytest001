module throughout_test();

logic clk = 1;
always #1 clk = ~clk;

logic reset_n;
logic sop,eop;



test_throughout: assert property (@(posedge clk) disable iff(!reset_n) 
                              sop |=>  (!sop throughout eop[->1])); 


initial begin
  sop <= 0; 
  eop <= 0; 
  reset_n <= 0;
  @ (posedge clk);
  reset_n <= 1;

  @ (posedge clk);
  sop <= 1;
  @ (posedge clk);
  sop <= 0;
  @ (posedge clk);
  sop <= 1;
  @ (posedge clk);
  sop <= 0;
  eop <= 1;  

  @ (posedge clk);
  sop <= 1;
  @ (posedge clk);
  sop <= 0;
  repeat(3) @ (posedge clk);
  sop <= 0;
  eop <= 1;
  @ (posedge clk);

  repeat(3) @ (posedge clk);
  sop <= 1;
  eop <= 0;
  @ (posedge clk);
  sop <= 0;
  repeat(2) @ (posedge clk);
  sop <= 1;
  @ (posedge clk);
  sop <= 0;
  eop <= 1;
  @ (posedge clk);
  sop <= 0;
  eop <= 0;

  repeat(3) @ (posedge clk);
  sop <= 1;
  @ (posedge clk);
  sop <= 0;
  repeat(3) @ (posedge clk);
  sop <= 1;
  eop <= 1;
  @ (posedge clk);
  sop <= 0;
  eop <= 0;


  #30 $finish;
end


initial begin
      $fsdbDumpfile("tb.fsdb");
      $fsdbDumpvars;
      $fsdbDumpMDA;
      $fsdbDumpSVA;
end


endmodule
