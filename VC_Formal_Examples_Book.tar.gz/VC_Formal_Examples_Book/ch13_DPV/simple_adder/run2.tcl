set_fml_appmode DPV

#Enable Vacuity
set_fml_var fml_vacuity_on true

#Enable Witness
set_fml_var fml_witness_on true

#compile spec and impl. Then use compose to wrap them
create_design -name spec -top adder_wrapper -cov
cppan -I. adder.cpp 
compile_design spec

create_design -name impl -top adder -clock clk -reset rst_n -negReset 
vcs adder_retiming.v
compile_design impl

compose

#set_user_assumes_lemmas_procedure "my_assume_assert"
proc my_assume_assert {} {
  map_by_name -inputs -specphase 1 -implphase 1
  map_by_name -outputs -specphase 1 -implphase 5
}

solveNB adder -ual my_assume_assert
#gen_proof -ual my_assume_assert adder 
#check_fv
listproofs

