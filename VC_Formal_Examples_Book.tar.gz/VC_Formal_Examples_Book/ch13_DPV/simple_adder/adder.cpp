#include "Hector.h"
#include <stdint.h>
int adder(uint32_t a, uint32_t b, uint32_t &c) {
  c=(a+b)&(0xFFFFFFFF);
  return 0;
}
int adder_wrapper () {
  uint32_t a,b,c;
  Hector::registerInput ("a", a);
  Hector::registerInput ("b", b);
  Hector::registerOutput("c", c);
  
  Hector::beginCapture();
  adder(a,b,c);
  Hector::endCapture();
  return 0;
}
