set_fml_appmode DPV
set_fml_var fml_vacuity_on true   ;#Enable Vacuity
set_fml_var fml_witness_on true   ;#Enable Witness

#compile spec and impl. Then use compose to wrap them
create_design -name spec -top adder_wrapper -cov
cppan -I. adder.cpp 
compile_design spec

create_design -name impl -top adder -clock clk -reset rst_n -negReset 
vcs adder_retiming.v
compile_design impl

compose

set_user_assumes_lemmas_procedure "my_assume_assert"
proc my_assume_assert {} {
  map_by_name -inputs -specphase 1 -implphase 1
  map_by_name -outputs -specphase 1 -implphase 5

    cover cover_1plus9 = ( (spec.a(1)==1) && (spec.b(1)==1) && (spec.a(2)==2) && (spec.b(2)==2)&& (spec.a(4)==3) && (spec.b(4)==3) && (impl.a(1)==1) && (impl.b(1)==1) && (impl.a(2)==2) && (impl.b(2)==2)&& (impl.a(4)==3) && (impl.b(4)==3) && (impl.a(6)==4) && (impl.b(6)==4)  )


}
gen_proof adder 
check_fv
listproofs

