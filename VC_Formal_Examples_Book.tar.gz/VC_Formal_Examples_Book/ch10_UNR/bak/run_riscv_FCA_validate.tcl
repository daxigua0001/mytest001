set_fml_appmode COV

signoff_config -type cov_all

########################################################
## Setup Specific to DUT
########################################################
set design soc

set_blackbox -cells u_rom_wrapper

# Enabling Trace for Covered Goals
set_fml_var fml_cov_gen_trace on 

########################################################
## Reading Simulation Coverage Database
########################################################
read_covdb -cov_input ../sim_riscv_soc/simv.vdb -cov_dut tb_soc.u_soc -elfiles { test3.el}  -check_el 

########################################################
## Compile & Setup
########################################################
# Compilation Step 
read_file -top $design -format sverilog \
  -vcs {-f  ../riscv.f}

# Clock Definitions
create_clock clk -period 100

# Reset Definitions
create_reset rst_n -sense low

# Initialization Commands
sim_run -stable
sim_save_reset
sim_set_state -uninitialized -apply 0

########################################################
## Proof
########################################################
check_fv -block 

########################################################
## Reports
########################################################
report_fv -list > results.txt

########################################################
## Saving Coverage Database and Exclusion File
########################################################
save_covdb -name cov -status covered -overwrite
save_cov_exclusion -file unr.el

########################################################
## Saving Session
########################################################
save_session -session batch_results 

