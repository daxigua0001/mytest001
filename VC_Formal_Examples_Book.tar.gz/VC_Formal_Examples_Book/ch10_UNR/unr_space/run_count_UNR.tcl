set_fml_appmode COV

signoff_config -type cov_all

########################################################
## Setup Specific to DUT
########################################################
set design counter 

# Enabling Trace for Covered Goals
set_fml_var fml_cov_gen_trace on 

########################################################
## Reading Simulation Coverage Database
########################################################

########################################################
## Compile & Setup
########################################################
# Compilation Step 
read_file -top $design -format verilog \
  -vcs counter.v

fvassume -env -stable -expr { mode }

if { 0} {
fvcover toggle_mode -expr { mode ##1 mode==0 }
fvcover mode01_counter0000 -expr {  counter==0 }
fvcover mode0_counter0001 -expr {  counter==1 }
fvcover mode0_counter0010 -expr {  counter==2 }
fvcover mode0_counter0011 -expr {  counter==3 }
fvcover mode1_counter0100 -expr {  counter==4'b0100 }
fvcover mode1_counter1000 -expr {  counter==4'b1000 }
fvcover mode1_counter1100 -expr {  counter==4'b1100 }

fvcover cons_never_counter0101 -expr {  counter==4'b0101 }
fvcover cons_never_counter0110 -expr {  counter==4'b0110 }
fvcover cons_never_counter0111 -expr {  counter==4'b0111 }
fvcover cons_never_counter1001 -expr {  counter==4'b1001 }
fvcover cons_never_counter1010 -expr {  counter==4'b1010 }
fvcover cons_never_counter1011 -expr {  counter==4'b1011 }
fvcover cons_never_counter1101 -expr {  counter==4'b1101 }
fvcover cons_never_counter1110 -expr {  counter==4'b1110 }
fvcover cons_never_counter1111 -expr {  counter==4'b1111 }
fvcover never_counter01xxxx -expr {  counter[5:4]==2'b01 }
fvcover never_counter10xxxx -expr {  counter[5:4]==2'b10 }
fvcover never_counter11xxxx -expr {  counter[5:4]==2'b11 }
}

# Clock Definitions
create_clock clk -period 100

# Reset Definitions
create_reset rst_n -sense low

# Initialization Commands
sim_run -stable
sim_save_reset

########################################################
## Proof
########################################################
check_fv -block 

########################################################
## Reports
########################################################
report_fv -list > results.txt

########################################################
## Saving Coverage Database and Exclusion File
########################################################
save_cov_exclusion -file counter_unr.el
