module counter(rst_n,clk,mode,counter,max_trigger);
    input rst_n,clk;
    input mode;
    output [3:0] counter;
    output reg max_trigger;

    reg[5:0] counter;
    always@(posedge clk or negedge rst_n)
       if(!rst_n)
        counter<=4'h0;
       else if(mode==0)
        counter[1:0]<= counter[1:0]+1;
       else if(mode==1)
        counter[3:2]<= counter[3:2]+1;

    always@(posedge clk or negedge rst_n)
       if(!rst_n)
        max_trigger<=1'b0;
       else if(max_trigger==1'b1)
        max_trigger<=1'b0;        
       else if(counter[3:0]==4'b1111)
        max_trigger<=1'b1;


endmodule

