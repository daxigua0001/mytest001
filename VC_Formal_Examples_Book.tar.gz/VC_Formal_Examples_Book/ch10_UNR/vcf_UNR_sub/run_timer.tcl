set_fml_appmode COV

signoff_config -type cov_all

## Setup Specific to DUT
set design timer 

# Enabling Trace for Covered Goals
#set_fml_var fml_cov_gen_trace on 

## Reading Simulation Coverage Database
read_covdb -cov_input ../../sim_riscv_soc/simv.vdb -cov_dut u0_timer       

# Compilation Step 
read_file -top $design -format sverilog \
  -vcs {-f  ./riscv.f +define+CC_BUG_FIX +define+FPV_BUG_FIX +define+FXP_BUG_FIX}

# Clock Definitions
create_clock clk -period 100

# Reset Definitions
create_reset rst_n -sense low

# Initialization Commands
sim_run -stable
sim_save_reset

########################################################
## Proof
########################################################
check_fv -block 

########################################################
## Reports
########################################################
report_fv -list > results.txt

########################################################
## Save Exclusion File
########################################################
#save_covdb -name cov -status covered -overwrite
save_cov_exclusion -file unr_timer.el

########################################################
## Saving Session
########################################################
save_session -session batch_results 

