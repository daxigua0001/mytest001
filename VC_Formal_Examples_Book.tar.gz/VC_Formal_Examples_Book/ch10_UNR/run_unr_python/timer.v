//  0x00000000 : 32-bit RELOAD_VALUE                 [ Read & Write ]
//  0x00000004 : 32-bit current counter value        [ Read Only ]
//  0x00000008 : 32-bit TIMER control                [ Read & Write ]
//      bit[0] = enable_timer            :    enable timer when set to 1  
//      bit[1] = timer_cg_clk_free_run   :    disable clock gating feature when set to 1  
//  0x0000000C : 32-bit INTERRUPT related            [ Read & Write ]
//      bit[0] = timer interrupt enable   :   enable timer interrupt when set to 1  


`define CSR_RELOAD_VALUE_ADDR 2'b0 
`define CSR_CURRENT_VALUE_ADDR 2'b01
`define CSR_TIMER_CTRL_ADDR 2'b10
`define CSR_INTERRUPT_ADDR 2'b11 

module timer
#(
    parameter ADDR_WIDTH = 10  //4KB by default
)
(
    input                        clk,
    input                        rst_n,
    //wishbone interface
    input		    wb_cyc_i,
    input		    wb_stb_i, 
    input           wb_we_i,
    input	[ADDR_WIDTH-1:0]	wb_addr_i,
    input	[31:0]	wb_dat_i,
    input	[3:0]	wb_sel_i,
    output	wire	wb_err_o,
    output	reg		wb_ack_o,
    output	reg	[31:0] wb_dat_o,    
    output  reg                     IRQ// interrupt
);

  reg [31:0] counter;
  reg  [31:0]  csr_regs_reload;
  reg  [1:0]  csr_regs_ctrl;
  reg  [1:0]  csr_regs_intr_en;



//UART clock gate logic
wire timer_clk_free_run= csr_regs_ctrl[1];
wire clk_cg; //gated clock for timer 

`ifndef SEC_BUG_FIX
wire timer_busy = wb_cyc_i || csr_regs_ctrl[0];
`else
wire timer_busy = wb_cyc_i || csr_regs_ctrl[0] || IRQ;
`endif

cg cg_timer(
.clk(clk),
.enable(~rst_n||timer_busy||timer_clk_free_run),
.gclk(clk_cg) );



// always ready to capture the data, assume never transfare failure
    	always @(posedge clk or negedge rst_n)
        if(~rst_n)
          wb_ack_o <= 1'b0;
        else if(wb_ack_o)
          wb_ack_o <= 1'b0;
        else
       	  wb_ack_o <= (wb_stb_i)&&(wb_cyc_i);
    
    wire read_en=wb_stb_i && wb_cyc_i && ~wb_we_i  &&(wb_addr_i[ADDR_WIDTH-1:4]==0)&& wb_ack_o ;
    wire write_en=wb_we_i && wb_cyc_i && wb_stb_i && wb_ack_o;

    
    // Control and State registers for this timer
    
    always @(posedge clk_cg or negedge rst_n)
    begin
      if (~rst_n)
        csr_regs_reload <= 32'h0000_0000;
      else if (write_en && (wb_addr_i[3:0]=={`CSR_RELOAD_VALUE_ADDR,2'b00}))
        csr_regs_reload <= wb_dat_i;
    end
    
    always @(posedge clk_cg or negedge rst_n)
    begin
      if (~rst_n)
        csr_regs_ctrl <= 32'h0000_0000;
      else if (write_en && (wb_addr_i[3:0]=={`CSR_TIMER_CTRL_ADDR,2'b00}))
        csr_regs_ctrl[1:0] <= wb_dat_i[1:0];
    end  

    always @(posedge clk_cg or negedge rst_n)
    begin
      if (~rst_n)
        csr_regs_intr_en <= 32'h0000_0000;
      else if (write_en && (wb_addr_i[3:0]=={`CSR_INTERRUPT_ADDR,2'b00}))
        csr_regs_intr_en <= wb_dat_i;
    end  

    always @(posedge clk_cg or negedge rst_n)
    begin
      if (~rst_n)
        wb_dat_o <= 32'h0000_0000;
      else if (read_en )
        case(wb_addr_i[3:0])
            {`CSR_RELOAD_VALUE_ADDR,2'b00}:
          wb_dat_o<= csr_regs_reload;
            {`CSR_CURRENT_VALUE_ADDR,2'b00}:
          //wb_dat_o<= csr_regs[`CSR_CURRENT_VALUE_ADDR];
          wb_dat_o<= counter;      //bug fix 
            {`CSR_TIMER_CTRL_ADDR,2'b00}:
          wb_dat_o<= csr_regs_ctrl;//bit 0 is valid for timer enable, bit 1 for timer clock gating
            {`CSR_INTERRUPT_ADDR,2'b00}:
          wb_dat_o<= csr_regs_intr_en; //bit 0 is valid for interrupt enable
          default: wb_dat_o<= 32'h00000000; 
        endcase
    end



  //timer counter 

  wire enable_timer= csr_regs_ctrl[0];
  wire wr_reload = write_en&(wb_addr_i[3:0]=={`CSR_RELOAD_VALUE_ADDR,2'b00});
  wire counter_eq0=  enable_timer&&(counter==32'h0000_0000);
  always @(posedge clk_cg or negedge rst_n)
  begin
    if (~rst_n)
      counter <= 32'h0000_0000;
    else if (wr_reload)
      counter <= wb_dat_i;      
    else if (counter_eq0)
      counter <= csr_regs_reload;
    else if (enable_timer)
      counter <= counter -32'h0000_0001;
  end

  // Trigger an interrupt when decrement to 0 and interrupt enabled
  wire timer_interrupt_set= (enable_timer & csr_regs_intr_en[0] & (counter==32'h00000001));

  always @(posedge clk_cg or negedge rst_n)
  begin
    if (IRQ)
      IRQ <= 1'b0;
    else if (timer_interrupt_set)
      IRQ <= 1'b1;
  end  

assign  wb_err_o = 1'b0;


endmodule
