set_fml_appmode COV

signoff_config -type cov_all

set design uart 

## Reading Simulation Coverage Database
read_covdb -cov_input ../s.vdb -cov_dut tb_soc.u_soc.u0_uart

read_file -top $design  -vcs {-f ../riscv.f \
 -sv=2012 +define+FPV_BUG_FIX }

create_clock clk -period 100
create_reset rst_n -sense low

sim_run -stable
sim_save_reset

check_fv -block 

report_fv -list > results.txt

save_cov_exclusion -file unr_uart0.el
