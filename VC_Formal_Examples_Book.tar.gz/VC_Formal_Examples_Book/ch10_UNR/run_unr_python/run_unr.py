#!/usr/bin/env python
import os     # for directory operation
import sys    # for geting arguments
import string #for string operation
#UNR config: 5 most importance input to run UNR: blk_name/clk/rst/coverage_databse/instance
blk_dict = {
'timer':{'clk':'clk','rst':'rst_n','vdb':'s.vdb','i':'u0_timer'},
'uart0':{'clk':'clk','rst':'rst_n','vdb':'s.vdb','i':'u0_uart'},
'uart1':{'clk':'clk','rst':'rst_n','vdb':'s.vdb','i':'u1_uart'}}
#generate and run <blk>_unr.tcl file 
def generate_and_run_blk_unr_tcl(blk):
  blk_name=blk.rstrip(string.digits)
  blk_unr_tcl=blk+"_unr.tcl"
  if not os.path.exists(blk+"_unr_run"):
          os.system("mkdir "+blk+"_unr_run")
  os.chdir(blk+"_unr_run")
  fo = open(blk_unr_tcl, "w")
  fo.write("set_fml_appmode COV\n")
  fo.write("set_fml_var fml_reset_property_check true\n")
  fo.write("set_app_var fml_cov_tgl_input_port true\n")
  fo.write("#set_fml_var fml_cov_gen_trace on\n")
  fo.write("set design "+blk_name+" \n")
  fo.write("## Reading Simulation Coverage Database\n")
  fo.write("read_covdb -cov_input ../"+blk_dict[blk]['vdb']+ \
     " -cov_dut tb_soc.u_soc."+blk_dict[blk]['i']+"\n")
  fo.write("read_file -top $design  -vcs {-f ../riscv.f \\\n")
  fo.write(" -sv=2012 +define+FPV_BUG_FIX } -cov all\n")
  fo.write("create_clock "+blk_dict[blk]['clk']+" -period 10\n")
  fo.write("create_reset "+blk_dict[blk]['rst']+" -sense low\n")
  fo.write("sim_run -stable\n")
  fo.write("sim_save_reset\n")
  fo.write("check_fv -block \n")
  fo.write("report_fv -list > results.txt\n")
  fo.write("save_cov_exclusion -file unr_"+blk+".el\n")
  fo.close()
  os.system("vcf -f "+blk+"_unr.tcl -gui &")
  os.chdir("../")
  return

os.putenv('NOVAS_IDLE_LICENSE_CHECKBACK_SILENCE','1') ;#no licence confirm
for blk in blk_dict:
    if(sys.argv[1]== 'all' or sys.argv[1]==blk):
      generate_and_run_blk_unr_tcl(blk)


