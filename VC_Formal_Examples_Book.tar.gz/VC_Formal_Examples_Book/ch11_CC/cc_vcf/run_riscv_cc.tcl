set_fml_appmode CC

#set_message_severity -name CC_UID017 error
set_message_error_action stop

set_app_var fml_cc_coverage_analyzer true      

set design soc 

# Compile the design
#read_file -top $design -format sverilog -cov all -vcs {-f ./riscv.f}
read_file -top $design -format sverilog -cov all -vcs {-f ./riscv.f +define+CC_BUG_FIX}

# Clock Definitions 
create_clock clk -period 100 
#create_clock clk -period 100 -initial 1

create_reset rst_n -sense low 

# csv parameters
load_cc_set_param csv_prop_name "%1%"    ;#name
load_cc_set_param csv_from "%2%"         ;#source
load_cc_set_param csv_to "%3%"           ;#dest            
load_cc_set_param csv_enable "%4%"       ;#enable
load_cc_set_param csv_path_delay "%5%"   ;#path delay
load_cc_set_param csv_enable_hold "%6%"  ;#enable hold
load_cc_set_param csv_enable_delay "%7%" ;#enable delay
load_cc_set_param csv_offset_delay "%8%" ;#offset delay
load_cc_set_param csv_clock "%9%"        ;#clock
load_cc_set_param csv_start_line "2"     ;#start line

#add_cc -src u_gpio.gpio_o -dest u_pinmux.gpio_o -enable {1}

# load csv file
load_cc -format csv riscv.csv

generate_cc -src uart0_tx -dest u_pinmux -file aaa.tcl -run

generate_cc -src {uart_tx,u_gpio.gpio_o,u0_uart.uart_debug} -dest u_pinmux -file bbb.tcl -run
###generate_cc -src u_pinmux -dest {u0_uart.u_uart_rx.rx,u_gpio.gpio_i} -file ccc.tcl -run

report_fv -formatCC csv > test.csv

#generate_cc -src [get_cells u_gpio] -dest u_pinmux -file bbb.csv -run
#set collect [get_nets uart_tx]
#set collect [add_to_collection $collect [get_nets core_dbg_out]]
#    foreach_in_collection inst $collect {
#        set instName [get_attribute $inst full_name];
#        puts "INFO - $instName"
#    }
#set collect [get_cells u_gpio]
#set collect [add_to_collection $collect [get_cells u_uart]]
##set collect [add_to_collection $collect [get_nets core_dbg_out]]
#generate_cc -src $collect -dest u_pinmux -file col.csv -run
#generate_cc -src [get_cells u_gpio] -dest u_pinmux -file gpio.csv -run
#
#    foreach_in_collection inst $collect {
#        set instName [get_attribute $inst full_name];
#        puts "INFO - $instName"
#        puts "iteration $inst"
#    }


# load initial state 
#sim_config -default_input 0
#sim_config -stable_limit 2000

#save_cc_cov 111.el

sim_run -stable
sim_reset

sim_save_reset 

# Run check command
#check_fv -run_finish {
#    report_fv -list
#}


check_fv -block

compute_cc_cov -block 

save_cc_cov_results
view_coverage

report_fv
