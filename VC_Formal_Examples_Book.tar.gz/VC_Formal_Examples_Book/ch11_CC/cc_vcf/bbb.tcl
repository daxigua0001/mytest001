add_cc -name uart0_tx__to__u_pinmux_uart0_tx_3 -src uart0_tx -dest u_pinmux.uart0_tx -enable {1}
add_cc -name u_gpio_gpio_o__to__u_pinmux_gpio_o_4 -src u_gpio.gpio_o -dest u_pinmux.gpio_o -enable {1}
add_cc -name u0_uart_uart_debug__to__u_pinmux_test_sig1_5 -src u0_uart.uart_debug -dest u_pinmux.test_sig1 -enable {1}
add_cc -name uart0_tx__to__u_pinmux_PAD_IO_0_6 -src uart0_tx -dest u_pinmux.PAD_IO_0 -enable {(soc.u_csr.cfg_uart0_en == 1) && (soc.test_mode_pin == 0)}
add_cc -name u_gpio_gpio_o_7__to__u_pinmux_PAD_IO_7_7 -src u_gpio.gpio_o[7] -dest u_pinmux.PAD_IO_7 -enable {(soc.test_mode_pin == 0) && (soc.u_gpio.csr_gpio_direct_out[7] == 1)}
add_cc -name u_gpio_gpio_o_6__to__u_pinmux_PAD_IO_6_9 -src u_gpio.gpio_o[6] -dest u_pinmux.PAD_IO_6 -enable {(soc.test_mode_pin == 0) && (soc.u_gpio.csr_gpio_direct_out[6] == 1)}
add_cc -name u_gpio_gpio_o_5__to__u_pinmux_PAD_IO_5_11 -src u_gpio.gpio_o[5] -dest u_pinmux.PAD_IO_5 -enable {(soc.test_mode_pin == 0) && (soc.u_gpio.csr_gpio_direct_out[5] == 1)}
add_cc -name u_gpio_gpio_o_4__to__u_pinmux_PAD_IO_4_13 -src u_gpio.gpio_o[4] -dest u_pinmux.PAD_IO_4 -enable {(soc.test_mode_pin == 0) && (soc.u_gpio.csr_gpio_direct_out[4] == 1)}
add_cc -name u_gpio_gpio_o_3__to__u_pinmux_PAD_IO_3_15 -src u_gpio.gpio_o[3] -dest u_pinmux.PAD_IO_3 -enable {(soc.u_csr.cfg_uart1_en == 0) && (soc.test_mode_pin == 0) && (soc.u_gpio.csr_gpio_direct_out[3] == 1)}
add_cc -name u_gpio_gpio_o_2__to__u_pinmux_PAD_IO_2_17 -src u_gpio.gpio_o[2] -dest u_pinmux.PAD_IO_2 -enable {(soc.u_csr.cfg_uart1_en == 0) && (soc.test_mode_pin == 0) && (soc.u_gpio.csr_gpio_direct_out[2] == 1)}
add_cc -name u_gpio_gpio_o_1__to__u_pinmux_PAD_IO_1_19 -src u_gpio.gpio_o[1] -dest u_pinmux.PAD_IO_1 -enable {(soc.u_csr.cfg_uart0_en == 0) && (soc.test_mode_pin == 0) && (soc.u_gpio.csr_gpio_direct_out[1] == 1)}
add_cc -name u_gpio_gpio_o_0__to__u_pinmux_PAD_IO_0_21 -src u_gpio.gpio_o[0] -dest u_pinmux.PAD_IO_0 -enable {(soc.u_csr.cfg_uart0_en == 0) && (soc.test_mode_pin == 0) && (soc.u_gpio.csr_gpio_direct_out[0] == 1)}
