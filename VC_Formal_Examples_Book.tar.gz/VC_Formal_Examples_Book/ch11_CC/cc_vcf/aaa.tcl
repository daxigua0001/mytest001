add_cc -name uart0_tx__to__u_pinmux_uart0_tx_0 -src uart0_tx -dest u_pinmux.uart0_tx -enable {1}
add_cc -name uart0_tx__to__u_pinmux_PAD_IO_0_1 -src uart0_tx -dest u_pinmux.PAD_IO_0 -enable {(soc.u_csr.cfg_uart0_en == 1) && (soc.test_mode_pin == 0)}
