add_cc -name in_4_0__to__out3_0 -src in_4[0] -dest out3 -enable {1}
