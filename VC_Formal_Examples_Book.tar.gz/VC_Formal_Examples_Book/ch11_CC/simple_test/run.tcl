set_fml_appmode CC

set design simple_test 

# Compile the design
read_file -top $design -format sverilog -vcs {simple_test.v}

#fvassume p4 -stable -expr {en1}

#connectivity rule 
add_cc -name c1 -src in1 -dest out1 -enable {en1==0} -path_delay 2 -enable_delay -2 -enable_hold 0 -clock clk  
add_cc -name c2 -src in2 -dest out1 -enable {en1==1} -path_delay 5 -enable_delay 0  -enable_hold 1 -clock clk  

add_cc -name c3 -src in1 -dest out2 -enable {~en1&& ~en2} -path_delay 2 -enable_delay -2  -enable_hold 4 -clock clk  
add_cc -name c4 -src in2 -dest out2 -enable {en1 && ~en2} -path_delay 5 -enable_delay 0  -enable_hold 5 -clock clk  

add_cc -name c5 -src in4 -dest out3 -enable {1}

#add_cc -name c6 -src in3 -dest out2 -enable {en2==1} -path_delay 0 -enable_delay 0  -enable_hold 0 -clock clk  
#path delay range
#add_cc -name range -src in1 -dest out1 -enable {en1==0} -path_delay 2:3 -enable_delay -2 -enable_hold 0 -clock clk 

# Clock Definitions 
create_clock clk -period 100 
create_reset rst_n -sense low 

sim_run -stable
sim_reset
sim_save_reset 

check_fv -block

#save properties to aaa.csv, test ok
#report_fv -formatCC csv > aaa.csv

