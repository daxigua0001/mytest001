
module simple_test
(
  input  clk,
  input  rst_n,

  input  in1,
  input  in2,
  input  in3,
  input  in4,

  input  en1,
  input  en2,

  output reg  out1,
  output wire out2,
  output wire out3

);

reg    in1_r ;
reg    in2_r ;
reg    in2_r2 ;
reg    in2_r3 ;
reg    in2_r4 ;
reg    en1_r ;
reg    en1_r2 ;
reg    en1_r3 ;

wire mux_out;
assign  mux_out = en1_r3 ? in2_r4 : in1_r;

assign out2 = en2 ? in3 : out1;
assign out3 = in4;

always @(posedge clk or negedge rst_n) 
begin
  if(~rst_n) begin
    out1 <= 1'b0;
  end
  else begin
    out1 <= mux_out;
  end
end


always @(posedge clk or negedge rst_n) 
begin
  if(~rst_n) begin
    in1_r <= 1'b0;

    in2_r <= 1'b0;
    in2_r2 <= 1'b0;
    in2_r3 <= 1'b0;
    in2_r4 <= 1'b0;

    en1_r <= 1'b0;
    en1_r2 <= 1'b0;
    en1_r3 <= 1'b0;
  end
  else begin
    in1_r <= in1;

    in2_r  <= in2;
    in2_r2 <= in2_r;
    in2_r3 <= in2_r2;
    in2_r4 <= in2_r3;

    en1_r  <= en1;
    en1_r2 <= en1_r;
    en1_r3 <= en1_r2;
  end

end


endmodule 
