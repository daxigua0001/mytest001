add_cc -name u_pinmux_PAD_IO_1__to__uart_rx_43 -src u_pinmux.PAD_IO_1 -dest uart_rx -enable {(soc.test_mode_pin == 0) && (soc.u_gpio.csr_gpio_direct_out[1] == 0) && (soc.u_csr.cfg_uart_en == 1)}
add_cc -name u_pinmux_gpio_i__to__u_gpio_gpio_i_52 -src u_pinmux.gpio_i -dest u_gpio.gpio_i -enable {1}
add_cc -name u_pinmux_uart_rx__to__uart_rx_53 -src u_pinmux.uart_rx -dest uart_rx -enable {1}
add_cc -name u_pinmux_PAD_IO_7__to__u_gpio_gpio_i_7_56 -src u_pinmux.PAD_IO_7 -dest u_gpio.gpio_i[7] -enable {(soc.test_mode_pin == 0) && (soc.u_gpio.csr_gpio_direct_out[7] == 0)}
add_cc -name u_pinmux_PAD_IO_6__to__u_gpio_gpio_i_6_57 -src u_pinmux.PAD_IO_6 -dest u_gpio.gpio_i[6] -enable {(soc.test_mode_pin == 0) && (soc.u_gpio.csr_gpio_direct_out[6] == 0)}
add_cc -name u_pinmux_PAD_IO_5__to__u_gpio_gpio_i_5_58 -src u_pinmux.PAD_IO_5 -dest u_gpio.gpio_i[5] -enable {(soc.test_mode_pin == 0) && (soc.u_gpio.csr_gpio_direct_out[5] == 0)}
add_cc -name u_pinmux_PAD_IO_4__to__u_gpio_gpio_i_4_59 -src u_pinmux.PAD_IO_4 -dest u_gpio.gpio_i[4] -enable {(soc.test_mode_pin == 0) && (soc.u_gpio.csr_gpio_direct_out[4] == 0)}
add_cc -name u_pinmux_PAD_IO_3__to__u_gpio_gpio_i_3_60 -src u_pinmux.PAD_IO_3 -dest u_gpio.gpio_i[3] -enable {(soc.test_mode_pin == 0) && (soc.u_gpio.csr_gpio_direct_out[3] == 0)}
add_cc -name u_pinmux_PAD_IO_2__to__u_gpio_gpio_i_2_61 -src u_pinmux.PAD_IO_2 -dest u_gpio.gpio_i[2] -enable {(soc.test_mode_pin == 0) && (soc.u_gpio.csr_gpio_direct_out[2] == 0)}
