add_cc -name uart_tx__to__u_pinmux_uart_tx_0 -src uart_tx -dest u_pinmux.uart_tx -enable {1}
add_cc -name uart_tx__to__u_pinmux_PAD_IO_0_1 -src uart_tx -dest u_pinmux.PAD_IO_0 -enable {(soc.u_csr.cfg_uart_en == 1) && (soc.test_mode_pin == 0)}
