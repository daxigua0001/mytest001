#
# *********************************************************************
# * SYNOPSYS CONFIDENTIAL                                             *
# *                                                                   *
# * This is an unpublished, proprietary work of Synopsys, Inc., and   *
# * is fully protected under copyright and trade secret laws. You may *
# * not view, use, disclose, copy, or distribute this file or any     *
# * information contained herein except pursuant to a valid written   *
# * license from Synopsys.                                            *
# *********************************************************************

set_fml_appmode CC

set_message_severity -name CC_UID017 error

set_message_error_action stop
set_app_var fml_cc_coverage_analyzer true      

set design soc 

# Compile the design
#read_file -top $design -format verilog -vcs {../design/cctest.v +define+RTL_BUG_FIX}
#read_file -top $design -format verilog -vcs {../design/cctest.v }
read_file -top $design -format sverilog -cov tgl -vcs {-f ../riscv.f}

# Clock Definitions 
create_clock clk -period 100 
#create_clock clk -period 100 -initial 1

create_reset rst_n -sense low 

add_cc -src u_gpio.gpio_o -dest u_pinmux.gpio_o -enable {1}

#set_constant -value 1  u_pinmux.uart_en 
#add_cc -src uart_tx -dest soc.u_pinmux.func_pin_mux[0] -enable u_pinmux.uart_en

#add_cc -src u_uart.u_uart_tx.tx -dest u_pinmux.u0_pad_io.o -enable "(~test_mode_pin) && (soc.u_csr.cfg_uart_en)"
#add_cc -src u_gpio.gpio_o[2] -dest u_pinmux.u2_pad_io.o -enable "(~test_mode_pin) && (soc.u_csr.cfg_uart_en)"


###generate_cc -src uart_tx -dest u_pinmux -file aaa.tcl -run
#generate_cc -src u_gpio.gpio_o -dest u_pinmux -file aaa.tcl -run

#test fail
#generate_cc -src {uart_tx u_gpio.gpio_o} -dest u_pinmux -file aaa.tcl -run
#generate_cc -src {uart_tx u_gpio.gpio_o} -dest u_pinmux -file bbb.tcl -run

#test ok
###generate_cc -src {uart_tx,u_gpio.gpio_o,u_core.core_dbg_out,u_uart.uart_debug} -dest u_pinmux -file bbb.tcl -run
#generate_cc -src u_core.core_dbg_out -dest u_pinmux -file ccc.tcl -run
#generate_cc -src u_pinmux.test_sig0 -dest u_pinmux.test_sig -file ddd.tcl -run

###generate_cc -src u_pinmux -dest {u0_uart.u_uart_rx.rx,u_gpio.gpio_i} -file ccc.tcl -run

add_cc -clock clk -src  u_pinmux.test_sig0 -dest u_pinmux.test_sig -enable {cfg_test_sig_sel == 0 } -path_delay 1

report_fv -formatCC csv > test.csv


#generate_cc -src [get_cells u_gpio] -dest u_pinmux -file bbb.csv -run
#set collect [get_nets uart_tx]
#set collect [add_to_collection $collect [get_nets core_dbg_out]]
#    foreach_in_collection inst $collect {
#        set instName [get_attribute $inst full_name];
#        puts "INFO - $instName"
#    }
#set collect [get_cells u_gpio]
#set collect [add_to_collection $collect [get_cells u_uart]]
##set collect [add_to_collection $collect [get_nets core_dbg_out]]
#generate_cc -src $collect -dest u_pinmux -file col.csv -run
#generate_cc -src [get_cells u_gpio] -dest u_pinmux -file gpio.csv -run
#
#    foreach_in_collection inst $collect {
#        set instName [get_attribute $inst full_name];
#        puts "INFO - $instName"
#        puts "iteration $inst"
#    }




#compute_cc_cov

#generate_cc -run -limit 5

# csv parameters
#load_cc_set_param csv_enable "%1%"
#load_cc_set_param csv_from "%2%"
#load_cc_set_param csv_to "%3%"
#load_cc_set_param csv_clock "%4%"
#load_cc_set_param csv_prop_name "%5%"
#load_cc_set_param csv_start_line "2"
#
## load csv file
#load_cc -format csv riscv_cctest.csv


# load initial state 
#sim_config -default_input 0
#sim_config -stable_limit 2000

#save_cc_cov 111.el

sim_run -stable
sim_reset

sim_save_reset 

# Run check command
#check_fv -run_finish {
#    report_fv -list
#}


check_fv -block

compute_cc_cov -block

save_cc_cov_results

view_coverage
report_fv
