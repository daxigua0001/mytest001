add_cc -name u_pinmux_PAD_IO_1__to__u0_uart_u_uart_rx_rx_0 -src u_pinmux.PAD_IO_1 -dest u0_uart.u_uart_rx.rx -enable {(soc.test_mode_pin == 0) && (soc.u_gpio.csr_gpio_direct_out[1] == 0) && (soc.u_csr.cfg_uart0_en == 1) && (soc.u0_uart.csr_uart_ctrl[0] == 0)}
add_cc -name u_pinmux_gpio_i__to__u_gpio_gpio_i_9 -src u_pinmux.gpio_i -dest u_gpio.gpio_i -enable {1}
add_cc -name u_pinmux_uart0_rx__to__u0_uart_u_uart_rx_rx_10 -src u_pinmux.uart0_rx -dest u0_uart.u_uart_rx.rx -enable {(soc.u0_uart.csr_uart_ctrl[0] == 0)}
add_cc -name u_pinmux_PAD_IO_7__to__u_gpio_gpio_i_7_13 -src u_pinmux.PAD_IO_7 -dest u_gpio.gpio_i[7] -enable {(soc.test_mode_pin == 0) && (soc.u_gpio.csr_gpio_direct_out[7] == 0)}
add_cc -name u_pinmux_PAD_IO_6__to__u_gpio_gpio_i_6_14 -src u_pinmux.PAD_IO_6 -dest u_gpio.gpio_i[6] -enable {(soc.test_mode_pin == 0) && (soc.u_gpio.csr_gpio_direct_out[6] == 0)}
add_cc -name u_pinmux_PAD_IO_5__to__u_gpio_gpio_i_5_15 -src u_pinmux.PAD_IO_5 -dest u_gpio.gpio_i[5] -enable {(soc.test_mode_pin == 0) && (soc.u_gpio.csr_gpio_direct_out[5] == 0)}
add_cc -name u_pinmux_PAD_IO_4__to__u_gpio_gpio_i_4_16 -src u_pinmux.PAD_IO_4 -dest u_gpio.gpio_i[4] -enable {(soc.test_mode_pin == 0) && (soc.u_gpio.csr_gpio_direct_out[4] == 0)}
add_cc -name u_pinmux_PAD_IO_3__to__u_gpio_gpio_i_3_17 -src u_pinmux.PAD_IO_3 -dest u_gpio.gpio_i[3] -enable {(soc.test_mode_pin == 0) && (soc.u_gpio.csr_gpio_direct_out[3] == 0) && (soc.u_csr.cfg_uart1_en == 0)}
add_cc -name u_pinmux_PAD_IO_2__to__u_gpio_gpio_i_2_18 -src u_pinmux.PAD_IO_2 -dest u_gpio.gpio_i[2] -enable {(soc.test_mode_pin == 0) && (soc.u_gpio.csr_gpio_direct_out[2] == 0) && (soc.u_csr.cfg_uart1_en == 0)}
add_cc -name u_pinmux_PAD_IO_1__to__u_gpio_gpio_i_1_19 -src u_pinmux.PAD_IO_1 -dest u_gpio.gpio_i[1] -enable {(soc.test_mode_pin == 0) && (soc.u_gpio.csr_gpio_direct_out[1] == 0) && (soc.u_csr.cfg_uart0_en == 0)}
add_cc -name u_pinmux_cfg_uart0_en__to__u_gpio_gpio_i_0_5268 -src u_pinmux.cfg_uart0_en -dest u_gpio.gpio_i[0] -enable {(soc.test_mode_pin == 0) && (soc.u_csr.cfg_uart0_en == 1) && (soc.u0_uart.u_uart_tx.tx == 1)}
add_cc -name u_pinmux_test_mode__to__~u_gpio_gpio_i_0_5284 -src u_pinmux.test_mode -dest ~u_gpio.gpio_i[0] -enable {(soc.test_mode_pin == 0) && (soc.u_csr.cfg_uart0_en == 1) && (soc.u0_uart.u_uart_tx.tx == 1)}
