set_fml_appmode CC

source $env(OUT_HOME)/$env(GC_VARIANT)/library/gc-$env(GC_VARIANT)/pub/src/formal/common/fpv_common_tcl_lib_vcf.tcl
source $env(OUT_HOME)/$env(GC_VARIANT)/library/gc-$env(GC_VARIANT)/pub/src/formal/common/fpv_gfxip_common_include.tcl
source $env(OUT_HOME)/$env(GC_VARIANT)/library/gc-$env(GC_VARIANT)/pub/src/formal/sh/lds/lds_common_include.tcl

GFXIP::INIT "CC"

LDS::DisplayChangelist
GFXIP::get_technology_library_paths

if {![info exists AFI_BUILD_OPTIONS]}     { set AFI_BUILD_OPTIONS "" ; }
if {![info exists subsys]}                { set subsys "sh" ; }
if {![info exists block]}                 { set block "lds" ; }
if {![info exists subblock]}              { set subblock "" ; }
if {![info exists testname]}              { set testname "unknown" ; }
if {![info exists sanity_only]}           { set sanity_only 0 ; }
if {![info exists run_clock_cover ]}      { set run_clock_cover 1 ; }
if {![info exists run_sample_only]}       { set run_sample_only 0 ; }
if {![info exists run_prior_failures]}    { set run_prior_failures 0 ; }
if {![info exists max_failures]}           { set max_failures 100 ; }
if {![info exists run_inconclusive_complexity_reports]}    { set run_inconclusive_complexity_reports 0 ; }
if {![info exists enable_abstractions]}   { set enable_abstractions 0 ; }
if {![info exists fml_effort0]}           { set fml_effort0           "default" ; }
if {![info exists lsf_licenses0]}         { set lsf_licenses0         96 ; }
if {![info exists backup_lsf_licenses0]}  { set backup_lsf_licenses0  24 ; }
if {![info exists lsf_mem0    ]}          { set lsf_mem0              8000 ; }
if {![info exists lsf_backup_mem0]}       { set lsf_backup_mem0       16000 ; }
if {![info exists max_time0]}             { set max_time0             24h ; }
if {![info exists max_proof_depth0]}      { set max_proof_depth0      -1 ; }
if {![info exists vacuity_on ]}           { set vacuity_on false ; }
if {![info exists rma_dir]}                  { set rma_dir "$env(STEM)/FORMAL/RMA_LEARN_DATA/$env(GC_VARIANT)/${subsys}/${block}/${testname}" ; }
if {![info exists upload_results]}        { set upload_results 0 ; }
if {![info exists auto_save]}             { set auto_save 1 ; }


##### SETTINGS
set_fml_var fml_vacuity_on $vacuity_on
if {$auto_save==1} { set_app_var fml_auto_save true; } else { set_app_var fml_auto_save false; }
if {$rma_dir != ""} { GFXIP::setup_regression_mode_acceleration $rma_dir }

### none of our checking should be going through the memories or fifos, consequently blackbox them.
set_blackbox -designs *_mem2p*
set_blackbox -designs gfx_new_kc_fifo
set_blackbox -designs gfx_new_kc_fifo_reg_out

seq_config -map_uninit -map_counters -map_x bestmatch

# Compile the design
#read_file -sva -top chip_top -verilog -format verilog -vcs {../design/cctest.v -sverilog +define+RTL_BUG_FIX}
#
analyze -format sverilog -vcs " -verbose -sverilog -assert svaext -f $env(OUT_HOME)/$env(DJ_CONTEXT)/library/gc-$env(DJ_CONTEXT)/pub/src/formal/sh/lds/lds_filelist.f +define+FPV_VCF_FPV+FPV_VCF+FORMAL+USE_KC_BEHAVIORAL  $AFI_BUILD_OPTIONS -suppress=SM_IGN_FINAL,SVAC-IAAB,SVAC-IATFNS,SV-LCM-PPWI,PHNE "  
elaborate -sva -vcs " -verbose -suppress=SM_IGN_FINAL,SVAC-IAAB,SVAC-IATFNS,UII-L,SV-LCM-PPWI -error=XMRE-L -error=XMRE-L,SM_BNP +lint=TFIPC-L" $block  

 # csv parameters
load_cc_set_param csv_prop_name "%1%"
load_cc_set_param csv_enable "%2%"
load_cc_set_param csv_from "%3%"
load_cc_set_param csv_to "%4%"
load_cc_set_param csv_path_delay "%5%"
load_cc_set_param csv_enable_delay "%6%"
load_cc_set_param csv_enable_hold "%7%"
load_cc_set_param csv_clock "%8%"
load_cc_set_param csv_start_line "2"

# load csv file
load_cc -format csv $env(OUT_HOME)/$env(GC_VARIANT)/library/gc-$env(GC_VARIANT)/pub/src/formal/sh/lds/lds_cc_lds_icg_ctrl_reg.csv

#report_link
#report_fv_complexity

fvassume ASM_enable_cgcg_en              -env -expr "cgcg_en"
fvassume ASM_dft_clk_gate_cntl_0         -env -expr "dft_clk_gate_ctrl[1:0] == 0"
fvassume ASM_dft_shift_clk_off           -env -expr "dft_shift_clk == 0"
fvassume ASM_BPM_LDS_PERFMON_clock_state -env -expr "BPM_LDS_PERFMON_clock_state == 1"
fvassume spec_ASM_TTOP_LDS_REP_fgcg_stable -expr "@(posedge Cpl_GFXCLK)  ~TTOP_LDS_REP_fgcg_override"

## the override confuses the tool in that it modifies the override also.  force this to be disabled.
#fvassume no_ttop -expr { TTOP_LDS_mgcg_override == 0 }

set_constant -value 0 TTOP_LDS_mgcg_override

## load initial state 
sim_config -default_input 0
sim_config -stable_limit 2000
sim_reset
create_clock Cpl_GFXCLK -period 100 -initial 1
create_reset bind_lds_intf.virtual_resetb -sense low
sim_force TTOP_P1_LDS_hard_resetb -apply 0
sim_force TTOP_P2_LDS_hard_resetb -apply 0
sim_force TTOP_P2_LDS_combined_resetb -apply 0
sim_set_state -uninitialized -apply 0
sim_run 10
sim_run -stable
sim_force TTOP_P1_LDS_hard_resetb -apply 1
sim_force TTOP_P2_LDS_hard_resetb -apply 1
sim_force TTOP_P2_LDS_combined_resetb -apply 1
sim_run 4
sim_save_reset

GFXIP::amd_setup_grid -1 -1 $lsf_licenses0 $lsf_mem0 $backup_lsf_licenses0 $lsf_backup_mem0
check_fv_setup -block
get_resource_cost
report_fv_setup
report_fv_setup -list


# Run check command
check_fv  -block
report_fv 
report_fv -list > results.txt
save_session

